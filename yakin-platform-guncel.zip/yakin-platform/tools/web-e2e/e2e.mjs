import { chromium } from 'playwright-core';
const API = 'http://localhost:3000/v1';
const j = async (path, body, tok, method) => { const r = await fetch(API + path, { method: method || (body ? 'POST' : 'GET'), headers: { 'content-type': 'application/json', ...(tok ? { authorization: 'Bearer ' + tok } : {}) }, body: body ? JSON.stringify(body) : undefined }); return r.json(); };
import { execSync } from 'child_process';
const clearOtp = () => execSync(`PGPASSWORD=yakin psql -h localhost -U yakin yakin -qc "delete from otp_codes"`);
const apiLogin = async ph => { clearOtp(); await j('/auth/otp/request', { phone: ph }); return (await j('/auth/otp/verify', { phone: ph, code: '123456', termsAccepted: true })).accessToken; };
const results = [];
const ok = (name, cond, extra = "") => { const s = `${cond ? "GECTI" : "KALDI"}  ${name} ${extra}`; results.push(s); console.log(s); };

const b = await chromium.launch({ executablePath: process.env.HOME + '/.cache/ms-playwright/chromium-1217/chrome-linux64/chrome' });
const ctx = await b.newContext({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 1.5 });
const p = await ctx.newPage();
const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
let n = 0;
const shot = async name => { await p.waitForTimeout(1300); await p.screenshot({ path: `/tmp/pw/e_${String(++n).padStart(2, '0')}_${name}.png` }); };
const btn = (name, exact) => p.getByRole('button', { name, exact }).first();
const tap = async (name, exact) => { await btn(name, exact).click({ timeout: 8000 }); await p.waitForTimeout(900); };
const semantics = async () => { await p.evaluate(() => document.querySelector('flt-semantics-placeholder')?.click()); await p.waitForTimeout(600); };
const go = async path => { await p.evaluate(h => { location.hash = h; }, path); await p.waitForTimeout(2200); };
const tab = async label => { await p.getByRole('tab', { name: new RegExp(label) }).or(p.getByRole('button', { name: new RegExp('^' + label) })).first().click(); await p.waitForTimeout(1200); };

const pick = async name => { const rx = typeof name === 'string' ? new RegExp('^' + name + '$') : name; await p.getByRole('button', { name: rx }).or(p.getByRole('checkbox', { name: rx })).or(p.getByRole('radio', { name: rx })).or(p.getByText(rx)).first().click({ timeout: 8000 }); await p.waitForTimeout(700); };
async function uiLogin(phone) { clearOtp();
  await p.goto('http://localhost:8080/'); await p.waitForTimeout(5000); await semantics();
  await tap('Başla');
  await p.getByRole('textbox').first().click(); await p.waitForTimeout(600); await p.keyboard.type(phone);
  await p.getByRole('checkbox').click(); await tap('Kod gönder'); await p.waitForTimeout(1500);
  await p.getByRole('textbox').first().click(); await p.waitForTimeout(600); await p.keyboard.type('123456'); await p.waitForTimeout(4000);
}
async function uiLogout() { await go('/profile'); await tap(/Çıkış yap/); await p.waitForTimeout(1500); }

const step = async (name, f) => { try { await f(); } catch (e) { ok(name, false, '-> ' + e.message.split('\n')[0].slice(0, 140)); await shot('HATA_' + name.replace(/\W+/g, '_')); } };

// ===== 1. Ayşe: fotoğraflı ilan ver =====
await uiLogin('5550000011');
const title = 'Çocuk bisikleti 16 jant ' + Date.now().toString().slice(-4);
await step('İlan verme sihirbazı', async () => {
  await tab('İlan ver');
  await tap(/Ücretsiz veriyorum/); await tap('Devam');
  await shot('foto_adimi');
  await p.getByRole('button', { name: /Ekle/ }).last().click(); await p.waitForTimeout(800);
  const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 8000 }), tap(/Galeriden seç/)]);
  await fc.setFiles('/tmp/pw/bisiklet.jpg'); await p.waitForTimeout(3000);
  await shot('foto_yuklendi');
  await tap('Devam');
  await p.getByRole('textbox', { name: /Başlık/ }).click(); await p.waitForTimeout(600); await p.keyboard.type(title);
  await p.getByRole('textbox', { name: /Açıklama/ }).click(); await p.waitForTimeout(600); await p.keyboard.type('Kızım büyüdü, bisiklet sağlam durumda. Bahçelievler parkında teslim edebilirim.');
  await pick('İyi');
  await shot('bilgiler');
  await tap('Devam');
  await p.getByRole('checkbox').click();
  await shot('onizleme');
  await tap('Yayınla'); await p.waitForTimeout(2500);
  await shot('ilan_detay');
  ok('İlan verme sihirbazı (fotoğraf yükleme dahil)', true);
});

// ===== 2. Mehmet API ile yazar =====
const mehmet = await apiLogin('+905550000012');
const feed = await j('/listings?q=' + encodeURIComponent('bisiklet'), null, mehmet);
const L = (feed.items || []).find(x => x.title === title);
ok('İlan akışta ve fotoğraflı görünüyor', !!L && !!L.coverUrl);
let convId;
if (L) { convId = (await j('/conversations', { listingId: L.id }, mehmet)).id; await j(`/conversations/${convId}/messages`, { body: 'Merhaba, bisiklet için yazıyorum. Yarın alabilir miyim?' }, mehmet); }

// ===== 3. Ayşe ilanı kapatır, teslim alanı seçer =====
await step('İlan kapatma ve teslim', async () => {
  await go('/me/listings');
  await shot('ilanlarim');
  const labels = await p.getByRole('group').evaluateAll(es => es.map(e => e.getAttribute('aria-label') || e.textContent || ''));
  const cards = labels.filter(l => l.includes('görüntülenme'));
  const idx = cards.findIndex(l => l.includes(title)); console.log('kart sırası', idx);
  await p.getByRole('button', { name: 'Menüyü göster' }).nth(idx).click();
  await p.waitForTimeout(800);
  await shot('menu');
  await p.getByRole('menuitem', { name: 'Kapat' }).click(); await p.waitForTimeout(1500);
  await pick(/Mehmet/);
  await shot('kapat_sayfasi');
  await p.getByRole('button', { name: 'Kapat', exact: true }).last().click(); await p.waitForTimeout(2000);
  await shot('kapandi');
  const l = await j('/listings/' + L.id, null, mehmet);
  ok('İlan kapatma (teslim edilen kişi seçerek)', l.status === 'closed', `durum=${l.status}`);
});

// ===== 4. Değerlendirme =====
await step('Değerlendirme', async () => {
  await go('/me/pending-reviews');
  await shot('bekleyen_degerlendirme');
  await p.getByRole('button', { name: new RegExp(title.slice(0, 10)) }).first().click(); await p.waitForTimeout(1500);
  await shot('degerlendirme_bos'); await pick(/5 yıldız|5/); await pick('Dakik'); await pick('Nazik');
  await p.getByRole('textbox').first().click(); await p.waitForTimeout(600); await p.keyboard.type('Zamanında geldi, çok nazikti.');
  await shot('degerlendirme');
  await tap('Gönder', true); await p.waitForTimeout(2000);
  const pr = await j('/me/pending-reviews', null, mehmet);
  ok('Değerlendirme gönderildi (Mehmet tarafında da istek oluştu)', (pr.items || []).some(x => x.listingId === L.id));
});

// ===== 5. Ayarlar =====
await step('Ayarlar', async () => {
  await go('/settings');
  await p.getByRole('switch', { name: /Mahallemi gizle/ }).or(p.getByRole('checkbox', { name: /Mahallemi gizle/ })).first().click(); await p.waitForTimeout(1500);
  await shot('ayarlar');
  const ayse = await apiLogin('+905550000011');
  const me = await j('/me', null, ayse);
  ok('Gizlilik ayarı kaydediliyor', me.privacy.hideNeighborhood === true);
  await j('/me', { hideNeighborhood: false }, ayse, 'PATCH');
  await p.mouse.wheel(0, 900); await shot('ayarlar_alt');
});
await step('Bildirimler ve profil', async () => {
  await go('/notifications'); await shot('bildirimler');
  await go('/me/reports'); await shot('sikayetlerim');
  await go('/profile'); await shot('profil');
  ok('Bildirimler, şikayetlerim, profil ekranları açıldı', true);
});
await uiLogout();

// ===== 6. Moderasyon verisi hazırla =====
const zeynep = await apiLogin('+905550000013');
// const zc = await j('/conversations', { listingId: (await j('/listings?q=kedi', null, zeynep)).items?.find(x => true)?.id }, zeynep).catch(() => null);
// Mehmet'in bir mesajı için Zeynep şikayet etsin: Mehmet bir ilan açsın, Zeynep yazsın, Mehmet şüpheli yanıt versin
const ml = await j('/listings', { category: 'yardim', subtype: 'istiyorum', title: 'Kamp sandalyesi taşıma', description: 'Kamp sandalyelerini arabaya taşımak için yardım lazım.', publish: true }, mehmet);
console.log('ml', JSON.stringify(ml).slice(0,200));
const mc = await j('/conversations', { listingId: ml.id }, zeynep);
await j(`/conversations/${mc.id}/messages`, { body: 'Merhaba, sandalye duruyor mu?' }, zeynep);
const bad = await j(`/conversations/${mc.id}/messages`, { body: 'Duruyor, önce kapora at sonra konuşuruz.' }, mehmet);
const rep = await j('/reports', { targetType: 'message', targetId: bad.message.id, reason: 'dolandiricilik', note: 'Görmeden kapora istiyor.' }, zeynep);
ok('Mesaj şikayeti oluşturuldu', !!rep.id, JSON.stringify(rep).slice(0, 160)); console.log('bad', JSON.stringify(bad).slice(0,200));
const pend = await j('/listings', { category: 'yardim', subtype: 'istiyorum', title: 'Taşınma için yardım', description: 'Eşyaları taşıyacak birine ihtiyaç var, önce kapora alıyorum.', publish: true }, mehmet);
console.log('pend', JSON.stringify(pend).slice(0,200));
ok('Kurala takılan ilan incelemeye düştü', pend.status === 'pending_review', pend.status);

// ===== 7. Moderatör paneli =====
await uiLogin('5550000002');
await step('Moderasyon paneli', async () => {
  await tab('Profil'); await shot('moderator_profil');
  await tap(/Moderasyon paneli/); await p.waitForTimeout(1500);
  await shot('panel');
  await tap(/Şikayet kuyruğu/); await shot('kuyruk');
  await tap(/Sıradakini al/); await p.waitForTimeout(2000);
  await shot('vaka');
  await pick('Uyarı');
  await p.getByRole('textbox', { name: /İhlal edilen kural/ }).click(); await p.waitForTimeout(600); await p.keyboard.type('4.2 Ön ödeme talebi');
  await p.getByRole('textbox', { name: /gerekçe/ }).click(); await p.waitForTimeout(600); await p.keyboard.type('Ürünü görmeden kapora istemek kurallarımıza aykırı.');
  await shot('karar_formu');
  await p.mouse.move(200,500); await p.mouse.wheel(0,800); await p.waitForTimeout(800); await tap('Kararı kaydet'); await p.waitForTimeout(2000);
  const d = await j('/me/decisions', null, mehmet);
  ok('Moderatör şikayet vakasına karar verdi (uyarı)', (d.items || []).some(x => x.action === 'warn'));
  await p.goBack().catch(() => {}); await p.waitForTimeout(1000);
});
await step('İlan onayı', async () => {
  await go('/admin/listings'); await shot('onay_bekleyen');
  await tap('Onayla'); await p.waitForTimeout(2000);
  const l = await j('/listings/' + pend.id, null, mehmet);
  ok('Moderatör bekleyen ilanı onayladı', l.status === 'active', l.status);
});
await step('Kullanıcı arama', async () => {
  await go('/admin/users');
  await p.getByRole('textbox').first().click(); await p.waitForTimeout(600); await p.keyboard.type('Mehmet'); await p.keyboard.press('Enter'); await p.waitForTimeout(1500);
  await tap(/Mehmet/); await p.waitForTimeout(1500);
  await shot('kullanici_detay');
  ok('Kullanıcı arama ve detay', true);
});
await step('Denetim kaydı', async () => { await go('/admin/audit'); await shot('denetim'); ok('Denetim kaydı açıldı', true); });
await uiLogout();

// ===== 8. Mehmet itiraz eder (uygulamada), yönetici sonuçlandırır =====
await uiLogin('5550000012');
await step('Kullanıcı itirazı', async () => {
  await go('/decisions'); await shot('kararlar');
  await tap('İtiraz et');
  await p.getByRole('textbox').last().click(); await p.waitForTimeout(600); await p.keyboard.type('Şaka yapmıştım, kimseden para almadım. Yüz yüze teslim edecektim.');
  await tap('Gönder', true); await p.waitForTimeout(1800);
  await shot('itiraz_gonderildi');
  const d = await j('/me/decisions', null, mehmet);
  ok('Kullanıcı karara uygulamadan itiraz etti', (d.items || []).some(x => x.appeal));
});
await uiLogout();
await uiLogin('5550000001');
await step('İtiraz sonuçlandırma', async () => {
  await go('/admin'); await shot('yonetici_panel');
  await go('/admin/appeals'); await shot('itirazlar');
  await pick('Reddet'); await p.waitForTimeout(800);
  await tap('Kaydet'); await p.waitForTimeout(2000);
  const d = await j('/me/decisions', null, mehmet);
  ok('Yönetici itirazı sonuçlandırdı', (d.items || []).some(x => x.appeal && x.appeal.status === 'rejected'));
});
await step('Kurallar', async () => {
  await go('/admin/rules'); await shot('kurallar');
  await tap(/Kural ekle/);
  await p.getByRole('textbox', { name: /Kelime/ }).click(); await p.waitForTimeout(600); await p.keyboard.type('sahte fatura');
  await p.getByRole('textbox', { name: /Etiket/ }).click(); await p.waitForTimeout(600); await p.keyboard.type('Sahte belge');
  await tap('Ekle', true); await p.waitForTimeout(1500);
  await shot('kural_eklendi');
  const admin = await apiLogin('+905550000001');
  const rules = await j('/admin/rules', null, admin);
  ok('Yönetici yeni içerik kuralı ekledi', (rules.items || rules).some(r => r.pattern === 'sahte fatura'));
});
console.log(results.join('\n'));
console.log('Sayfa hataları:', JSON.stringify(errs.slice(0, 10)));
await b.close();
