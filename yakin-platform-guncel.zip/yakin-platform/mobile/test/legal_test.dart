import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yakin/features/legal/legal_screen.dart';

void main() {
  test('üç hukuki metin de var ve boş bölüm yok', () {
    expect(kLegalDocs.keys, containsAll(['terms', 'kvkk', 'privacy']));
    for (final e in kLegalDocs.entries) {
      expect(e.value.title, isNotEmpty, reason: e.key);
      expect(e.value.sections.length, greaterThanOrEqualTo(5), reason: e.key);
      for (final s in e.value.sections) {
        expect(s.title.trim(), isNotEmpty, reason: e.key);
        expect(s.body.trim().length, greaterThan(20), reason: '${e.key}: ${s.title}');
      }
    }
  });

  testWidgets('metin ekranı başlığı ve taslak uyarısını gösterir', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: LegalScreen(kind: 'terms')));
    expect(find.text('Kullanım koşulları'), findsWidgets);
    if (kLegalIsDraft) expect(find.textContaining('taslaktır'), findsOneWidget);
  });

  testWidgets('bilinmeyen metin türünde hata durumu gösterilir', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: LegalScreen(kind: 'yok')));
    expect(find.text('Metin bulunamadı'), findsWidgets);
  });
}
