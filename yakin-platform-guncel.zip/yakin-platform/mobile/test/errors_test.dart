import 'package:flutter_test/flutter_test.dart';
import 'package:yakin/core/errors.dart';

void main() {
  test('yeni sunucu hata kodlarının kullanıcı metni var', () {
    for (final c in ['AUTH_SMS_BUDGET', 'AUTH_TOTP_REQUIRED', 'AUTH_TOTP_INVALID', 'TOTP_SETUP_REQUIRED', 'TOTP_ALREADY_ENABLED', 'TOTP_NOT_SETUP']) {
      expect(kErrorText.containsKey(c), isTrue, reason: c);
    }
  });

  test('bilinen kodda Türkçe metin, bilinmeyen kodda sunucu mesajı gösterilir', () {
    expect(ApiException('AUTH_SMS_BUDGET', 'x', 503).message, kErrorText['AUTH_SMS_BUDGET']);
    expect(ApiException('YENI_KOD', 'Sunucu mesajı', 400).message, 'Sunucu mesajı');
    expect(ApiException('YENI_KOD', '', 400).message, 'Bir şeyler ters gitti. Tekrar dene.');
  });
}
