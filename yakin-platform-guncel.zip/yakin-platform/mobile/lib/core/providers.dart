import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'api.dart';
import 'session.dart';

/// main() içinde gerçek oturumla değiştirilir.
final sessionProvider = Provider<Session>((ref) => throw UnimplementedError());
final apiProvider = Provider<Api>((ref) => ref.watch(sessionProvider).api);

final neighborhoodsProvider = FutureProvider<List<Json>>((ref) async {
  final r = await ref.watch(apiProvider).get<Json>('/neighborhoods');
  return List<Json>.from(r['items']);
});

final listingProvider = FutureProvider.autoDispose.family<Json, String>((ref, id) => ref.watch(apiProvider).get<Json>('/listings/$id'));
final conversationsProvider = FutureProvider.autoDispose.family<List<Json>, String>((ref, filter) async {
  final r = await ref.watch(apiProvider).get<Json>('/conversations', {'filter': filter});
  return List<Json>.from(r['items']);
});
final myListingsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/me/listings'))['items']));
final favoritesProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/me/favorites'))['items']));
final notificationsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/notifications'))['items']));
final publicProfileProvider = FutureProvider.autoDispose.family<Json, String>((ref, id) => ref.watch(apiProvider).get<Json>('/users/$id'));
final myStatsProvider = FutureProvider.autoDispose<Json>((ref) => ref.watch(apiProvider).get<Json>('/me/stats'));
final pendingReviewsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/me/pending-reviews'))['items']));
final decisionsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/me/decisions'))['items']));
final blocksProvider = FutureProvider.autoDispose<List<Json>>((ref) async => List<Json>.from((await ref.watch(apiProvider).get<Json>('/me/blocks'))['items']));
