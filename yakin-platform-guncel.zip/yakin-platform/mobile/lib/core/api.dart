import 'dart:async';

import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';

import 'config.dart';
import 'errors.dart';

typedef Json = Map<String, dynamic>;

/// YAKIN API istemcisi. Erişim belirteci süresi dolduğunda tek seferlik yenileme yapar ve isteği tekrarlar.
class Api {
  Api({required this.readTokens, required this.onTokens, required this.onSignedOut}) {
    dio = Dio(BaseOptions(baseUrl: '$kApiUrl/v1', connectTimeout: const Duration(seconds: 10), receiveTimeout: const Duration(seconds: 20)));
    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) {
        final t = readTokens().$1;
        if (t != null && o.headers['Authorization'] == null) o.headers['Authorization'] = 'Bearer $t';
        h.next(o);
      },
      onError: (e, h) async {
        final data = e.response?.data;
        final code = data is Map ? data['code'] : null;
        final isRetry = e.requestOptions.extra['retried'] == true;
        if (e.response?.statusCode == 401 && code == 'AUTH_TOKEN_EXPIRED' && !isRetry && readTokens().$2 != null) {
          try {
            await _refresh();
            final o = e.requestOptions..extra['retried'] = true;
            o.headers['Authorization'] = 'Bearer ${readTokens().$1}';
            return h.resolve(await dio.fetch(o));
          } catch (_) {
            onSignedOut();
          }
        } else if (e.response?.statusCode == 401 && !e.requestOptions.path.startsWith('/auth/')) {
          onSignedOut();
        }
        h.next(e);
      },
    ));
  }

  late final Dio dio;
  final (String?, String?) Function() readTokens;
  final Future<void> Function(String access, String refresh) onTokens;
  final void Function() onSignedOut;
  Future<void>? _refreshing;

  Future<void> _refresh() {
    return _refreshing ??= () async {
      try {
        final r = await Dio(BaseOptions(baseUrl: '$kApiUrl/v1')).post('/auth/refresh', data: {'refreshToken': readTokens().$2});
        await onTokens(r.data['accessToken'], r.data['refreshToken']);
      } finally {
        _refreshing = null;
      }
    }();
  }

  Future<T> _wrap<T>(Future<Response> f) async {
    try {
      return (await f).data as T;
    } on DioException catch (e) {
      final d = e.response?.data;
      if (d is Map && d['code'] != null) {
        throw ApiException(d['code'], d['message'] ?? '', e.response?.statusCode ?? 0, Map<String, dynamic>.from(d['details'] ?? {}));
      }
      throw ApiException(e.response == null ? 'NETWORK' : 'UNKNOWN', '', e.response?.statusCode ?? 0);
    }
  }

  Future<T> get<T>(String path, [Json? q]) => _wrap(dio.get(path, queryParameters: q?..removeWhere((_, v) => v == null)));
  Future<T> post<T>(String path, [Object? body]) => _wrap(dio.post(path, data: body ?? {}));
  Future<T> patch<T>(String path, [Object? body]) => _wrap(dio.patch(path, data: body ?? {}));
  Future<T> delete<T>(String path) => _wrap(dio.delete(path));

  Future<Json> upload(XFile file) async {
    final bytes = await file.readAsBytes();
    final form = FormData.fromMap({'file': MultipartFile.fromBytes(bytes, filename: file.name.isEmpty ? 'foto.jpg' : file.name)});
    return _wrap(dio.post('/media', data: form));
  }
}
