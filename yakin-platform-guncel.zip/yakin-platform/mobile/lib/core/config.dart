/// Derleme zamanında verilir: flutter run --dart-define=API_URL=https://api.ornek.com
/// Android emülatöründe bilgisayardaki sunucu 10.0.2.2 adresindedir.
const String kApiUrl = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:3000');
const String kAppVersion = '0.1.0';
