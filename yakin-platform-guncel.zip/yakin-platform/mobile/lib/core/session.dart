import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:socket_io_client/socket_io_client.dart' as sio;

import 'api.dart';
import 'config.dart';

enum AuthState { loading, signedOut, needsProfile, ready }

class RealtimeEvent {
  final String name;
  final dynamic data;
  RealtimeEvent(this.name, this.data);
}

/// Oturum, kullanıcı profili ve gerçek zamanlı bağlantı.
class Session extends ChangeNotifier {
  Session() {
    api = Api(readTokens: () => (_access, _refresh), onTokens: _saveTokens, onSignedOut: () => signOut(remote: false));
  }

  static const _store = FlutterSecureStorage();
  late final Api api;
  String? _access, _refresh;
  Json? me;
  AuthState state = AuthState.loading;
  sio.Socket? _socket;
  final _events = StreamController<RealtimeEvent>.broadcast();
  Stream<RealtimeEvent> get events => _events.stream;
  final badges = ValueNotifier<Json>({'messages': 0, 'notifications': 0, 'pendingReviews': 0});

  Future<void> init() async {
    _access = await _store.read(key: 'access');
    _refresh = await _store.read(key: 'refresh');
    if (_refresh == null) return _set(AuthState.signedOut);
    try {
      await reloadMe();
      _connect();
    } catch (_) {
      if (_refresh == null) return _set(AuthState.signedOut);
      _set(AuthState.signedOut);
    }
  }

  Future<void> _saveTokens(String access, String refresh) async {
    _access = access;
    _refresh = refresh;
    await _store.write(key: 'access', value: access);
    await _store.write(key: 'refresh', value: refresh);
    _socket?.auth = {'token': access};
  }

  void _set(AuthState s) {
    state = s;
    notifyListeners();
  }

  Future<Json> requestOtp(String phone) => api.post<Json>('/auth/otp/request', {'phone': phone});

  Future<void> verifyOtp(String phone, String code, bool terms, {String? totpCode}) async {
    final r = await api.post<Json>('/auth/otp/verify', {'phone': phone, 'code': code, 'termsAccepted': terms, 'device': defaultTargetPlatform.name, if (totpCode != null) 'totpCode': totpCode});
    await _saveTokens(r['accessToken'], r['refreshToken']);
    me = Map<String, dynamic>.from(r['user']);
    _connect();
    _set(me!['profileComplete'] == true ? AuthState.ready : AuthState.needsProfile);
  }

  Future<void> reloadMe() async {
    me = await api.get<Json>('/me');
    _set(me!['profileComplete'] == true ? AuthState.ready : AuthState.needsProfile);
    refreshBadges();
  }

  Future<void> updateMe(Json patch) async {
    me = await api.patch<Json>('/me', patch);
    _set(me!['profileComplete'] == true ? AuthState.ready : AuthState.needsProfile);
  }

  Future<void> refreshBadges() async {
    if (state != AuthState.ready) return;
    try {
      badges.value = await api.get<Json>('/badges');
    } catch (_) {}
  }

  void _connect() {
    _socket?.dispose();
    _socket = sio.io(kApiUrl, sio.OptionBuilder().setTransports(['websocket']).setAuth({'token': _access}).enableReconnection().disableAutoConnect().build());
    for (final e in ['message:new', 'message:read', 'message:deleted', 'typing', 'conversation:updated', 'listing:status', 'notification:new']) {
      _socket!.on(e, (data) {
        _events.add(RealtimeEvent(e, data));
        if (e == 'message:new' || e == 'notification:new' || e == 'conversation:updated') refreshBadges();
      });
    }
    _socket!.connect();
  }

  void emitTyping(String conversationId) => _socket?.emit('typing', {'conversationId': conversationId});

  Future<void> signOut({bool remote = true}) async {
    if (state == AuthState.signedOut) return;
    if (remote && _refresh != null) {
      try {
        await api.post('/auth/logout', {'refreshToken': _refresh});
      } catch (_) {}
    }
    _socket?.dispose();
    _socket = null;
    _access = _refresh = null;
    me = null;
    await _store.deleteAll();
    _set(AuthState.signedOut);
  }
}
