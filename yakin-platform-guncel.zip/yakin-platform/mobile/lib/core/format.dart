import 'package:intl/intl.dart';

final _tl = NumberFormat.currency(locale: 'tr_TR', symbol: '₺', decimalDigits: 0);

String priceText(String subtype, num? kurus) {
  switch (subtype) {
    case 'ucretsiz': return 'Ücretsiz';
    case 'odunc': return 'Ödünç';
    case 'takas': return 'Takas';
    case 'satilik': return kurus == null ? 'Satılık' : _tl.format(kurus / 100);
    case 'istiyorum': return 'Yardım isteniyor';
    case 'teklif': return 'Yardım teklifi';
    case 'kayip_esya': return 'Kayıp eşya';
    case 'bulunan_esya': return 'Bulunan eşya';
    case 'kayip_hayvan': return 'Kayıp hayvan';
  }
  return '';
}

const kCategoryLabel = {'esya': 'Eşya', 'yardim': 'Yardım', 'kayip': 'Kayıp ve bulunan'};
const kSubtypeLabel = {
  'ucretsiz': 'Ücretsiz veriyorum', 'satilik': 'Satıyorum', 'odunc': 'Ödünç veriyorum', 'takas': 'Takas',
  'istiyorum': 'Yardım istiyorum', 'teklif': 'Yardım edebilirim',
  'kayip_esya': 'Eşyamı kaybettim', 'bulunan_esya': 'Bir şey buldum', 'kayip_hayvan': 'Hayvanım kayboldu',
};
const kReportReasons = {
  'dolandiricilik': 'Dolandırıcılık şüphesi', 'uygunsuz_icerik': 'Uygunsuz içerik', 'taciz': 'Taciz veya tehdit',
  'yasakli_urun': 'Yasaklı ürün', 'sahte_ilan': 'Sahte ilan', 'spam': 'Spam', 'cocuk_guvenligi': 'Çocuk güvenliği', 'diger': 'Diğer',
};
const kReviewTags = {'dakik': 'Dakik', 'nazik': 'Nazik', 'aciklamaya_uygun': 'Açıklamaya uygun', 'iletisim_kolay': 'İletişimi kolay', 'guvenilir': 'Güvenilir'};

String distanceText(Map<String, dynamic>? d) {
  if (d == null) return '';
  if (d['approx'] == 'lt300') return "300 m'den yakın";
  final m = (d['meters'] as num).toInt();
  return m >= 1000 ? '${(m / 1000).toStringAsFixed(1).replaceAll('.', ',')} km' : '$m m';
}

String timeAgo(String? iso) {
  if (iso == null) return '';
  final t = DateTime.parse(iso).toLocal();
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'şimdi';
  if (d.inMinutes < 60) return '${d.inMinutes} dk';
  if (d.inHours < 24) return '${d.inHours} sa';
  if (d.inDays < 7) return '${d.inDays} gün';
  return DateFormat('d MMM', 'tr_TR').format(t);
}

String clock(String iso) => DateFormat('HH:mm').format(DateTime.parse(iso).toLocal());
String dayLabel(String iso) {
  final t = DateTime.parse(iso).toLocal();
  final now = DateTime.now();
  if (t.year == now.year && t.month == now.month && t.day == now.day) return 'Bugün';
  final y = now.subtract(const Duration(days: 1));
  if (t.year == y.year && t.month == y.month && t.day == y.day) return 'Dün';
  return DateFormat('d MMMM y', 'tr_TR').format(t);
}

String responseTimeText(int? sec) {
  if (sec == null) return 'Henüz yeterli veri yok';
  if (sec < 3600) return 'Genelde ${(sec / 60).ceil()} dakika içinde yanıt verir';
  if (sec < 86400) return 'Genelde ${(sec / 3600).ceil()} saat içinde yanıt verir';
  return 'Genelde 1 günden uzun sürede yanıt verir';
}
