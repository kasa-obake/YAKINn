/// Sunucu hata kodları için kullanıcıya gösterilen metinler (Tasarım dokümanı 17.4).
const Map<String, String> kErrorText = {
  'AUTH_PHONE_INVALID': 'Telefon numarasını 5XX XXX XX XX biçiminde gir.',
  'AUTH_RATE_LIMITED': 'Çok fazla kod istedin. Biraz sonra tekrar dene.',
  'AUTH_RESEND_TOO_SOON': 'Yeni kod için biraz bekle.',
  'AUTH_SMS_FAILED': 'Kod şu an gönderilemedi. Biraz sonra tekrar dene.',
  'AUTH_OTP_INVALID': 'Kod hatalı. Tekrar dene.',
  'AUTH_OTP_EXPIRED': 'Kodun süresi doldu. Yeni kod iste.',
  'AUTH_OTP_LOCKED': 'Çok fazla hatalı deneme. Yeni kod iste.',
  'AUTH_SMS_BUDGET': 'Şu an doğrulama kodu gönderemiyoruz. Biraz sonra tekrar dene.',
  'AUTH_TOTP_REQUIRED': 'İki adımlı doğrulama kodunu gir.',
  'AUTH_TOTP_INVALID': 'İki adımlı doğrulama kodu hatalı.',
  'TOTP_SETUP_REQUIRED': 'Yönetim işlemleri için önce Ayarlar bölümünden iki adımlı doğrulamayı kur.',
  'TOTP_ALREADY_ENABLED': 'İki adımlı doğrulama zaten açık.',
  'TOTP_NOT_SETUP': 'Önce iki adımlı doğrulama kurulumunu başlat.',
  'AUTH_TERMS_REQUIRED': 'Devam etmek için kullanım koşullarını onayla.',
  'AUTH_REQUIRED': 'Oturumun kapandı. Tekrar giriş yap.',
  'AUTH_TOKEN_EXPIRED': 'Oturumun kapandı. Tekrar giriş yap.',
  'ACCOUNT_SUSPENDED': 'Hesabın şu an askıda.',
  'ACCOUNT_DELETED': 'Bu hesap silinmiş.',
  'PROFILE_INCOMPLETE': 'Önce profilini tamamla.',
  'USER_UNDERAGE': 'YAKIN şimdilik 18 yaş ve üzeri içindir.',
  'USER_NEIGHBORHOOD_LIMIT': 'Mahalleni bu ay en fazla 2 kez değiştirebilirsin.',
  'USER_BIRTHYEAR_LOCKED': 'Doğum yılı değiştirilemez. Destek ile iletişime geç.',
  'GEO_OUT_OF_REGION': 'YAKIN şu an yalnızca Burdur merkezde hizmet veriyor.',
  'LISTING_PHOTO_REQUIRED': 'Bu ilan türü için en az bir fotoğraf ekle.',
  'LISTING_PRICE_REQUIRED': 'Satılık ilanda fiyat gir.',
  'LISTING_SUBTYPE_INVALID': 'İlan türünü seç.',
  'LISTING_LIMIT_REACHED': 'Aynı anda en fazla 10 aktif ilanın olabilir.',
  'LISTING_RATE_LIMITED': 'Kısa sürede çok ilan verdin. Biraz sonra tekrar dene.',
  'LISTING_CONTENT_BLOCKED': 'Bu içerik topluluk kurallarına aykırı görünüyor.',
  'LISTING_NOT_AVAILABLE': 'Bu ilan artık yayında değil.',
  'LISTING_NEIGHBORHOOD_TOO_FAR': 'Yalnızca kendi mahallende veya yakın mahallelerde ilan verebilirsin.',
  'CHAT_BLOCKED': 'Bu kişiyle mesajlaşamazsın.',
  'CHAT_LISTING_CLOSED': 'Bu sohbet artık yalnızca okunabilir.',
  'CHAT_RATE_LIMITED': 'Çok hızlı mesaj gönderiyorsun.',
  'CHAT_OWN_LISTING': 'Kendi ilanına mesaj gönderemezsin.',
  'CHAT_DELETE_WINDOW': 'Mesaj yalnızca ilk 10 dakika içinde silinebilir.',
  'MEDIA_TOO_LARGE': 'Fotoğraf 15 MB sınırını aşıyor.',
  'MEDIA_UNSUPPORTED': 'Bu dosya türü desteklenmiyor.',
  'FAVORITE_LIMIT_REACHED': 'En fazla 100 favori ekleyebilirsin.',
  'REPORT_DUPLICATE': 'Bunu zaten bildirdin. İnceleniyor.',
  'REVIEW_DUPLICATE': 'Bu ilanı zaten değerlendirdin.',
  'APPEAL_WINDOW_CLOSED': 'İtiraz süresi doldu.',
  'APPEAL_DUPLICATE': 'Bu karara zaten itiraz ettin.',
  'RATE_LIMITED': 'Çok fazla istek. Biraz bekle.',
  'NETWORK': 'Bağlantı kurulamadı. İnternetini kontrol et.',
};

class ApiException implements Exception {
  final String code;
  final String serverMessage;
  final int status;
  final Map<String, dynamic> details;
  ApiException(this.code, this.serverMessage, this.status, [this.details = const {}]);
  String get message => kErrorText[code] ?? (serverMessage.isNotEmpty ? serverMessage : 'Bir şeyler ters gitti. Tekrar dene.');
  @override
  String toString() => message;
}

String errorText(Object e) => e is ApiException ? e.message : 'Bir şeyler ters gitti. Tekrar dene.';
