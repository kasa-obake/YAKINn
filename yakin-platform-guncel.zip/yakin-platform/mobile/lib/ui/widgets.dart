import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../core/api.dart';
import '../core/errors.dart';
import '../core/format.dart';
import 'theme.dart';

IconData categoryIcon(String c, [String? sub]) {
  if (sub == 'kayip_hayvan') return LucideIcons.pawPrint;
  return switch (c) { 'yardim' => LucideIcons.handHeart, 'kayip' => LucideIcons.searchX, _ => LucideIcons.package };
}

void toast(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

/// AsyncValue için standart yükleniyor / hata / boş durumları.
class AsyncView<T> extends StatelessWidget {
  const AsyncView({super.key, required this.value, required this.builder, this.onRetry});
  final AsyncValue<T> value;
  final Widget Function(T data) builder;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) => value.when(
        data: builder,
        loading: () => const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator(strokeWidth: 2.5))),
        error: (e, _) => ErrorState(message: errorText(e), onRetry: onRetry),
      );
}

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) => EmptyState(icon: LucideIcons.circleAlert, title: 'Yüklenemedi', body: message, action: onRetry == null ? null : OutlinedButton(onPressed: onRetry, child: const Text('Tekrar dene')));
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, required this.body, this.action});
  final IconData icon;
  final String title, body;
  final Widget? action;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 64, height: 64, decoration: const BoxDecoration(color: YkColors.green50, shape: BoxShape.circle), child: Icon(icon, color: YkColors.green700, size: 28)),
            const SizedBox(height: 16),
            Text(title, style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(body, style: const TextStyle(color: YkColors.n600), textAlign: TextAlign.center),
            if (action != null) ...[const SizedBox(height: 20), SizedBox(width: 220, child: action!)],
          ]),
        ),
      );
}

class Avatar extends StatelessWidget {
  const Avatar({super.key, this.url, required this.name, this.size = 40});
  final String? url;
  final String name;
  final double size;
  @override
  Widget build(BuildContext context) {
    final initial = name.isEmpty ? '?' : name.characters.first.toUpperCase();
    return ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: url != null
            ? CachedNetworkImage(imageUrl: url!, fit: BoxFit.cover)
            : Container(color: YkColors.green100, alignment: Alignment.center, child: Text(initial, style: TextStyle(color: YkColors.green700, fontWeight: FontWeight.w700, fontSize: size * .42))),
      ),
    );
  }
}

class CategoryPill extends StatelessWidget {
  const CategoryPill({super.key, required this.category, required this.subtype});
  final String category, subtype;
  @override
  Widget build(BuildContext context) {
    final c = YkColors.category(category);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: c.withValues(alpha: .1), borderRadius: BorderRadius.circular(999)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(categoryIcon(category, subtype), size: 12, color: c),
        const SizedBox(width: 4),
        Text(priceText(subtype, null), style: TextStyle(color: c, fontSize: 11.5, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

class ListingImage extends StatelessWidget {
  const ListingImage({super.key, required this.url, required this.category, this.subtype, this.radius = YkRadius.md});
  final String? url;
  final String category;
  final String? subtype;
  final double radius;
  @override
  Widget build(BuildContext context) {
    final c = YkColors.category(category);
    final placeholder = Container(color: c.withValues(alpha: .08), alignment: Alignment.center, child: Icon(categoryIcon(category, subtype), color: c, size: 32));
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: url == null ? placeholder : CachedNetworkImage(imageUrl: url!, fit: BoxFit.cover, placeholder: (_, _) => placeholder, errorWidget: (_, __, ___) => placeholder),
    );
  }
}

/// Akış ızgarasındaki ilan kartı.
class ListingCard extends StatelessWidget {
  const ListingCard({super.key, required this.item, required this.onTap});
  final Json item;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final sub = item['subtype'] as String;
    final price = priceText(sub, item['priceKurus'] as num?);
    return Semantics(
      button: true,
      label: '${item['title']}, $price, ${item['neighborhood'] ?? ''}',
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(YkRadius.md),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AspectRatio(
            aspectRatio: 1,
            child: Stack(fit: StackFit.expand, children: [
              ListingImage(url: item['coverUrl'], category: item['category'], subtype: sub),
              if (item['isNew'] == true)
                Positioned(left: 8, top: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: YkColors.mint, borderRadius: BorderRadius.circular(6)), child: const Text('Yeni', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: YkColors.green900)))),
              if (item['isFavorite'] == true) const Positioned(right: 8, top: 8, child: Icon(LucideIcons.heart, color: Colors.white, size: 18)),
            ]),
          ),
          const SizedBox(height: 8),
          Text(item['title'], maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, height: 1.3)),
          const SizedBox(height: 2),
          Text(price, style: TextStyle(fontWeight: FontWeight.w700, color: YkColors.category(item['category']), fontSize: 13.5)),
          const SizedBox(height: 2),
          Text([item['neighborhood'], distanceText(item['distance']), timeAgo(item['publishedAt'])].where((s) => s != null && s.toString().isNotEmpty).join(' · '),
              maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: YkColors.n500, fontSize: 12)),
        ]),
      ),
    );
  }
}

class SafetyBanner extends StatelessWidget {
  const SafetyBanner({super.key, required this.text, this.tone = 'info', this.icon});
  final String text;
  final String tone;
  final IconData? icon;
  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (tone) { 'warning' => (YkColors.warningBg, YkColors.warning), 'error' => (YkColors.errorBg, YkColors.error), _ => (YkColors.infoBg, YkColors.info) };
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(YkRadius.md)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon ?? LucideIcons.shieldCheck, size: 18, color: fg),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: TextStyle(color: fg, fontSize: 13, height: 1.4, fontWeight: FontWeight.w500))),
      ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});
  final String text;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Row(children: [Expanded(child: Text(text, style: Theme.of(context).textTheme.titleMedium)), if (trailing != null) trailing!]),
      );
}

class BadgeIcon extends StatelessWidget {
  const BadgeIcon({super.key, required this.icon, required this.count});
  final IconData icon;
  final int count;
  @override
  Widget build(BuildContext context) => Badge(isLabelVisible: count > 0, label: Text(count > 99 ? '99+' : '$count'), backgroundColor: YkColors.error, child: Icon(icon));
}
