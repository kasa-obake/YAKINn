import 'package:flutter/material.dart';

/// YAKIN tasarım belirteçleri (Tasarım Sistemi dokümanı 16.4).
class YkColors {
  static const green900 = Color(0xFF0B3325);
  static const green700 = Color(0xFF145A3E);
  static const green600 = Color(0xFF1B6E4C);
  static const green100 = Color(0xFFDDF3E8);
  static const green50 = Color(0xFFEFF9F4);
  static const mint = Color(0xFF4FD69C);
  static const white = Color(0xFFFFFFFF);
  static const n50 = Color(0xFFF4F7F5);
  static const n100 = Color(0xFFE8EFEB);
  static const n200 = Color(0xFFD5DFDA);
  static const n500 = Color(0xFF7C8A83);
  static const n600 = Color(0xFF5E6B64);
  static const n900 = Color(0xFF121D18);
  static const success = Color(0xFF027A48);
  static const warning = Color(0xFFB54708);
  static const warningBg = Color(0xFFFFF6E5);
  static const error = Color(0xFFB42318);
  static const errorBg = Color(0xFFFEF0EF);
  static const info = Color(0xFF0369A1);
  static const infoBg = Color(0xFFEAF5FC);
  static const esya = Color(0xFF166534);
  static const yardim = Color(0xFFB45309);
  static const kayip = Color(0xFFBE123C);

  static Color category(String c) => switch (c) { 'yardim' => yardim, 'kayip' => kayip, _ => esya };
}

class YkSpace {
  static const xs = 4.0, sm = 8.0, md = 12.0, lg = 16.0, xl = 24.0, xxl = 32.0;
  static const margin = 16.0;
}

class YkRadius {
  static const xs = 6.0, sm = 10.0, md = 12.0, lg = 16.0, xl = 24.0, sheet = 28.0;
}

class YkMotion {
  static const instant = Duration(milliseconds: 100);
  static const fast = Duration(milliseconds: 150);
  static const base = Duration(milliseconds: 200);
  static const medium = Duration(milliseconds: 300);
}

ThemeData ykTheme() {
  final base = ThemeData(useMaterial3: true, brightness: Brightness.light);
  final text = base.textTheme.apply(bodyColor: YkColors.n900, displayColor: YkColors.n900);
  const scheme = ColorScheme.light(
    primary: YkColors.green700,
    onPrimary: YkColors.white,
    secondary: YkColors.mint,
    onSecondary: YkColors.green900,
    surface: YkColors.white,
    onSurface: YkColors.n900,
    error: YkColors.error,
    outline: YkColors.n200,
    surfaceContainerHighest: YkColors.n100,
  );
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(YkRadius.md));
  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: YkColors.white,
    textTheme: text.copyWith(
      headlineSmall: text.headlineSmall?.copyWith(fontWeight: FontWeight.w700, fontSize: 24, height: 1.25),
      titleLarge: text.titleLarge?.copyWith(fontWeight: FontWeight.w700, fontSize: 20),
      titleMedium: text.titleMedium?.copyWith(fontWeight: FontWeight.w600, fontSize: 16),
      bodyLarge: text.bodyLarge?.copyWith(fontSize: 16, height: 1.5),
      bodyMedium: text.bodyMedium?.copyWith(fontSize: 14, height: 1.45),
      labelLarge: text.labelLarge?.copyWith(fontWeight: FontWeight.w600, fontSize: 15),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: YkColors.white,
      foregroundColor: YkColors.n900,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: text.titleLarge?.copyWith(fontWeight: FontWeight.w700, fontSize: 20, color: YkColors.n900),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: shape, backgroundColor: YkColors.green700, textStyle: text.labelLarge?.copyWith(fontWeight: FontWeight.w600)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: shape, foregroundColor: YkColors.green700, side: const BorderSide(color: YkColors.n200)),
    ),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: YkColors.green700)),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: YkColors.n50,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(YkRadius.md), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(YkRadius.md), borderSide: const BorderSide(color: YkColors.n100)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(YkRadius.md), borderSide: const BorderSide(color: YkColors.green700, width: 1.5)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(YkRadius.md), borderSide: const BorderSide(color: YkColors.error)),
      hintStyle: const TextStyle(color: YkColors.n500),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: YkColors.n50,
      selectedColor: YkColors.green700,
      side: const BorderSide(color: YkColors.n100),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: YkColors.white,
      indicatorColor: YkColors.green100,
      surfaceTintColor: Colors.transparent,
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(fontSize: 12, fontWeight: s.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500, color: s.contains(WidgetState.selected) ? YkColors.green700 : YkColors.n600)),
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(color: s.contains(WidgetState.selected) ? YkColors.green700 : YkColors.n600, size: 24)),
    ),
    dividerTheme: const DividerThemeData(color: YkColors.n100, thickness: 1, space: 1),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: YkColors.white,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(YkRadius.sheet))),
      showDragHandle: true,
    ),
    snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: YkColors.n900, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YkRadius.md))),
    listTileTheme: const ListTileThemeData(iconColor: YkColors.n600, contentPadding: EdgeInsets.symmetric(horizontal: 16)),
  );
}
