import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/errors.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    Widget promise(IconData i, String t, String b) => Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: YkColors.green50, borderRadius: BorderRadius.circular(YkRadius.sm)), child: Icon(i, color: YkColors.green700, size: 20)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 2), Text(b, style: const TextStyle(color: YkColors.n600, fontSize: 13.5))])),
          ]),
        );
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Spacer(),
            Container(width: 56, height: 56, decoration: BoxDecoration(color: YkColors.green700, borderRadius: BorderRadius.circular(YkRadius.lg)), child: const Icon(LucideIcons.mapPin, color: YkColors.mint, size: 28)),
            const SizedBox(height: 20),
            Text('YAKIN', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: YkColors.green700, letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Text('İhtiyacın varsa yakınında biri vardır.', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 28),
            promise(LucideIcons.package, 'Paylaş, ödünç ver, sat', 'Kullanmadığın eşyalar komşunun işine yarasın.'),
            promise(LucideIcons.handHeart, 'Yardım iste, yardım et', 'Alışveriş, taşıma, ders. Mahallende biri hazır.'),
            promise(LucideIcons.shieldCheck, 'Adresin gizli kalır', 'Konumun yaklaşık gösterilir, telefonun paylaşılmaz.'),
            const Spacer(),
            FilledButton(onPressed: () => context.push('/auth/phone'), child: const Text('Başla')),
            const SizedBox(height: 12),
            const Center(child: Text('Şimdilik Burdur merkezde, 18 yaş ve üzeri için.', style: TextStyle(color: YkColors.n500, fontSize: 12.5))),
          ]),
        ),
      ),
    );
  }
}

class PhoneScreen extends ConsumerStatefulWidget {
  const PhoneScreen({super.key});
  @override
  ConsumerState<PhoneScreen> createState() => _PhoneScreenState();
}

class _PhoneScreenState extends ConsumerState<PhoneScreen> {
  final _c = TextEditingController();
  bool _terms = false, _busy = false;
  String? _error;

  Future<void> _submit() async {
    setState(() { _busy = true; _error = null; });
    try {
      final r = await ref.read(sessionProvider).requestOtp(_c.text);
      if (mounted) context.push('/auth/otp', extra: {'phone': _c.text, 'terms': _terms, 'devCode': r['devCode'], 'masked': r['phoneMasked']});
    } catch (e) {
      setState(() => _error = errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final digits = _c.text.replaceAll(RegExp(r'\D'), '');
    final valid = RegExp(r'^0?5\d{9}$').hasMatch(digits);
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          Text('Telefon numaran', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text('Sana tek kullanımlık bir kod göndereceğiz. Numaran diğer kullanıcılara gösterilmez.', style: TextStyle(color: YkColors.n600)),
          const SizedBox(height: 24),
          TextField(
            controller: _c,
            autofocus: true,
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d ]')), LengthLimitingTextInputFormatter(14)],
            decoration: InputDecoration(prefixText: '+90  ', hintText: '5XX XXX XX XX', errorText: _error),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, letterSpacing: .5),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 16),
          CheckboxListTile(
            value: _terms,
            onChanged: (v) => setState(() => _terms = v ?? false),
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            title: const Text('Kullanım koşullarını ve KVKK aydınlatma metnini okudum, kabul ediyorum.', style: TextStyle(fontSize: 13.5)),
          ),
          Wrap(spacing: 4, children: [
            TextButton(onPressed: () => context.push('/legal/terms'), child: const Text('Kullanım koşulları')),
            TextButton(onPressed: () => context.push('/legal/kvkk'), child: const Text('KVKK aydınlatma metni')),
            TextButton(onPressed: () => context.push('/legal/privacy'), child: const Text('Gizlilik politikası')),
          ]),
          const SizedBox(height: 16),
          FilledButton(onPressed: valid && !_busy ? _submit : null, child: _busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Kod gönder')),
        ]),
      ),
    );
  }
}

class OtpScreen extends ConsumerStatefulWidget {
  const OtpScreen({super.key, required this.args});
  final Map<String, dynamic> args;
  @override
  ConsumerState<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends ConsumerState<OtpScreen> {
  final _c = TextEditingController();
  final _totp = TextEditingController();
  bool _needTotp = false;
  late bool _terms = widget.args['terms'] == true;
  String? _error, _devCode;
  bool _busy = false;
  int _left = 60;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _devCode = widget.args['devCode'];
    _tick();
  }

  void _tick() {
    _t?.cancel();
    _left = 60;
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _left--);
      if (_left <= 0) t.cancel();
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    _totp.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_c.text.length != 6) return;
    if (_needTotp && _totp.text.length != 6) return;
    setState(() { _busy = true; _error = null; });
    try {
      await ref.read(sessionProvider).verifyOtp(widget.args['phone'], _c.text, _terms, totpCode: _needTotp ? _totp.text : null);
    } on ApiException catch (e) {
      // İki adımlı doğrulaması açık yönetici/moderatör hesabı: SMS kodu korunur, ikinci kod istenir.
      if (e.code == 'AUTH_TOTP_REQUIRED') {
        if (mounted) setState(() => _needTotp = true);
        return;
      }
      if (e.code == 'AUTH_TOTP_INVALID') {
        if (mounted) setState(() { _error = e.message; _totp.clear(); });
        return;
      }
      if (e.code == 'AUTH_TERMS_REQUIRED' && mounted) {
        final ok = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('Koşulları onayla'),
            content: const Text('YAKIN hesabı oluşturmak için kullanım koşullarını ve KVKK aydınlatma metnini kabul etmen gerekiyor.'),
            actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kabul ediyorum'))],
          ),
        );
        if (ok == true) { _terms = true; return _verify(); }
      }
      setState(() { _error = e.message; _c.clear(); });
    } catch (e) {
      setState(() => _error = errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resend() async {
    try {
      final r = await ref.read(sessionProvider).requestOtp(widget.args['phone']);
      setState(() { _devCode = r['devCode']; _error = null; });
      _tick();
    } catch (e) {
      setState(() => _error = errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          Text('Kodu gir', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text('${widget.args['masked'] ?? widget.args['phone']} numarasına gönderdiğimiz 6 haneli kodu yaz.', style: const TextStyle(color: YkColors.n600)),
          const SizedBox(height: 24),
          TextField(
            controller: _c,
            autofocus: true,
            keyboardType: TextInputType.number,
            autofillHints: const [AutofillHints.oneTimeCode],
            textAlign: TextAlign.center,
            maxLength: 6,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.w700),
            decoration: InputDecoration(counterText: '', hintText: '------', errorText: _needTotp ? null : _error),
            onChanged: (v) { if (v.length == 6) _verify(); },
          ),
          if (_needTotp) ...[
            const SizedBox(height: 20),
            const Text('Hesabında iki adımlı doğrulama açık. Doğrulayıcı uygulamandaki 6 haneli kodu da gir.', style: TextStyle(color: YkColors.n600)),
            const SizedBox(height: 12),
            TextField(
              controller: _totp,
              autofocus: true,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              maxLength: 6,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.w700),
              decoration: InputDecoration(counterText: '', hintText: '------', labelText: 'İki adımlı doğrulama kodu', errorText: _error),
              onChanged: (v) { if (v.length == 6) _verify(); },
            ),
          ],
          if (_devCode != null) ...[
            const SizedBox(height: 12),
            SafetyBanner(text: 'Geliştirme sunucusu: SMS gönderilmedi, kod $_devCode', icon: LucideIcons.info),
          ],
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _verify, child: _busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Doğrula')),
          const SizedBox(height: 8),
          TextButton(onPressed: _left > 0 ? null : _resend, child: Text(_left > 0 ? 'Yeni kod $_left sn sonra' : 'Yeni kod gönder')),
        ]),
      ),
    );
  }
}

/// Kayıt sonrası profil tamamlama: ad, doğum yılı (18+), mahalle.
class ProfileSetupScreen extends ConsumerStatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  ConsumerState<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends ConsumerState<ProfileSetupScreen> {
  final _first = TextEditingController(), _last = TextEditingController(), _year = TextEditingController();
  int? _hood;
  String? _error;
  bool _busy = false;

  Future<void> _save() async {
    setState(() { _busy = true; _error = null; });
    try {
      await ref.read(sessionProvider).updateMe({'firstName': _first.text.trim(), 'lastName': _last.text.trim(), 'birthYear': int.tryParse(_year.text), 'neighborhoodId': _hood});
    } catch (e) {
      setState(() => _error = errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hoods = ref.watch(neighborhoodsProvider);
    final ok = _first.text.trim().length >= 2 && _year.text.length == 4 && _hood != null;
    return Scaffold(
      appBar: AppBar(title: const Text('Profilini tamamla'), actions: [TextButton(onPressed: () => ref.read(sessionProvider).signOut(), child: const Text('Çıkış'))]),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const Text('Komşuların seni adın ve soyadının baş harfiyle görür. Örneğin "Ayşe K."', style: TextStyle(color: YkColors.n600)),
          const SizedBox(height: 20),
          TextField(controller: _first, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Ad'), onChanged: (_) => setState(() {})),
          const SizedBox(height: 12),
          TextField(controller: _last, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Soyad')),
          const SizedBox(height: 12),
          TextField(controller: _year, keyboardType: TextInputType.number, maxLength: 4, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'Doğum yılı', counterText: '', helperText: 'Yalnızca yaş kontrolü için. Kimseye gösterilmez.'), onChanged: (_) => setState(() {})),
          const SizedBox(height: 20),
          Text('Mahallen', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text('Tam adresin hiçbir zaman istenmez ve gösterilmez.', style: TextStyle(color: YkColors.n600, fontSize: 13)),
          const SizedBox(height: 12),
          AsyncView(
            value: hoods,
            onRetry: () => ref.invalidate(neighborhoodsProvider),
            builder: (list) => Wrap(spacing: 8, runSpacing: 8, children: [
              for (final n in list)
                ChoiceChip(
                  label: Text(n['name']),
                  selected: _hood == n['id'],
                  showCheckmark: false,
                  labelStyle: TextStyle(color: _hood == n['id'] ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600),
                  onSelected: (_) => setState(() => _hood = n['id']),
                ),
            ]),
          ),
          if (_error != null) ...[const SizedBox(height: 16), SafetyBanner(text: _error!, tone: 'error', icon: LucideIcons.circleAlert)],
          const SizedBox(height: 24),
          FilledButton(onPressed: ok && !_busy ? _save : null, child: const Text('Devam et')),
        ]),
      ),
    );
  }
}
