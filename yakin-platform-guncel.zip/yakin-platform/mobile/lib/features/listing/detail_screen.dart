import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';
import '../safety/report_sheet.dart';

class ListingDetailScreen extends ConsumerStatefulWidget {
  const ListingDetailScreen({super.key, required this.id});
  final String id;
  @override
  ConsumerState<ListingDetailScreen> createState() => _ListingDetailScreenState();
}

class _ListingDetailScreenState extends ConsumerState<ListingDetailScreen> {
  int _page = 0;
  bool _busy = false;

  Future<void> _message(Json l) async {
    if (l['myConversationId'] != null) return context.push('/chat/${l['myConversationId']}').then((_) {});
    setState(() => _busy = true);
    try {
      final r = await ref.read(apiProvider).post<Json>('/conversations', {'listingId': widget.id});
      if (mounted) context.push('/chat/${r['id']}');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleFav(Json l) async {
    final api = ref.read(apiProvider);
    try {
      l['isFavorite'] == true ? await api.delete('/listings/${widget.id}/favorite') : await api.post('/listings/${widget.id}/favorite');
      ref.invalidate(listingProvider(widget.id));
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final v = ref.watch(listingProvider(widget.id));
    return Scaffold(
      body: AsyncView(
        value: v,
        onRetry: () => ref.invalidate(listingProvider(widget.id)),
        builder: (l) => _body(context, l),
      ),
      bottomNavigationBar: v.value == null ? null : _bar(v.value!),
    );
  }

  Widget? _bar(Json l) {
    if (l['isOwner'] == true) {
      return SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: OutlinedButton.icon(icon: const Icon(LucideIcons.listFilter, size: 18), onPressed: () => context.push('/me/listings'), label: const Text('İlanlarımda yönet'))));
    }
    if (l['status'] != 'active' && l['myConversationId'] == null) return null;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Row(children: [
          IconButton.outlined(
            tooltip: l['isFavorite'] == true ? 'Favorilerden çıkar' : 'Favorilere ekle',
            style: IconButton.styleFrom(minimumSize: const Size(52, 52), side: const BorderSide(color: YkColors.n200), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YkRadius.md))),
            onPressed: () => _toggleFav(l),
            icon: Icon(LucideIcons.heart, color: l['isFavorite'] == true ? YkColors.kayip : YkColors.n600),
          ),
          const SizedBox(width: 12),
          Expanded(child: FilledButton.icon(onPressed: _busy ? null : () => _message(l), icon: const Icon(LucideIcons.messageCircle, size: 18), label: Text(l['myConversationId'] != null ? 'Mesajlara git' : 'Mesaj gönder'))),
        ]),
      ),
    );
  }

  Widget _body(BuildContext context, Json l) {
    final media = List<Json>.from(l['media'] ?? []);
    final owner = Map<String, dynamic>.from(l['owner'] ?? {});
    final loc = l['approxLocation'] as Map;
    final details = Map<String, dynamic>.from(l['details'] ?? {});
    const detailLabels = {'condition': 'Durum', 'loanDays': 'Ödünç süresi (gün)', 'swapFor': 'Takas için', 'brand': 'Marka', 'when': 'Ne zaman', 'date': 'Tarih', 'duration': 'Süre', 'skill': 'Beceri', 'animalType': 'Hayvan', 'color': 'Renk', 'distinctive': 'Ayırt edici özellik', 'reward': 'Ödül'};
    const conditionLabels = {'yeni': 'Yeni', 'az_kullanilmis': 'Az kullanılmış', 'iyi': 'İyi', 'kullanilmis': 'Kullanılmış', 'tamir': 'Tamir gerekiyor'};
    final cat = l['category'] as String;
    return CustomScrollView(slivers: [
      SliverAppBar(
        pinned: true,
        expandedHeight: media.isEmpty ? 0 : 320,
        actions: [
          if (l['isOwner'] != true)
            PopupMenuButton<String>(
              icon: const Icon(LucideIcons.ellipsisVertical),
              onSelected: (v) {
                if (v == 'report') showReportSheet(context, ref, 'listing', l['id']);
                if (v == 'block') blockUser(context, ref, owner['id'], owner['displayName']);
              },
              itemBuilder: (_) => const [PopupMenuItem(value: 'report', child: Text('İlanı bildir')), PopupMenuItem(value: 'block', child: Text('Kullanıcıyı engelle'))],
            ),
        ],
        flexibleSpace: media.isEmpty
            ? null
            : FlexibleSpaceBar(
                background: Stack(fit: StackFit.expand, children: [
                  PageView.builder(itemCount: media.length, onPageChanged: (i) => setState(() => _page = i), itemBuilder: (_, i) => ListingImage(url: media[i]['url'], category: cat, radius: 0)),
                  if (media.length > 1)
                    Positioned(right: 12, bottom: 12, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(999)), child: Text('${_page + 1}/${media.length}', style: const TextStyle(color: Colors.white, fontSize: 12)))),
                ]),
              ),
      ),
      SliverPadding(
        padding: const EdgeInsets.all(16),
        sliver: SliverList.list(children: [
          if (l['status'] != 'active')
            Padding(padding: const EdgeInsets.only(bottom: 12), child: SafetyBanner(text: l['status'] == 'pending_review' ? 'Bu ilan inceleniyor. Onaylanınca yayına girer.' : 'Bu ilan kapandı.', tone: 'warning', icon: LucideIcons.clock)),
          Row(children: [CategoryPill(category: cat, subtype: l['subtype']), const Spacer(), Text(timeAgo(l['publishedAt'] ?? l['createdAt']), style: const TextStyle(color: YkColors.n500, fontSize: 12.5))]),
          const SizedBox(height: 10),
          Text(l['title'], style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text(priceText(l['subtype'], l['priceKurus']), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: YkColors.category(cat))),
          const SizedBox(height: 6),
          Row(children: [const Icon(LucideIcons.mapPin, size: 15, color: YkColors.n500), const SizedBox(width: 4), Text([(l['neighborhood'] as Map?)?['name'], distanceText(l['distance'])].whereType<String>().where((s) => s.isNotEmpty).join(' · '), style: const TextStyle(color: YkColors.n600))]),
          const SizedBox(height: 16),
          Text(l['description'], style: Theme.of(context).textTheme.bodyLarge),
          if (details.isNotEmpty) ...[
            const SizedBox(height: 16),
            for (final e in details.entries)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(children: [SizedBox(width: 150, child: Text(detailLabels[e.key] ?? e.key, style: const TextStyle(color: YkColors.n600))), Expanded(child: Text(e.value is bool ? (e.value ? 'Var' : 'Yok') : (conditionLabels[e.value] ?? '${e.value}'), style: const TextStyle(fontWeight: FontWeight.w600)))]),
              ),
          ],
          const SizedBox(height: 20),
          const SafetyBanner(text: 'Görüşmeyi kalabalık, açık bir yerde yap. Ürünü görmeden ödeme yapma, kapora gönderme.'),
          const SizedBox(height: 20),
          InkWell(
            onTap: () => context.push('/users/${owner['id']}'),
            borderRadius: BorderRadius.circular(YkRadius.md),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(border: Border.all(color: YkColors.n100), borderRadius: BorderRadius.circular(YkRadius.md)),
              child: Row(children: [
                Avatar(url: owner['avatarUrl'], name: owner['displayName'] ?? '', size: 44),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(owner['displayName'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Row(children: [const Icon(LucideIcons.circleCheck, size: 13, color: YkColors.success), const SizedBox(width: 4), Text('Telefon doğrulandı · ${owner['helpedCount'] ?? 0} kez yardım etti', style: const TextStyle(fontSize: 12.5, color: YkColors.n600))]),
                ])),
                const Icon(LucideIcons.chevronRight, color: YkColors.n500),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          Text('Yaklaşık konum', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(YkRadius.md),
            child: SizedBox(
              height: 160,
              child: FlutterMap(
                options: MapOptions(initialCenter: LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble()), initialZoom: 14.5, interactionOptions: const InteractionOptions(flags: InteractiveFlag.none)),
                children: [
                  TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'app.yakin.yakin'),
                  CircleLayer(circles: [CircleMarker(point: LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble()), radius: (loc['radiusM'] as num).toDouble(), useRadiusInMeter: true, color: YkColors.green700.withValues(alpha: .15), borderColor: YkColors.green700, borderStrokeWidth: 1.5)]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          const Text('Tam adres gösterilmez. Buluşma noktasını mesajlaşarak belirleyin.', style: TextStyle(color: YkColors.n500, fontSize: 12.5)),
          if (l['ownerStats'] != null) ...[
            const SizedBox(height: 20),
            Text('İstatistikler', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text('${l['ownerStats']['views']} görüntülenme · ${l['ownerStats']['conversations']} sohbet · ${l['ownerStats']['favorites']} favori', style: const TextStyle(color: YkColors.n600)),
          ],
          if ((l['similar'] as List?)?.isNotEmpty == true) ...[
            const SizedBox(height: 24),
            Text('Benzer ilanlar', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            SizedBox(
              height: 230,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: (l['similar'] as List).length,
                separatorBuilder: (_, _) => const SizedBox(width: 12),
                itemBuilder: (_, i) {
                  final s = Map<String, dynamic>.from(l['similar'][i]);
                  return SizedBox(width: 150, child: ListingCard(item: s, onTap: () => context.push('/listings/${s['id']}')));
                },
              ),
            ),
          ],
        ]),
      ),
    ]);
  }
}
