import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

const _subtypes = {
  'esya': ['ucretsiz', 'satilik', 'odunc', 'takas'],
  'yardim': ['istiyorum', 'teklif'],
  'kayip': ['kayip_esya', 'bulunan_esya', 'kayip_hayvan'],
};

/// İlan oluşturma sihirbazı: tür → fotoğraf → bilgiler → önizleme.
class CreateListingScreen extends ConsumerStatefulWidget {
  const CreateListingScreen({super.key});
  @override
  ConsumerState<CreateListingScreen> createState() => _CreateListingScreenState();
}

class _CreateListingScreenState extends ConsumerState<CreateListingScreen> {
  int _step = 0;
  String? _cat, _sub;
  final _photos = <Json>[];
  bool _uploading = false, _busy = false, _rules = false;
  final _title = TextEditingController(), _desc = TextEditingController(), _price = TextEditingController(), _extra = TextEditingController();
  String? _condition, _when, _animal;
  LatLng? _point;
  String? _error;

  bool get _photoRequired => _cat == 'esya' || _sub == 'kayip_hayvan';
  bool get _stepValid => switch (_step) {
        0 => _sub != null,
        1 => !_photoRequired || _photos.isNotEmpty,
        2 => _title.text.trim().length >= 5 && _desc.text.trim().length >= 10 && (_sub != 'satilik' || (int.tryParse(_price.text) ?? 0) > 0),
        _ => _rules,
      };

  Future<void> _pick(ImageSource src) async {
    if (_photos.length >= 8) return;
    final x = await ImagePicker().pickImage(source: src, maxWidth: 2400, imageQuality: 88);
    if (x == null) return;
    setState(() => _uploading = true);
    try {
      final r = await ref.read(apiProvider).upload(x);
      setState(() => _photos.add(r));
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Json _details() => {
        if (_condition != null) 'condition': _condition,
        if (_sub == 'odunc' && _extra.text.isNotEmpty) 'loanDays': int.tryParse(_extra.text),
        if (_sub == 'takas' && _extra.text.isNotEmpty) 'swapFor': _extra.text,
        if (_when != null) 'when': _when,
        if (_animal != null) 'animalType': _animal,
        if (_cat == 'kayip' && _extra.text.isNotEmpty) 'distinctive': _extra.text,
      };

  Future<void> _publish({bool draft = false}) async {
    setState(() { _busy = true; _error = null; });
    try {
      final r = await ref.read(apiProvider).post<Json>('/listings', {
        'category': _cat, 'subtype': _sub, 'title': _title.text.trim(), 'description': _desc.text.trim(),
        if (_sub == 'satilik') 'priceKurus': (int.tryParse(_price.text) ?? 0) * 100,
        'details': _details(), 'mediaIds': _photos.map((p) => p['id']).toList(), 'publish': !draft,
        if (_point != null) 'point': {'lat': _point!.latitude, 'lng': _point!.longitude},
      });
      ref.invalidate(myListingsProvider);
      if (!mounted) return;
      if (draft) { toast(context, 'Taslak kaydedildi.'); context.pop(); return; }
      final warnings = List<String>.from(r['warnings'] ?? []);
      toast(context, r['status'] == 'pending_review' ? 'İlanın incelemeye alındı. Onaylanınca yayına girer.' : warnings.isNotEmpty ? 'İlanın yayında. Telefon veya IBAN paylaşmamanı öneririz.' : 'İlanın yayında.');
      context.pushReplacement('/listings/${r['id']}');
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _chips(List<(String, String)> opts, String? value, void Function(String?) on) => Wrap(spacing: 8, runSpacing: 8, children: [
        for (final (v, l) in opts)
          ChoiceChip(label: Text(l), selected: value == v, showCheckmark: false, labelStyle: TextStyle(color: value == v ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600), onSelected: (s) => setState(() => on(s ? v : null))),
      ]);

  Widget _stepType() => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Ne paylaşmak istiyorsun?', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 16),
        for (final c in ['esya', 'yardim', 'kayip']) ...[
          Text(kCategoryLabel[c]!, style: TextStyle(fontWeight: FontWeight.w700, color: YkColors.category(c))),
          const SizedBox(height: 8),
          for (final s in _subtypes[c]!)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: InkWell(
                borderRadius: BorderRadius.circular(YkRadius.md),
                onTap: () => setState(() { _cat = c; _sub = s; }),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(YkRadius.md), border: Border.all(color: _sub == s ? YkColors.category(c) : YkColors.n100, width: _sub == s ? 2 : 1), color: _sub == s ? YkColors.category(c).withValues(alpha: .05) : null),
                  child: Row(children: [Icon(categoryIcon(c, s), color: YkColors.category(c)), const SizedBox(width: 12), Expanded(child: Text(kSubtypeLabel[s]!, style: const TextStyle(fontWeight: FontWeight.w600))), if (_sub == s) Icon(LucideIcons.circleCheck, color: YkColors.category(c))]),
                ),
              ),
            ),
          const SizedBox(height: 8),
        ],
      ]);

  Widget _stepPhotos() => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Fotoğraflar', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 4),
        Text(_photoRequired ? 'En az 1, en fazla 8 fotoğraf ekle. Konum bilgisi fotoğraftan otomatik silinir.' : 'İsteğe bağlı. Konum bilgisi fotoğraftan otomatik silinir.', style: const TextStyle(color: YkColors.n600)),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: [
            for (final (i, p) in _photos.indexed)
              Stack(fit: StackFit.expand, children: [
                ClipRRect(borderRadius: BorderRadius.circular(YkRadius.sm), child: CachedNetworkImage(imageUrl: p['url'], fit: BoxFit.cover)),
                if (i == 0) Positioned(left: 4, bottom: 4, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: YkColors.green700, borderRadius: BorderRadius.circular(4)), child: const Text('Kapak', style: TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)))),
                Positioned(right: 2, top: 2, child: IconButton.filled(iconSize: 14, constraints: const BoxConstraints.tightFor(width: 28, height: 28), padding: EdgeInsets.zero, style: IconButton.styleFrom(backgroundColor: Colors.black54), tooltip: 'Kaldır', onPressed: () => setState(() => _photos.removeAt(i)), icon: const Icon(LucideIcons.x, color: Colors.white))),
              ]),
            if (_photos.length < 8)
              InkWell(
                borderRadius: BorderRadius.circular(YkRadius.sm),
                onTap: _uploading ? null : () => showModalBottomSheet(
                  context: context,
                  builder: (c) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    ListTile(leading: const Icon(LucideIcons.camera), title: const Text('Fotoğraf çek'), onTap: () { Navigator.pop(c); _pick(ImageSource.camera); }),
                    ListTile(leading: const Icon(LucideIcons.image), title: const Text('Galeriden seç'), onTap: () { Navigator.pop(c); _pick(ImageSource.gallery); }),
                  ])),
                ),
                child: Container(
                  decoration: BoxDecoration(color: YkColors.n50, borderRadius: BorderRadius.circular(YkRadius.sm), border: Border.all(color: YkColors.n200)),
                  child: Center(child: _uploading ? const CircularProgressIndicator(strokeWidth: 2) : const Column(mainAxisSize: MainAxisSize.min, children: [Icon(LucideIcons.camera, color: YkColors.green700), SizedBox(height: 4), Text('Ekle', style: TextStyle(fontWeight: FontWeight.w600, color: YkColors.green700))])),
                ),
              ),
          ],
        ),
      ]);

  Widget _stepDetails() {
    final hood = ref.read(sessionProvider).me?['neighborhood'] as Map?;
    final hoods = ref.watch(neighborhoodsProvider).value ?? [];
    final h = hoods.where((x) => x['id'] == hood?['id']).firstOrNull;
    final center = h == null ? const LatLng(37.721, 30.2895) : LatLng((h['center']['lat'] as num).toDouble(), (h['center']['lng'] as num).toDouble());
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Bilgiler', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 16),
      TextField(controller: _title, maxLength: 80, decoration: const InputDecoration(labelText: 'Başlık', hintText: 'Örneğin: Çocuk bisikleti, 16 jant'), onChanged: (_) => setState(() {})),
      const SizedBox(height: 8),
      TextField(controller: _desc, maxLength: 1000, maxLines: 5, minLines: 3, decoration: const InputDecoration(labelText: 'Açıklama', hintText: 'Durumu, teslim şekli, uygun olduğun saatler...', alignLabelWithHint: true), onChanged: (_) => setState(() {})),
      if (_sub == 'satilik') ...[
        const SizedBox(height: 8),
        TextField(controller: _price, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'Fiyat', suffixText: '₺'), onChanged: (_) => setState(() {})),
      ],
      if (_cat == 'esya') ...[
        const SizedBox(height: 16),
        const Text('Durum', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        _chips([('yeni', 'Yeni'), ('az_kullanilmis', 'Az kullanılmış'), ('iyi', 'İyi'), ('kullanilmis', 'Kullanılmış'), ('tamir', 'Tamir gerekiyor')], _condition, (v) => _condition = v),
      ],
      if (_sub == 'odunc' || _sub == 'takas') ...[
        const SizedBox(height: 16),
        TextField(controller: _extra, keyboardType: _sub == 'odunc' ? TextInputType.number : TextInputType.text, decoration: InputDecoration(labelText: _sub == 'odunc' ? 'En fazla kaç gün?' : 'Ne ile takas edersin?')),
      ],
      if (_cat == 'yardim') ...[
        const SizedBox(height: 16),
        const Text('Ne zaman?', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        _chips([('bugun', 'Bugün'), ('bu_hafta', 'Bu hafta'), ('esnek', 'Esnek')], _when, (v) => _when = v),
        const SizedBox(height: 12),
        const SafetyBanner(text: 'Evine yabancı birini çağırmak yerine ortak bir noktada buluşmayı tercih et.'),
      ],
      if (_cat == 'kayip') ...[
        if (_sub == 'kayip_hayvan') ...[
          const SizedBox(height: 16),
          _chips([('kedi', 'Kedi'), ('kopek', 'Köpek'), ('kus', 'Kuş'), ('diger', 'Diğer')], _animal, (v) => _animal = v),
        ],
        const SizedBox(height: 16),
        TextField(controller: _extra, decoration: const InputDecoration(labelText: 'Ayırt edici özellik (isteğe bağlı)')),
        const SizedBox(height: 16),
        const Text('Yaklaşık nerede?', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        const Text('Haritaya dokun. Bu nokta kimseye gösterilmez; ilan 150-300 m uzaklaştırılmış bir noktada görünür.', style: TextStyle(color: YkColors.n600, fontSize: 12.5)),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(YkRadius.md),
          child: SizedBox(
            height: 200,
            child: FlutterMap(
              options: MapOptions(initialCenter: center, initialZoom: 15, onTap: (_, p) => setState(() => _point = p)),
              children: [
                TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'app.yakin.yakin'),
                if (_point != null) MarkerLayer(markers: [Marker(point: _point!, width: 32, height: 32, child: const Icon(LucideIcons.mapPin, color: YkColors.kayip, size: 32))]),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 16),
      Text('Mahalle: ${hood?['name'] ?? ''}', style: const TextStyle(color: YkColors.n600)),
    ]);
  }

  Widget _stepReview() => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Önizleme', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 16),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 96, height: 96, child: ListingImage(url: _photos.firstOrNull?['url'], category: _cat!, subtype: _sub)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CategoryPill(category: _cat!, subtype: _sub!),
            const SizedBox(height: 6),
            Text(_title.text, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 4),
            Text(priceText(_sub!, _sub == 'satilik' ? (int.tryParse(_price.text) ?? 0) * 100 : null), style: TextStyle(fontWeight: FontWeight.w700, color: YkColors.category(_cat!))),
          ])),
        ]),
        const SizedBox(height: 12),
        Text(_desc.text, style: const TextStyle(color: YkColors.n600)),
        const SizedBox(height: 20),
        if (RegExp(r'0?5\d{2}\s?\d{3}\s?\d{2}\s?\d{2}').hasMatch(_desc.text))
          const Padding(padding: EdgeInsets.only(bottom: 12), child: SafetyBanner(text: 'Açıklamada telefon numarası var gibi görünüyor. YAKIN mesajlaşması numaranı gizli tutar.', tone: 'warning')),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _rules,
          onChanged: (v) => setState(() => _rules = v ?? false),
          title: const Text('Yasaklı ürün içermediğini ve topluluk kurallarına uygun olduğunu onaylıyorum.', style: TextStyle(fontSize: 13.5)),
        ),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: SafetyBanner(text: _error!, tone: 'error', icon: LucideIcons.circleAlert)),
      ]);

  @override
  Widget build(BuildContext context) {
    final steps = [_stepType, _stepPhotos, _stepDetails, _stepReview];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(tooltip: 'Kapat', icon: const Icon(LucideIcons.x), onPressed: () => context.pop()),
        title: Text('İlan ver · ${_step + 1}/4'),
        actions: [if (_step >= 2 && _title.text.trim().isNotEmpty) TextButton(onPressed: _busy ? null : () => _publish(draft: true), child: const Text('Taslak'))],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(3), child: LinearProgressIndicator(value: (_step + 1) / 4, minHeight: 3, backgroundColor: YkColors.n100)),
      ),
      body: AnimatedSwitcher(duration: YkMotion.base, child: KeyedSubtree(key: ValueKey(_step), child: steps[_step]())),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            if (_step > 0) ...[Expanded(child: OutlinedButton(onPressed: () => setState(() => _step--), child: const Text('Geri'))), const SizedBox(width: 12)],
            Expanded(
              flex: 2,
              child: FilledButton(
                onPressed: !_stepValid || _busy ? null : () => _step == 3 ? _publish() : setState(() => _step++),
                child: Text(_step == 3 ? 'Yayınla' : 'Devam'),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
