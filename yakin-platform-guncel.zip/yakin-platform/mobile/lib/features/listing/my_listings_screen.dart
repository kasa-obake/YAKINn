import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

const _statusLabel = {'active': 'Yayında', 'pending_review': 'İncelemede', 'closed': 'Kapandı', 'draft': 'Taslak', 'removed': 'Kaldırıldı', 'expired': 'Süresi doldu'};

class MyListingsScreen extends ConsumerWidget {
  const MyListingsScreen({super.key});

  Future<void> _act(BuildContext context, WidgetRef ref, Future<void> Function() f, String ok) async {
    try {
      await f();
      ref.invalidate(myListingsProvider);
      if (context.mounted) toast(context, ok);
    } catch (e) {
      if (context.mounted) toast(context, errorText(e));
    }
  }

  Future<void> _close(BuildContext context, WidgetRef ref, Json l) async {
    final api = ref.read(apiProvider);
    final convs = (await api.get<Json>('/conversations', {'filter': 'mine'}))['items'] as List;
    final people = convs.where((c) => c['listing']['id'] == l['id']).map((c) => Map<String, dynamic>.from(c['other'] ?? {})).where((o) => o['id'] != null).toList();
    if (!context.mounted) return;
    String reason = 'delivered';
    String? to;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('İlanı kapat', style: Theme.of(c).textTheme.titleLarge),
              const SizedBox(height: 12),
              RadioGroup<String>(
                groupValue: reason,
                onChanged: (v) => set(() => reason = v!),
                child: Column(children: [
                  RadioListTile(value: 'delivered', contentPadding: EdgeInsets.zero, title: Text(l['category'] == 'yardim' ? 'Yardımlaşma gerçekleşti' : l['category'] == 'kayip' ? 'Sahibine ulaştı' : 'Teslim edildi')),
                  const RadioListTile(value: 'cancelled', contentPadding: EdgeInsets.zero, title: Text('Vazgeçtim')),
                ]),
              ),
              if (reason == 'delivered' && people.isNotEmpty) ...[
                const SizedBox(height: 8),
                const Text('Kiminle gerçekleşti? Değerlendirme isteği iki tarafa da gider.', style: TextStyle(color: YkColors.n600, fontSize: 13)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final p in people)
                    ChoiceChip(
                      avatar: Avatar(url: p['avatarUrl'], name: p['displayName'] ?? '?', size: 24),
                      label: Text(p['displayName'] ?? ''),
                      selected: to == p['id'],
                      showCheckmark: false,
                      onSelected: (s) => set(() => to = s ? p['id'] : null),
                    ),
                ]),
              ],
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kapat'))),
            ]),
          ),
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    await _act(context, ref, () => api.post('/listings/${l['id']}/close', {'reason': reason, 'deliveredToUserId': ?to}), 'İlan kapatıldı.');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final api = ref.read(apiProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('İlanlarım')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => context.push('/create'), icon: const Icon(LucideIcons.plus), label: const Text('İlan ver')),
      body: AsyncView<List<Json>>(
        value: ref.watch(myListingsProvider),
        onRetry: () => ref.invalidate(myListingsProvider),
        builder: (items) => items.isEmpty
            ? EmptyState(icon: LucideIcons.package, title: 'Henüz ilanın yok', body: 'Kullanmadığın bir eşyayı paylaş ya da komşularından yardım iste.', action: FilledButton(onPressed: () => context.push('/create'), child: const Text('İlk ilanını ver')))
            : RefreshIndicator(
                onRefresh: () async => ref.invalidate(myListingsProvider),
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  itemCount: items.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final l = items[i];
                    final status = l['status'] as String;
                    final exp = l['expiresAt'] == null ? null : DateTime.parse(l['expiresAt']).difference(DateTime.now()).inDays;
                    return Card(
                      margin: EdgeInsets.zero,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(YkRadius.md),
                        onTap: () => context.push('/listings/${l['id']}'),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            SizedBox(width: 72, height: 72, child: ListingImage(url: l['coverUrl'], category: l['category'], subtype: l['subtype'], radius: 10)),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                _StatusChip(status),
                                const Spacer(),
                                PopupMenuButton<String>(
                                  icon: const Icon(LucideIcons.ellipsisVertical, size: 18),
                                  padding: EdgeInsets.zero,
                                  onSelected: (v) => switch (v) {
                                    'close' => _close(context, ref, l),
                                    'reopen' => _act(context, ref, () => api.post('/listings/${l['id']}/reopen'), 'İlan yeniden yayında.'),
                                    'extend' => _act(context, ref, () => api.post('/listings/${l['id']}/extend'), 'Süre uzatıldı.'),
                                    'delete' => showDialog<bool>(
                                        context: context,
                                        builder: (c) => AlertDialog(
                                          title: const Text('İlan silinsin mi?'),
                                          content: const Text('Bu işlem geri alınamaz. Sohbetler salt okunur kalır.'),
                                          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sil'))],
                                        ),
                                      ).then((ok) { if (ok == true && context.mounted) _act(context, ref, () => api.delete('/listings/${l['id']}'), 'İlan silindi.'); }),
                                    _ => null,
                                  },
                                  itemBuilder: (_) => [
                                    if (status == 'active') const PopupMenuItem(value: 'close', child: Text('Kapat')),
                                    if (status == 'active' && exp != null && exp <= 7) const PopupMenuItem(value: 'extend', child: Text('Süreyi uzat')),
                                    if (status == 'closed') const PopupMenuItem(value: 'reopen', child: Text('Yeniden yayınla')),
                                    const PopupMenuItem(value: 'delete', child: Text('Sil')),
                                  ],
                                ),
                              ]),
                              Text(l['title'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 4),
                              Text('${l['views'] ?? 0} görüntülenme · ${l['conversations'] ?? 0} sohbet${status == 'active' && exp != null ? ' · $exp gün kaldı' : ''}', style: const TextStyle(fontSize: 12.5, color: YkColors.n600)),
                            ])),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip(this.status);
  final String status;
  @override
  Widget build(BuildContext context) {
    final color = switch (status) { 'active' => YkColors.green700, 'pending_review' => YkColors.warning, 'removed' => YkColors.error, _ => YkColors.n500 };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: .1), borderRadius: BorderRadius.circular(6)),
      child: Text(_statusLabel[status] ?? status, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w700)),
    );
  }
}

/// Teslim sonrası değerlendirme.
class ReviewScreen extends ConsumerStatefulWidget {
  const ReviewScreen({super.key, required this.listingId, this.toName});
  final String listingId;
  final String? toName;
  @override
  ConsumerState<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends ConsumerState<ReviewScreen> {
  int _rating = 0;
  final _tags = <String>{};
  final _comment = TextEditingController();
  bool _busy = false;

  Future<void> _submit() async {
    setState(() => _busy = true);
    try {
      await ref.read(apiProvider).post('/listings/${widget.listingId}/reviews', {'rating': _rating, 'tags': _tags.toList(), if (_comment.text.trim().isNotEmpty) 'comment': _comment.text.trim()});
      ref.invalidate(pendingReviewsProvider);
      ref.read(sessionProvider).refreshBadges();
      if (mounted) { toast(context, 'Teşekkürler. Değerlendirmen, karşı taraf da değerlendirdiğinde veya 7 gün sonra yayınlanır.'); context.pop(); }
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Değerlendir')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(widget.toName == null ? 'Deneyimin nasıldı?' : '${widget.toName} ile deneyimin nasıldı?', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 1; i <= 5; i++)
            IconButton(
              iconSize: 40,
              tooltip: '$i yıldız',
              onPressed: () => setState(() => _rating = i),
              icon: Icon(LucideIcons.star, color: i <= _rating ? YkColors.warning : YkColors.n200),
            ),
        ]),
        const SizedBox(height: 16),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in kReviewTags.entries)
            FilterChip(label: Text(e.value), selected: _tags.contains(e.key), onSelected: (s) => setState(() => s ? _tags.add(e.key) : _tags.remove(e.key))),
        ]),
        const SizedBox(height: 16),
        TextField(controller: _comment, maxLength: 300, maxLines: 3, decoration: const InputDecoration(labelText: 'Yorum (isteğe bağlı)')),
        const SizedBox(height: 8),
        const Text('Değerlendirmeler karşılıklıdır; iki taraf da yazınca veya 7 gün dolunca birlikte yayınlanır.', style: TextStyle(color: YkColors.n600, fontSize: 12.5)),
      ]),
      bottomNavigationBar: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: FilledButton(onPressed: _rating == 0 || _busy ? null : _submit, child: const Text('Gönder')))),
    );
  }
}

class PendingReviewsScreen extends ConsumerWidget {
  const PendingReviewsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bekleyen değerlendirmeler')),
      body: AsyncView<List<Json>>(
        value: ref.watch(pendingReviewsProvider),
        onRetry: () => ref.invalidate(pendingReviewsProvider),
        builder: (items) => items.isEmpty
            ? const EmptyState(icon: LucideIcons.star, title: 'Bekleyen değerlendirme yok', body: 'Bir teslimleşme tamamlandığında burada görünür.')
            : ListView(children: [
                for (final r in items)
                  ListTile(
                    leading: Avatar(url: r['to']?['avatarUrl'], name: r['to']?['displayName'] ?? '?'),
                    title: Text(r['title'] ?? ''),
                    subtitle: Text('${r['to']?['displayName'] ?? ''} · ${timeAgo(r['closedAt'])}'),
                    trailing: const Icon(LucideIcons.chevronRight),
                    onTap: () => context.push('/listings/${r['listingId']}/review', extra: r['to']?['displayName']),
                  ),
              ]),
      ),
    );
  }
}
