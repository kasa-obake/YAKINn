import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../ui/theme.dart';
import '../../ui/widgets.dart';

/// Hukuki metinler TASLAKTIR. Yayından önce bir hukuk danışmanı tarafından gözden geçirilmeli,
/// [köşeli parantez] içindeki yerler doldurulmalı ve ardından bu değer false yapılmalıdır.
/// true iken her metnin başında "taslak" uyarısı gösterilir.
const bool kLegalIsDraft = true;

class LegalSection {
  const LegalSection(this.title, this.body);
  final String title, body;
}

class LegalDoc {
  const LegalDoc(this.title, this.updated, this.sections);
  final String title, updated;
  final List<LegalSection> sections;
}

const Map<String, LegalDoc> kLegalDocs = {
  'terms': LegalDoc('Kullanım koşulları', '[tarih]', [
    LegalSection('1. Kapsam', "YAKIN, [İşletme adı] tarafından işletilen; Burdur merkezde yaşayan kişilerin eşya paylaşması, ödünç vermesi, satması ve birbirine yardım etmesi için hazırlanmış bir ilan ve mesajlaşma uygulamasıdır. Uygulamayı kullanarak bu koşulları kabul etmiş olursun."),
    LegalSection('2. Üyelik', "YAKIN 18 yaş ve üzeri kişiler içindir. Hesap, telefon numarasına gönderilen tek kullanımlık kodla açılır. Verdiğin bilgilerin doğru olması gerekir. Doğum yılı sonradan değiştirilemez. Bir kişi bir hesap kullanabilir. Hesabının güvenliğinden sen sorumlusun."),
    LegalSection('3. YAKIN’ın rolü', "YAKIN yalnızca kullanıcıları buluşturan bir aracıdır. Eşyaların satışı, ödünç verilmesi veya yardım anlaşmaları kullanıcılar arasında yapılır; YAKIN bu işlemlerin tarafı değildir. Uygulama içinde ödeme alınmaz. Ürünün durumu, teslimi ve ödeme konusunda sorumluluk ilgili kullanıcılara aittir."),
    LegalSection('4. İlan ve içerik kuralları', "İlanların doğru ve güncel olmalı, fotoğraflar ilanla ilgili olmalıdır. Silah, uyuşturucu, reçeteli ilaç ve sahte belge ilanları yasaktır. Ön ödeme/kapora talepleri ve canlı hayvan satışı içeren ilanlar moderatör incelemesine alınabilir. Nefret söylemi, taciz, aldatıcı içerik, başkasının kişisel bilgisini ve telif hakkıyla korunan içeriği izinsiz paylaşmak yasaktır."),
    LegalSection('5. Güvenli buluşma', "Eşya alışverişi ve teslimlerinde kalabalık, aydınlık ve herkese açık yerleri tercih et. Tanımadığın kişilere ön ödeme yapma. Kendini güvende hissetmediğin bir durumda görüşmeyi bırak ve kullanıcıyı bildir. Acil durumlarda 112’yi ara."),
    LegalSection('6. Mesajlaşma ve davranış', "Diğer kullanıcılara saygılı davranmanı bekleriz. Taciz, spam ve tehdit yasaktır. İstemediğin kişileri engelleyebilir, uygunsuz içerik ve davranışları bildirebilirsin."),
    LegalSection('7. Moderasyon ve itiraz', "İçerikler otomatik kurallarla ve moderatörler tarafından denetlenebilir. Kurallara aykırı içerik için uyarı verilebilir, ilan kaldırılabilir, hesap geçici olarak askıya alınabilir veya kapatılabilir. Karar ve gerekçesi sana bildirilir. Karara, bildirimde belirtilen süre içinde uygulama üzerinden itiraz edebilirsin. İtirazı, kararı veren moderatörden farklı biri değerlendirir."),
    LegalSection('8. Hesabın silinmesi', "Hesabını Ayarlar bölümünden silebilirsin. Silme talebinden sonra 30 gün beklenir; bu sürede tekrar giriş yaparsan talep iptal olur. Süre dolunca kişisel verilerin silinir veya anonimleştirilir (ayrıntılar KVKK aydınlatma metninde)."),
    LegalSection('9. Sorumluluğun sınırı', "[Hukuk danışmanıyla belirlenecek: hizmetin kesintisiz olacağı garanti edilmez, kullanıcı içeriklerinden ve kullanıcılar arası anlaşmalardan doğan zararlar için sorumluluk sınırı vb.]"),
    LegalSection('10. Değişiklik, uygulanacak hukuk ve iletişim', "Koşullar güncellenebilir; önemli değişiklikler uygulama içinde duyurulur. Bu koşullara Türkiye Cumhuriyeti hukuku uygulanır, uyuşmazlıklarda [Burdur] mahkemeleri ve icra daireleri yetkilidir. İletişim: [e-posta adresi], [adres]."),
  ]),
  'kvkk': LegalDoc('KVKK aydınlatma metni', '[tarih]', [
    LegalSection('1. Veri sorumlusu', "6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) uyarınca kişisel verilerin veri sorumlusu [İşletme adı / unvan], [adres], [e-posta adresi] tarafından işlenir."),
    LegalSection('2. İşlenen kişisel veriler', "Kimlik ve iletişim: ad, soyad, telefon numarası, doğum yılı. Konum: seçtiğin mahalle ve ilanlar için yaklaşık konum (tam adresin istenmez ve gösterilmez). İçerik: ilanlar, fotoğraflar, mesajlar, değerlendirmeler, şikayet ve itirazlar. İşlem güvenliği: IP adresi, cihaz türü, oturum ve denetim kayıtları. Tercihler: bildirim ve gizlilik ayarları; bildirimler açıldığında cihaz bildirim belirteci."),
    LegalSection('3. İşleme amaçları', "Hesabın oluşturulması ve telefonunun doğrulanması; ilan, mesajlaşma ve değerlendirme hizmetlerinin sunulması; platform güvenliğinin sağlanması, kötüye kullanımın ve dolandırıcılığın önlenmesi; içerik denetimi ve şikayetlerin çözümü; destek taleplerinin yanıtlanması; hukuki yükümlülüklerin yerine getirilmesi."),
    LegalSection('4. Hukuki sebepler', "Verilerin KVKK madde 5/2 kapsamında; sözleşmenin kurulması ve ifası, hukuki yükümlülüğün yerine getirilmesi, bir hakkın tesisi, kullanılması veya korunması ve veri sorumlusunun meşru menfaati sebeplerine dayanılarak işlenir. Açık rıza gerektiren işlemler için ayrıca rızan alınır. [Hukuk danışmanı onaylayacak]"),
    LegalSection('5. Verilerin aktarıldığı taraflar', "Doğrulama kodu göndermek için SMS hizmet sağlayıcısına ([Netgsm]) telefon numaran; barındırma ve altyapı hizmeti için [sağlayıcı adı, veri merkezi ülkesi]; yasal talep halinde yetkili kamu kurum ve kuruluşlarına veri aktarılabilir. [Yurt dışına aktarım varsa KVKK madde 9 kapsamında burada belirtilecek.]"),
    LegalSection('6. Toplama yöntemi', "Verilerin uygulama üzerinden elektronik ortamda, senin girdiğin bilgilerle ve uygulamayı kullanman sırasında otomatik olarak toplanır."),
    LegalSection('7. Saklama süreleri', "Hesabın açık olduğu sürece saklanır. Hesap silme talebinden 30 gün sonra kişisel verilerin silinir veya anonimleştirilir: profil, telefon, mesaj metinleri, fotoğraflar, ilan içerikleri, favoriler, engeller, bildirimler ve destek talepleri. Doğrulama kodları 2 gün, bildirimler 180 gün sonra silinir. Moderasyon kayıtları ve denetim günlükleri yasal yükümlülükler için anonim kimlikle [saklama süresi] boyunca tutulur."),
    LegalSection('8. Haklarınız', "KVKK madde 11 uyarınca; verilerinin işlenip işlenmediğini öğrenme, bilgi talep etme, işleme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme, aktarıldığı kişileri bilme, düzeltilmesini veya silinmesini isteme, bu işlemlerin aktarılan üçüncü kişilere bildirilmesini isteme, işlemeye itiraz etme ve zararın giderilmesini talep etme haklarına sahipsin."),
    LegalSection('9. Başvuru', "Haklarını kullanmak için Ayarlar bölümündeki “Verilerimi indir” ve “Hesabımı sil” seçeneklerini, “Destek ile iletişim” formunu veya [e-posta adresi] adresini kullanabilirsin. Başvurular en geç 30 gün içinde yanıtlanır."),
  ]),
  'privacy': LegalDoc('Gizlilik politikası', '[tarih]', [
    LegalSection('Kısaca', "YAKIN seni komşularınla buluşturur; ama kim olduğunu ve nerede yaşadığını sana sormadan göstermez."),
    LegalSection('Başkalarının göreceği bilgiler', "Diğer kullanıcılar seni adın ve soyadının baş harfiyle görür (örneğin “Ayşe K.”). Telefon numaran gösterilmez. Mahalle adını profilinde gizleyebilirsin. Tam adresin hiçbir zaman istenmez ve gösterilmez; ilanlar yalnızca yaklaşık mesafeyle görünür. Canlı konum paylaşımı yoktur."),
    LegalSection('Paylaştığın içerik', "İlanların ve ilan fotoğrafların diğer kullanıcılar tarafından görülebilir. Mesajların yalnızca yazıştığın kişiyle paylaşılır. Okundu bilgisini ve yanıt süreni göstermeyi Ayarlar bölümünden kapatabilirsin. İstemediğin kullanıcıları engelleyebilirsin."),
    LegalSection('Reklam ve izleme', "Uygulamada reklam yoktur ve verilerin reklam amacıyla paylaşılmaz. [Analitik veya üçüncü taraf araç eklenirse burada belirtilecek.]"),
    LegalSection('Güvenlik', "Uygulama ile sunucu arasındaki iletişim şifrelidir (HTTPS). Oturum anahtarların cihazında güvenli depolamada tutulur. Yönetici ve moderatör hesapları için iki adımlı doğrulama kullanılabilir."),
    LegalSection('Verilerin üzerindeki kontrolün', "Ayarlar bölümünden verilerini indirebilir ve hesabını silebilirsin. Ayrıntılar için KVKK aydınlatma metnine bak."),
    LegalSection('İletişim', "Sorların için Ayarlar > Destek ile iletişim veya [e-posta adresi]."),
  ]),
};

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.kind});
  final String kind;

  @override
  Widget build(BuildContext context) {
    final doc = kLegalDocs[kind];
    return Scaffold(
      appBar: AppBar(title: Text(doc?.title ?? 'Metin bulunamadı')),
      body: doc == null
          ? const EmptyState(icon: LucideIcons.scrollText, title: 'Metin bulunamadı', body: 'Bu sayfa mevcut değil.')
          : SafeArea(
              child: ListView(padding: const EdgeInsets.all(20), children: [
                if (kLegalIsDraft) ...[
                  const SafetyBanner(text: 'Bu metin taslaktır ve henüz hukuki incelemeden geçmemiştir.'),
                  const SizedBox(height: 12),
                ],
                Text('Son güncelleme: ${doc.updated}', style: const TextStyle(color: YkColors.n500, fontSize: 12.5)),
                const SizedBox(height: 14),
                for (final s in doc.sections) ...[
                  Text(s.title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(s.body, style: const TextStyle(height: 1.5, color: YkColors.n900)),
                  const SizedBox(height: 18),
                ],
              ]),
            ),
    );
  }
}
