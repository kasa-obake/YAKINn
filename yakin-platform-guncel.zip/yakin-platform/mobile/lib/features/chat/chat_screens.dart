import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';
import '../safety/report_sheet.dart';

/// Mesajlar sekmesi: tümü / ilanlarım / ilgilendiklerim.
class ConversationsScreen extends ConsumerStatefulWidget {
  const ConversationsScreen({super.key});
  @override
  ConsumerState<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends ConsumerState<ConversationsScreen> {
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = ref.read(sessionProvider).events.listen((e) {
      if (e.name == 'message:new' || e.name == 'conversation:updated' || e.name == 'message:read') {
        for (final f in ['all', 'mine', 'interested']) {
          ref.invalidate(conversationsProvider(f));
        }
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Mesajlar'),
          bottom: const TabBar(tabs: [Tab(text: 'Tümü'), Tab(text: 'İlanlarım'), Tab(text: 'İlgilendiklerim')]),
        ),
        body: const TabBarView(children: [_ConvList('all'), _ConvList('mine'), _ConvList('interested')]),
      ),
    );
  }
}

class _ConvList extends ConsumerWidget {
  const _ConvList(this.filter);
  final String filter;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final v = ref.watch(conversationsProvider(filter));
    return AsyncView<List<Json>>(
      value: v,
      onRetry: () => ref.invalidate(conversationsProvider(filter)),
      builder: (items) => items.isEmpty
          ? const EmptyState(icon: LucideIcons.messageCircle, title: 'Henüz mesaj yok', body: 'Bir ilana yazdığında veya biri ilanına yazdığında sohbetler burada görünür.')
          : RefreshIndicator(
              onRefresh: () async => ref.invalidate(conversationsProvider(filter)),
              child: ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_, _) => const Divider(height: 1, indent: 76),
                itemBuilder: (_, i) {
                  final c = items[i];
                  final other = c['other'] as Map? ?? {};
                  final last = c['lastMessage'] as Map?;
                  final unread = (c['unread'] ?? 0) as int;
                  final listing = c['listing'] as Map;
                  final lastText = last == null ? 'Sohbet başladı' : last['deleted'] == true ? 'Mesaj silindi' : last['kind'] == 'image' ? 'Fotoğraf' : last['kind'] == 'system' ? last['body'] : last['body'];
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    leading: Stack(clipBehavior: Clip.none, children: [
                      Avatar(url: other['avatarUrl'], name: other['displayName'] ?? '?', size: 48),
                      Positioned(right: -4, bottom: -4, child: SizedBox(width: 24, height: 24, child: ListingImage(url: listing['coverUrl'], category: listing['category'], subtype: listing['subtype'], radius: 6))),
                    ]),
                    title: Row(children: [
                      Expanded(child: Text(other['displayName'] ?? 'Kullanıcı', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: unread > 0 ? FontWeight.w800 : FontWeight.w600))),
                      if (c['muted'] == true) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(LucideIcons.bellOff, size: 14, color: YkColors.n500)),
                      Text(timeAgo(c['lastMessageAt']), style: const TextStyle(fontSize: 12, color: YkColors.n500)),
                    ]),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(listing['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: YkColors.green700, fontWeight: FontWeight.w600)),
                      Row(children: [
                        Expanded(child: Text(lastText ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: unread > 0 ? YkColors.n900 : YkColors.n600))),
                        if (unread > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: YkColors.green700, borderRadius: BorderRadius.circular(10)),
                            child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700)),
                          ),
                      ]),
                    ]),
                    onTap: () => context.push('/chat/${c['id']}').then((_) {
                      ref.invalidate(conversationsProvider(filter));
                      ref.read(sessionProvider).refreshBadges();
                    }),
                  );
                },
              ),
            ),
    );
  }
}

const _warningText = {
  'payment': 'Ürünü görmeden kapora, havale veya ön ödeme yapma. YAKIN hiçbir zaman ödeme aracılığı yapmaz.',
  'link': 'Bu mesajda bağlantı var. Tanımadığın bağlantılara tıklama, kişisel bilgi girme.',
  'contact': 'Uygulama dışına geçmek, yaşanabilecek sorunlarda seni korumamızı zorlaştırır.',
  'shipping': 'Kargo ile gönderim yerine yüz yüze, kalabalık bir noktada teslimleşmeni öneririz.',
};

const _readOnlyText = {
  'blocked': 'Bu kullanıcıyla aranızda engelleme var. Mesaj gönderilemez.',
  'listing_removed': 'İlan kaldırıldığı için sohbet salt okunur.',
  'listing_closed': 'İlan kapanalı 7 günden fazla oldu. Sohbet salt okunur.',
};

/// Tek sohbet ekranı. Gerçek zamanlı mesaj, okundu ve yazıyor bilgisi alır.
class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key, required this.id});
  final String id;
  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  Json? _conv;
  final _msgs = <Json>[];
  String? _cursor;
  bool _loadingMore = false, _sending = false, _typing = false;
  Object? _error;
  final _input = TextEditingController();
  final _scroll = ScrollController();
  StreamSubscription? _sub;
  Timer? _typingTimer;
  DateTime _lastTypingSent = DateTime(2000);

  Api get _api => ref.read(apiProvider);
  String get _meId => ref.read(sessionProvider).me?['id'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 200) _more();
    });
    _sub = ref.read(sessionProvider).events.listen(_onEvent);
  }

  void _onEvent(dynamic e) {
    final d = e.data is Map ? Map<String, dynamic>.from(e.data) : <String, dynamic>{};
    final cid = d['conversationId'] ?? (d['message'] is Map ? d['message']['conversationId'] : null);
    if (cid != widget.id) return;
    switch (e.name) {
      case 'message:new':
        final m = Map<String, dynamic>.from(d['message'] ?? d);
        if (_msgs.any((x) => x['id'] == m['id'])) return;
        setState(() { _msgs.insert(0, m); _typing = false; });
        if (m['senderId'] != _meId) _markRead();
      case 'message:read':
        setState(() {
          for (final m in _msgs) {
            if (m['senderId'] == _meId) m['readAt'] ??= DateTime.now().toIso8601String();
          }
        });
      case 'message:deleted':
        setState(() {
          for (final m in _msgs) {
            if (m['id'] == d['messageId'] || m['id'] == d['id']) { m['deleted'] = true; m['body'] = ''; m['imageUrl'] = null; }
          }
        });
      case 'typing':
        if (d['userId'] == _meId) return;
        setState(() => _typing = true);
        _typingTimer?.cancel();
        _typingTimer = Timer(const Duration(seconds: 4), () { if (mounted) setState(() => _typing = false); });
    }
  }

  Future<void> _load() async {
    try {
      final c = await _api.get<Json>('/conversations/${widget.id}');
      final r = await _api.get<Json>('/conversations/${widget.id}/messages', {'limit': 30});
      setState(() {
        _conv = c;
        _msgs..clear()..addAll(List<Json>.from(r['items']).reversed);
        _cursor = r['nextCursor'];
        _error = null;
      });
      _markRead();
    } catch (e) {
      setState(() => _error = e);
    }
  }

  Future<void> _more() async {
    if (_cursor == null || _loadingMore) return;
    _loadingMore = true;
    try {
      final r = await _api.get<Json>('/conversations/${widget.id}/messages', {'limit': 30, 'before': _cursor});
      setState(() { _msgs.addAll(List<Json>.from(r['items']).reversed); _cursor = r['nextCursor']; });
    } catch (_) {
    } finally {
      _loadingMore = false;
    }
  }

  Future<void> _markRead() async {
    try {
      await _api.post('/conversations/${widget.id}/read');
      ref.read(sessionProvider).refreshBadges();
    } catch (_) {}
  }

  Future<void> _send({String? mediaId, bool confirmPayment = false}) async {
    final body = _input.text.trim();
    if (body.isEmpty && mediaId == null) return;
    setState(() => _sending = true);
    try {
      final r = await _api.post<Json>('/conversations/${widget.id}/messages', {
        if (body.isNotEmpty) 'body': body,
        'mediaId': ?mediaId,
        if (confirmPayment) 'confirmPayment': true,
        'clientId': DateTime.now().microsecondsSinceEpoch.toString(),
      });
      final m = Map<String, dynamic>.from(r['message']);
      setState(() {
        if (!_msgs.any((x) => x['id'] == m['id'])) _msgs.insert(0, m);
        _input.clear();
      });
    } on ApiException catch (e) {
      if (e.code == 'CHAT_PAYMENT_CONFIRM' && mounted) {
        final ok = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('IBAN paylaşıyorsun'),
            content: const Text('Ürünü görmeden ödeme yapmamanı öneririz. Dolandırıcılar çoğunlukla kapora veya ön ödeme ister. Yine de göndermek istiyor musun?'),
            actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yine de gönder'))],
          ),
        );
        if (ok == true) {
          setState(() => _sending = false);
          return _send(mediaId: mediaId, confirmPayment: true);
        }
      } else if (mounted) {
        toast(context, e.message.isEmpty ? errorText(e) : e.message);
      }
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _photo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 2400, imageQuality: 88);
    if (x == null) return;
    setState(() => _sending = true);
    try {
      final m = await _api.upload(x);
      await _send(mediaId: m['id']);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
      setState(() => _sending = false);
    }
  }

  void _onTypingChanged(String _) {
    if (DateTime.now().difference(_lastTypingSent).inSeconds >= 3) {
      _lastTypingSent = DateTime.now();
      ref.read(sessionProvider).emitTyping(widget.id);
    }
  }

  Future<void> _deleteMsg(Json m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Mesaj silinsin mi?'),
        content: const Text('Mesaj iki taraf için de "Mesaj silindi" olarak görünür.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sil'))],
      ),
    );
    if (ok != true) return;
    try {
      await _api.delete('/messages/${m['id']}');
      setState(() { m['deleted'] = true; m['body'] = ''; m['imageUrl'] = null; });
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  Future<void> _menu(String v) async {
    final c = _conv!;
    final other = c['other'] as Map;
    switch (v) {
      case 'mute':
        final on = c['muted'] != true;
        on ? await _api.post('/conversations/${widget.id}/mute') : await _api.delete('/conversations/${widget.id}/mute');
        setState(() => c['muted'] = on);
        if (mounted) toast(context, on ? 'Bildirimler kapatıldı.' : 'Bildirimler açıldı.');
      case 'archive':
        await _api.post('/conversations/${widget.id}/archive');
        if (mounted) { toast(context, 'Sohbet arşivlendi.'); context.pop(); }
      case 'report':
        showReportSheet(context, ref, 'user', other['id']);
      case 'block':
        if (await blockUser(context, ref, other['id'], other['displayName'] ?? '')) _load();
      case 'profile':
        context.push('/users/${other['id']}');
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _typingTimer?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Widget _bubble(Json m, Json? older) {
    final mine = m['senderId'] == _meId;
    final showDay = older == null || dayLabel(older['createdAt']) != dayLabel(m['createdAt']);
    final day = showDay
        ? Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Center(child: Text(dayLabel(m['createdAt']), style: const TextStyle(fontSize: 12, color: YkColors.n500, fontWeight: FontWeight.w600))))
        : const SizedBox.shrink();
    if (m['kind'] == 'system') {
      return Column(children: [day, Padding(padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 24), child: Text(m['body'] ?? '', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5, color: YkColors.n600)))]);
    }
    final warnings = List<String>.from(m['warnings'] ?? []);
    final deleted = m['deleted'] == true;
    final canDelete = mine && !deleted && DateTime.now().difference(DateTime.parse(m['createdAt'])).inMinutes < 10;
    final bubble = GestureDetector(
      onLongPress: canDelete
          ? () => _deleteMsg(m)
          : !mine && !deleted
              ? () => showReportSheet(context, ref, 'message', m['id'])
              : null,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: m['imageUrl'] != null ? const EdgeInsets.all(4) : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: mine ? YkColors.green700 : YkColors.n50,
          borderRadius: BorderRadius.only(topLeft: const Radius.circular(16), topRight: const Radius.circular(16), bottomLeft: Radius.circular(mine ? 16 : 4), bottomRight: Radius.circular(mine ? 4 : 16)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          if (deleted)
            Text('Mesaj silindi', style: TextStyle(fontStyle: FontStyle.italic, color: mine ? Colors.white70 : YkColors.n500))
          else ...[
            if (m['imageUrl'] != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: CachedNetworkImage(imageUrl: m['imageUrl'], width: 220, fit: BoxFit.cover)),
            if ((m['body'] ?? '').toString().isNotEmpty) Padding(padding: EdgeInsets.all(m['imageUrl'] != null ? 6 : 0), child: SelectableText(m['body'], style: TextStyle(color: mine ? Colors.white : YkColors.n900, fontSize: 15, height: 1.35))),
          ],
          const SizedBox(height: 2),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Text(clock(m['createdAt']), style: TextStyle(fontSize: 10.5, color: mine ? Colors.white70 : YkColors.n500)),
            if (mine && _conv?['showReadReceipts'] == true) ...[const SizedBox(width: 4), Icon(m['readAt'] != null ? LucideIcons.checkCheck : LucideIcons.check, size: 13, color: Colors.white70)],
          ]),
        ]),
      ),
    );
    return Column(children: [
      day,
      Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: bubble),
      if (!deleted)
        for (final w in warnings.where(_warningText.containsKey))
          Padding(padding: const EdgeInsets.only(top: 4, bottom: 6), child: SafetyBanner(text: _warningText[w]!, tone: w == 'payment' ? 'error' : 'warning', icon: LucideIcons.shieldAlert)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return Scaffold(appBar: AppBar(), body: ErrorState(message: errorText(_error!), onRetry: _load));
    final c = _conv;
    if (c == null) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    final other = c['other'] as Map? ?? {};
    final listing = c['listing'] as Map;
    final ro = c['readOnly'] as String?;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: InkWell(
          onTap: () => _menu('profile'),
          child: Row(children: [
            Avatar(url: other['avatarUrl'], name: other['displayName'] ?? '?', size: 36),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(other['displayName'] ?? 'Kullanıcı', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              Text(_typing ? 'yazıyor...' : (other['neighborhood'] ?? 'Telefonu doğrulanmış'), style: TextStyle(fontSize: 12, color: _typing ? YkColors.green700 : YkColors.n500, fontWeight: FontWeight.w500)),
            ])),
          ]),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(LucideIcons.ellipsisVertical),
            onSelected: _menu,
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'profile', child: Text('Profili gör')),
              PopupMenuItem(value: 'mute', child: Text(c['muted'] == true ? 'Bildirimleri aç' : 'Bildirimleri kapat')),
              const PopupMenuItem(value: 'archive', child: Text('Arşivle')),
              const PopupMenuItem(value: 'report', child: Text('Şikayet et')),
              const PopupMenuItem(value: 'block', child: Text('Engelle')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        Material(
          color: YkColors.n50,
          child: InkWell(
            onTap: () => context.push('/listings/${listing['id']}'),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(children: [
                SizedBox(width: 44, height: 44, child: ListingImage(url: listing['coverUrl'], category: listing['category'], subtype: listing['subtype'], radius: 8)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(listing['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text(listing['status'] == 'closed' ? 'Kapandı' : priceText(listing['subtype'], listing['priceKurus']), style: TextStyle(fontSize: 13, color: YkColors.category(listing['category']), fontWeight: FontWeight.w700)),
                ])),
                const Icon(LucideIcons.chevronRight, size: 18, color: YkColors.n500),
              ]),
            ),
          ),
        ),
        Expanded(
          child: _msgs.isEmpty
              ? const Padding(padding: EdgeInsets.all(24), child: Center(child: SafetyBanner(text: 'Telefon numaranı paylaşmak zorunda değilsin. Buluşmalarını gündüz ve kalabalık bir yerde yap.')))
              : ListView.builder(
                  controller: _scroll,
                  reverse: true,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  itemCount: _msgs.length,
                  itemBuilder: (_, i) => _bubble(_msgs[i], i + 1 < _msgs.length ? _msgs[i + 1] : null),
                ),
        ),
        if (ro != null)
          SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(12), child: SafetyBanner(text: _readOnlyText[ro] ?? 'Bu sohbet salt okunur.', tone: 'warning')))
        else
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: YkColors.n100))),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                IconButton(tooltip: 'Fotoğraf gönder', onPressed: _sending ? null : _photo, icon: const Icon(LucideIcons.image, color: YkColors.n600)),
                Expanded(
                  child: TextField(
                    controller: _input,
                    minLines: 1,
                    maxLines: 5,
                    maxLength: 2000,
                    textCapitalization: TextCapitalization.sentences,
                    onChanged: _onTypingChanged,
                    decoration: const InputDecoration(hintText: 'Mesaj yaz', counterText: '', isDense: true),
                  ),
                ),
                const SizedBox(width: 6),
                IconButton.filled(tooltip: 'Gönder', onPressed: _sending ? null : () => _send(), icon: _sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(LucideIcons.send)),
              ]),
            ),
          ),
      ]),
    );
  }
}
