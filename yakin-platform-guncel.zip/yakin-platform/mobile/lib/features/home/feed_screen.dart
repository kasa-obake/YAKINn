import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

class FeedFilter {
  String? category;
  int radiusKm = 5;
  String sort = 'new';
  bool freeOnly = false;
  String? since;
  String? q;
  Json toQuery() => {'category': category, 'radiusKm': radiusKm, 'sort': sort, 'freeOnly': freeOnly ? 'true' : null, 'since': since, 'q': (q?.isEmpty ?? true) ? null : q};
  FeedFilter copy() => FeedFilter()
    ..category = category
    ..radiusKm = radiusKm
    ..sort = sort
    ..freeOnly = freeOnly
    ..since = since
    ..q = q;
  int get activeCount => (radiusKm != 5 ? 1 : 0) + (sort != 'new' ? 1 : 0) + (freeOnly ? 1 : 0) + (since != null ? 1 : 0);
}

/// Sayfalı ilan listesi denetleyicisi (cursor tabanlı).
class FeedController extends ChangeNotifier {
  FeedController(this.api, this.filter);
  final Api api;
  FeedFilter filter;
  final items = <Json>[];
  String? cursor;
  bool loading = false, done = false;
  Object? error;

  Future<void> refresh() async {
    items.clear();
    cursor = null;
    done = false;
    error = null;
    await more();
  }

  Future<void> more() async {
    if (loading || done) return;
    loading = true;
    notifyListeners();
    try {
      final r = await api.get<Json>('/listings', {...filter.toQuery(), 'cursor': cursor, 'limit': 20});
      items.addAll(List<Json>.from(r['items']));
      cursor = r['nextCursor'];
      done = cursor == null;
    } catch (e) {
      error = e;
    }
    loading = false;
    notifyListeners();
  }
}

class FeedScreen extends ConsumerStatefulWidget {
  const FeedScreen({super.key});
  @override
  ConsumerState<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends ConsumerState<FeedScreen> {
  late final FeedController _feed = FeedController(ref.read(apiProvider), FeedFilter())..refresh();
  List<Json> _help = [];
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() { if (_scroll.position.extentAfter < 600) _feed.more(); });
    _loadHelp();
  }

  Future<void> _loadHelp() async {
    try {
      final r = await ref.read(apiProvider).get<Json>('/listings', {'category': 'yardim', 'subtype': 'istiyorum', 'radiusKm': 3, 'limit': 10});
      if (mounted) setState(() => _help = List<Json>.from(r['items']));
    } catch (_) {}
  }

  Future<void> _reload() async {
    await Future.wait([_feed.refresh(), _loadHelp()]);
  }

  void _setCategory(String? c) {
    _feed.filter.category = c;
    _feed.refresh();
    setState(() {});
  }

  Future<void> _openFilters() async {
    final f = await showModalBottomSheet<FeedFilter>(context: context, isScrollControlled: true, builder: (_) => FilterSheet(initial: _feed.filter));
    if (f != null) {
      _feed.filter = f;
      _feed.refresh();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(sessionProvider).me;
    final hood = (me?['neighborhood'] as Map?)?['name'] ?? '';
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Yakınında', style: TextStyle(fontSize: 12, color: YkColors.n500, fontWeight: FontWeight.w500)),
          Row(children: [const Icon(LucideIcons.mapPin, size: 16, color: YkColors.green700), const SizedBox(width: 4), Text('$hood, ${_feed.filter.radiusKm} km', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))]),
        ]),
        actions: [
          IconButton(tooltip: 'Ara', icon: const Icon(LucideIcons.search), onPressed: () => context.push('/search')),
          ValueListenableBuilder(
            valueListenable: ref.read(sessionProvider).badges,
            builder: (_, b, __) => IconButton(tooltip: 'Bildirimler', icon: BadgeIcon(icon: LucideIcons.bell, count: (b['notifications'] ?? 0) as int), onPressed: () => context.push('/notifications')),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _reload,
        child: ListenableBuilder(
          listenable: _feed,
          builder: (context, _) => CustomScrollView(controller: _scroll, slivers: [
            SliverToBoxAdapter(
              child: SizedBox(
                height: 52,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), children: [
                  for (final (k, l) in [(null, 'Tümü'), ('esya', 'Eşya'), ('yardim', 'Yardım'), ('kayip', 'Kayıp ve bulunan')])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(l),
                        selected: _feed.filter.category == k,
                        showCheckmark: false,
                        labelStyle: TextStyle(color: _feed.filter.category == k ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600),
                        onSelected: (_) => _setCategory(k),
                      ),
                    ),
                  ActionChip(
                    avatar: const Icon(LucideIcons.slidersHorizontal, size: 16),
                    label: Text(_feed.filter.activeCount > 0 ? 'Filtre (${_feed.filter.activeCount})' : 'Filtre'),
                    onPressed: _openFilters,
                  ),
                ]),
              ),
            ),
            if (_help.isNotEmpty && _feed.filter.category == null) SliverToBoxAdapter(child: HelpStrip(items: _help)),
            if (_feed.items.isEmpty && _feed.loading)
              const SliverFillRemaining(child: Center(child: CircularProgressIndicator(strokeWidth: 2.5)))
            else if (_feed.items.isEmpty && _feed.error != null)
              SliverFillRemaining(child: ErrorState(message: errorText(_feed.error!), onRetry: _feed.refresh))
            else if (_feed.items.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  icon: LucideIcons.mapPin,
                  title: 'Yakınında henüz ilan yok',
                  body: 'Mesafeyi genişletebilir ya da ilk ilanı sen verebilirsin.',
                  action: FilledButton(onPressed: () => context.push('/create'), child: const Text('İlan ver')),
                ),
              )
            else ...[
              const SliverToBoxAdapter(child: SectionTitle('Yeni ilanlar')),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 20, crossAxisSpacing: 12, childAspectRatio: .66),
                  delegate: SliverChildBuilderDelegate(
                    (c, i) => ListingCard(item: _feed.items[i], onTap: () => context.push('/listings/${_feed.items[i]['id']}')),
                    childCount: _feed.items.length,
                  ),
                ),
              ),
              SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: _feed.loading ? const CircularProgressIndicator(strokeWidth: 2) : _feed.done ? const Text('Hepsi bu kadar', style: TextStyle(color: YkColors.n500)) : const SizedBox()))),
            ],
          ]),
        ),
      ),
    );
  }
}

/// Ana sayfadaki "Yakınında yardım bekleyenler" şeridi.
class HelpStrip extends StatelessWidget {
  const HelpStrip({super.key, required this.items});
  final List<Json> items;
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('Yakınında yardım bekleyenler'),
      SizedBox(
        height: 104,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: items.length,
          separatorBuilder: (_, _) => const SizedBox(width: 10),
          itemBuilder: (c, i) {
            final it = items[i];
            return InkWell(
              onTap: () => context.push('/listings/${it['id']}'),
              borderRadius: BorderRadius.circular(YkRadius.md),
              child: Container(
                width: 240,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: YkColors.yardim.withValues(alpha: .07), borderRadius: BorderRadius.circular(YkRadius.md), border: Border.all(color: YkColors.yardim.withValues(alpha: .18))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [const Icon(LucideIcons.handHeart, size: 16, color: YkColors.yardim), const SizedBox(width: 6), Text(timeAgo(it['publishedAt']), style: const TextStyle(fontSize: 12, color: YkColors.yardim, fontWeight: FontWeight.w600))]),
                  const SizedBox(height: 6),
                  Text(it['title'], maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                  const Spacer(),
                  Text([it['neighborhood'], distanceText(it['distance'])].whereType<String>().where((s) => s.isNotEmpty).join(' · '), style: const TextStyle(fontSize: 12, color: YkColors.n600)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }
}

class FilterSheet extends ConsumerStatefulWidget {
  const FilterSheet({super.key, required this.initial});
  final FeedFilter initial;
  @override
  ConsumerState<FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends ConsumerState<FilterSheet> {
  late final FeedFilter f = widget.initial.copy();
  int? _count;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _recount();
  }

  void _recount() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      try {
        final r = await ref.read(apiProvider).get<Json>('/listings/count', f.toQuery());
        if (mounted) setState(() => _count = r['count']);
      } catch (_) {}
    });
  }

  void _set(VoidCallback fn) {
    setState(fn);
    _recount();
  }

  Widget _chips<T>(List<(T, String)> opts, T value, void Function(T) on) => Wrap(spacing: 8, runSpacing: 8, children: [
        for (final (v, l) in opts)
          ChoiceChip(label: Text(l), selected: value == v, showCheckmark: false, labelStyle: TextStyle(color: value == v ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600), onSelected: (_) => _set(() => on(v))),
      ]);

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme.titleMedium;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text('Filtreler', style: Theme.of(context).textTheme.titleLarge)), TextButton(onPressed: () => _set(() { f.radiusKm = 5; f.sort = 'new'; f.freeOnly = false; f.since = null; }), child: const Text('Temizle'))]),
          const SizedBox(height: 12),
          Text('Mesafe', style: t),
          const SizedBox(height: 8),
          _chips<int>([(1, '1 km'), (3, '3 km'), (5, '5 km'), (10, '10 km'), (20, '20 km')], f.radiusKm, (v) => f.radiusKm = v),
          const SizedBox(height: 20),
          Text('Sıralama', style: t),
          const SizedBox(height: 8),
          _chips<String>([('new', 'En yeni'), ('near', 'En yakın')], f.sort, (v) => f.sort = v),
          const SizedBox(height: 20),
          Text('Tarih', style: t),
          const SizedBox(height: 8),
          _chips<String?>([(null, 'Tümü'), ('24h', 'Son 24 saat'), ('7d', 'Son 7 gün')], f.since, (v) => f.since = v),
          const SizedBox(height: 12),
          SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Yalnızca ücretsiz'), value: f.freeOnly, onChanged: (v) => _set(() => f.freeOnly = v)),
          const SizedBox(height: 12),
          FilledButton(onPressed: () => Navigator.pop(context, f), child: Text(_count == null ? 'Sonuçları göster' : '$_count ilanı göster')),
        ]),
      ),
    );
  }
}

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});
  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  late final FeedController _feed = FeedController(ref.read(apiProvider), FeedFilter()..radiusKm = 10);
  final _c = TextEditingController();
  Timer? _d;
  bool _searched = false;

  void _onChanged(String v) {
    _d?.cancel();
    _d = Timer(const Duration(milliseconds: 350), () {
      if (v.trim().length < 2) return;
      _feed.filter.q = v.trim();
      _searched = true;
      _feed.refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller: _c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(hintText: 'Bisiklet, matkap, kedi...', prefixIcon: Icon(LucideIcons.search, size: 20), contentPadding: EdgeInsets.symmetric(vertical: 10)),
          onChanged: _onChanged,
        ),
        actions: const [SizedBox(width: 12)],
      ),
      body: ListenableBuilder(
        listenable: _feed,
        builder: (context, _) {
          if (!_searched) return const EmptyState(icon: LucideIcons.search, title: 'Mahallende ara', body: 'Aramalar 10 km içindeki aktif ilanlarda yapılır.');
          if (_feed.items.isEmpty && _feed.loading) return const Center(child: CircularProgressIndicator(strokeWidth: 2.5));
          if (_feed.items.isEmpty) return EmptyState(icon: LucideIcons.searchX, title: 'Sonuç bulunamadı', body: '"${_feed.filter.q}" için yakınında ilan yok. Farklı bir kelime dene.');
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 20, crossAxisSpacing: 12, childAspectRatio: .66),
            itemCount: _feed.items.length,
            itemBuilder: (c, i) {
              if (i == _feed.items.length - 4) _feed.more();
              return ListingCard(item: _feed.items[i], onTap: () => context.push('/listings/${_feed.items[i]['id']}'));
            },
          );
        },
      ),
    );
  }
}
