import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

/// Yönetici ve moderatörler için iki adımlı doğrulama (TOTP) kurulumu.
class TotpScreen extends ConsumerStatefulWidget {
  const TotpScreen({super.key});
  @override
  ConsumerState<TotpScreen> createState() => _TotpScreenState();
}

class _TotpScreenState extends ConsumerState<TotpScreen> {
  final _code = TextEditingController();
  Json? _setup;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _call(Future<void> Function() f) async {
    setState(() { _busy = true; _error = null; });
    try {
      await f();
    } catch (e) {
      if (mounted) setState(() => _error = errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _start() => _call(() async {
        final r = await ref.read(apiProvider).post<Json>('/me/totp/setup');
        if (mounted) setState(() => _setup = r);
      });

  Future<void> _enable() => _call(() async {
        await ref.read(apiProvider).post('/me/totp/enable', {'code': _code.text.trim()});
        await ref.read(sessionProvider).reloadMe();
        if (mounted) {
          _code.clear();
          setState(() => _setup = null);
          toast(context, 'İki adımlı doğrulama açıldı.');
        }
      });

  Future<void> _disable() => _call(() async {
        await ref.read(apiProvider).post('/me/totp/disable', {'code': _code.text.trim()});
        await ref.read(sessionProvider).reloadMe();
        if (mounted) {
          _code.clear();
          toast(context, 'İki adımlı doğrulama kapatıldı.');
        }
      });

  Widget _codeField() => TextField(
        controller: _code,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        maxLength: 6,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: const TextStyle(fontSize: 26, letterSpacing: 10, fontWeight: FontWeight.w700),
        decoration: const InputDecoration(counterText: '', hintText: '------', labelText: 'Uygulamadaki 6 haneli kod'),
        onChanged: (_) => setState(() {}),
      );

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(sessionProvider);
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        final enabled = session.me?['totpEnabled'] == true;
        final ready = _code.text.length == 6 && !_busy;
        final secret = (_setup?['secret'] ?? '').toString();
        return Scaffold(
          appBar: AppBar(title: const Text('İki adımlı doğrulama')),
          body: ListView(padding: const EdgeInsets.all(20), children: [
            SafetyBanner(
              text: enabled ? 'Açık. Girişte SMS kodunun yanında doğrulayıcı uygulamadaki kod da istenir.' : 'Kapalı. Yönetici ve moderatör hesabını korumak için açman önerilir.',
              icon: LucideIcons.shieldCheck,
            ),
            const SizedBox(height: 16),
            if (!enabled && _setup == null) ...[
              const Text('Google Authenticator, Microsoft Authenticator veya Authy gibi bir doğrulayıcı uygulama gerekir. Kurulumu başlatınca sana bir kurulum anahtarı göstereceğiz.', style: TextStyle(color: YkColors.n600)),
              const SizedBox(height: 16),
              FilledButton(onPressed: _busy ? null : _start, child: const Text('Kurulumu başlat')),
            ],
            if (!enabled && _setup != null) ...[
              const Text('1. Doğrulayıcı uygulamanda yeni hesap ekle ve “kurulum anahtarı gir” seçeneğini seç.', style: TextStyle(color: YkColors.n600)),
              const SizedBox(height: 6),
              const Text('2. Hesap adı olarak YAKIN yaz, anahtarı aşağıdan gir, tür olarak “zamana dayalı” bırak.', style: TextStyle(color: YkColors.n600)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: YkColors.green50, borderRadius: BorderRadius.circular(YkRadius.sm)),
                child: SelectableText(secret.replaceAllMapped(RegExp('.{4}'), (m) => '${m[0]} ').trim(), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: secret));
                  if (context.mounted) toast(context, 'Anahtar kopyalandı.');
                },
                icon: const Icon(LucideIcons.download),
                label: const Text('Anahtarı kopyala'),
              ),
              const SizedBox(height: 16),
              const Text('3. Uygulamanın gösterdiği kodu yaz:', style: TextStyle(color: YkColors.n600)),
              const SizedBox(height: 8),
              _codeField(),
              const SizedBox(height: 12),
              FilledButton(onPressed: ready ? _enable : null, child: const Text('Etkinleştir')),
              const SizedBox(height: 12),
              const Text('Telefonunu kaybedersen bir yöneticinin doğrulamayı sıfırlaması gerekir.', style: TextStyle(fontSize: 12.5, color: YkColors.n500)),
            ],
            if (enabled) ...[
              const Text('Kapatmak için doğrulayıcı uygulamadaki güncel kodu yaz:', style: TextStyle(color: YkColors.n600)),
              const SizedBox(height: 8),
              _codeField(),
              const SizedBox(height: 12),
              FilledButton(style: FilledButton.styleFrom(backgroundColor: YkColors.error), onPressed: ready ? _disable : null, child: const Text('İki adımlı doğrulamayı kapat')),
            ],
            if (_error != null) ...[
              const SizedBox(height: 16),
              SafetyBanner(text: _error!, tone: 'error', icon: LucideIcons.circleAlert),
            ],
          ]),
        );
      },
    );
  }
}
