import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/config.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';
import '../admin/admin_screens.dart';
import '../safety/report_sheet.dart';

Widget _stat(String value, String label) => Expanded(
      child: Column(children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: YkColors.n900)),
        const SizedBox(height: 2),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: YkColors.n600)),
      ]),
    );

/// Profil sekmesi.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  Future<void> _avatar(BuildContext context, WidgetRef ref) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 88);
    if (x == null) return;
    try {
      final m = await ref.read(apiProvider).upload(x);
      await ref.read(sessionProvider).updateMe({'avatarUrl': m['url']});
      if (context.mounted) toast(context, 'Profil fotoğrafı güncellendi.');
    } catch (e) {
      if (context.mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(sessionProvider);
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        final me = session.me ?? {};
        final stats = ref.watch(myStatsProvider).value;
        return Scaffold(
          appBar: AppBar(title: const Text('Profil'), actions: [IconButton(tooltip: 'Ayarlar', icon: const Icon(LucideIcons.settings), onPressed: () => context.push('/settings'))]),
          body: ListView(children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                GestureDetector(
                  onTap: () => _avatar(context, ref),
                  child: Stack(children: [
                    Avatar(url: me['avatarUrl'], name: me['displayName'] ?? '?', size: 72),
                    Positioned(right: 0, bottom: 0, child: Container(padding: const EdgeInsets.all(4), decoration: const BoxDecoration(color: YkColors.green700, shape: BoxShape.circle), child: const Icon(LucideIcons.camera, size: 14, color: Colors.white))),
                  ]),
                ),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(me['displayName'] ?? '', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 2),
                  Text('${me['neighborhood']?['name'] ?? ''} · ${me['phoneMasked'] ?? ''}', style: const TextStyle(color: YkColors.n600)),
                  const SizedBox(height: 6),
                  const Row(children: [Icon(LucideIcons.badgeCheck, size: 15, color: YkColors.green700), SizedBox(width: 4), Text('Telefonu doğrulanmış', style: TextStyle(fontSize: 12.5, color: YkColors.green700, fontWeight: FontWeight.w600))]),
                ])),
              ]),
            ),
            if (me['status'] == 'suspended')
              const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: SafetyBanner(text: 'Hesabın geçici olarak kısıtlandı. Ayrıntılar ve itiraz için Kararlar bölümüne bak.', tone: 'error')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: YkColors.green50, borderRadius: BorderRadius.circular(YkRadius.md)),
                child: Row(children: [
                  _stat('${me['helpedCount'] ?? 0}', 'komşuya\nyardım'),
                  _stat(stats == null || stats['ratingCount'] == 0 ? '-' : '${stats['ratingAvg']}', '${stats?['ratingCount'] ?? 0}\ndeğerlendirme'),
                  _stat(stats?['medianResponseSec'] == null ? '-' : responseTimeText(stats!['medianResponseSec']), 'ortalama\nyanıt'),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            ValueListenableBuilder<Json>(
              valueListenable: session.badges,
              builder: (_, b, __) => Column(children: [
                _link(context, LucideIcons.package, 'İlanlarım', '/me/listings'),
                _link(context, LucideIcons.heart, 'Favorilerim', '/me/favorites'),
                _link(context, LucideIcons.star, 'Bekleyen değerlendirmeler', '/me/pending-reviews', count: (b['pendingReviews'] ?? 0) as int),
                _link(context, LucideIcons.user, 'Herkese açık profilim', '/users/${me['id']}'),
                _link(context, LucideIcons.scale, 'Kararlar ve itirazlar', '/decisions'),
                _link(context, LucideIcons.flag, 'Gönderdiğim şikayetler', '/me/reports'),
                if (isStaff(me)) _link(context, LucideIcons.shieldCheck, 'Moderasyon paneli', '/admin'),
                _link(context, LucideIcons.settings, 'Ayarlar ve gizlilik', '/settings'),
              ]),
            ),
            const Divider(height: 24),
            ListTile(
              leading: const Icon(LucideIcons.logOut, color: YkColors.error),
              title: const Text('Çıkış yap', style: TextStyle(color: YkColors.error, fontWeight: FontWeight.w600)),
              onTap: () => session.signOut(),
            ),
            const SizedBox(height: 24),
          ]),
        );
      },
    );
  }

  Widget _link(BuildContext context, IconData icon, String title, String path, {int count = 0}) => ListTile(
        leading: Icon(icon, color: YkColors.green700),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          if (count > 0) Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: YkColors.green700, borderRadius: BorderRadius.circular(10)), child: Text('$count', style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700))),
          const Icon(LucideIcons.chevronRight, size: 18, color: YkColors.n500),
        ]),
        onTap: () => context.push(path),
      );
}

/// Başka bir kullanıcının herkese açık profili.
class PublicProfileScreen extends ConsumerWidget {
  const PublicProfileScreen({super.key, required this.id});
  final String id;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final v = ref.watch(publicProfileProvider(id));
    return Scaffold(
      appBar: AppBar(actions: [
        if (v.value != null && v.value!['isMe'] != true)
          PopupMenuButton<String>(
            icon: const Icon(LucideIcons.ellipsisVertical),
            onSelected: (s) async {
              final p = v.value!;
              if (s == 'report') showReportSheet(context, ref, 'user', id);
              if (s == 'block' && await blockUser(context, ref, id, p['user']['displayName'])) ref.invalidate(publicProfileProvider(id));
              if (s == 'unblock') {
                await ref.read(apiProvider).delete('/users/$id/block');
                ref.invalidate(publicProfileProvider(id));
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'report', child: Text('Şikayet et')),
              v.value!['blockedByMe'] == true ? const PopupMenuItem(value: 'unblock', child: Text('Engeli kaldır')) : const PopupMenuItem(value: 'block', child: Text('Engelle')),
            ],
          ),
      ]),
      body: AsyncView<Json>(
        value: v,
        onRetry: () => ref.invalidate(publicProfileProvider(id)),
        builder: (p) {
          final u = p['user'] as Map, s = p['stats'] as Map;
          final listings = List<Json>.from(p['listings']), reviews = List<Json>.from(p['reviews']);
          return ListView(padding: const EdgeInsets.all(16), children: [
            Center(child: Avatar(url: u['avatarUrl'], name: u['displayName'] ?? '?', size: 88)),
            const SizedBox(height: 12),
            Center(child: Text(u['displayName'] ?? '', style: Theme.of(context).textTheme.titleLarge)),
            Center(child: Text([if (u['neighborhood'] != null) u['neighborhood'], 'Üyelik: ${dayLabel(u['memberSince'])}'].join(' · '), style: const TextStyle(color: YkColors.n600))),
            if ((u['bio'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(u['bio'], textAlign: TextAlign.center)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(color: YkColors.green50, borderRadius: BorderRadius.circular(YkRadius.md)),
              child: Row(children: [
                _stat('${s['helpedCount'] ?? 0}', 'komşuya\nyardım'),
                _stat(s['ratingCount'] == 0 ? '-' : '${s['ratingAvg']}', '${s['ratingCount']}\ndeğerlendirme'),
                _stat(s['medianResponseSec'] == null ? '-' : responseTimeText(s['medianResponseSec']), 'ortalama\nyanıt'),
              ]),
            ),
            if (p['blockedByMe'] == true) const Padding(padding: EdgeInsets.only(top: 12), child: SafetyBanner(text: 'Bu kullanıcıyı engelledin. İlanlarını görmezsin ve sana yazamaz.', tone: 'warning')),
            if (listings.isNotEmpty) ...[
              const SizedBox(height: 20),
              const SectionTitle('Aktif ilanlar'),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: .72,
                children: [for (final l in listings) ListingCard(item: l, onTap: () => context.push('/listings/${l['id']}'))],
              ),
            ],
            const SizedBox(height: 20),
            const SectionTitle('Değerlendirmeler'),
            const SizedBox(height: 8),
            if (reviews.isEmpty) const Text('Henüz değerlendirme yok.', style: TextStyle(color: YkColors.n600)),
            for (final r in reviews)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    for (var i = 0; i < 5; i++) Icon(LucideIcons.star, size: 14, color: i < (r['rating'] as int) ? YkColors.warning : YkColors.n200),
                    const SizedBox(width: 8),
                    Text('${r['from']} · ${timeAgo(r['createdAt'])}', style: const TextStyle(fontSize: 12.5, color: YkColors.n600)),
                  ]),
                  if ((r['tags'] as List?)?.isNotEmpty == true) Padding(padding: const EdgeInsets.only(top: 4), child: Text((r['tags'] as List).map((t) => kReviewTags[t] ?? t).join(' · '), style: const TextStyle(fontSize: 12.5, color: YkColors.green700, fontWeight: FontWeight.w600))),
                  if ((r['comment'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(r['comment'])),
                ]),
              ),
          ]);
        },
      ),
    );
  }
}

class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Favorilerim')),
        body: AsyncView<List<Json>>(
          value: ref.watch(favoritesProvider),
          onRetry: () => ref.invalidate(favoritesProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.heart, title: 'Favorin yok', body: 'Beğendiğin ilanları kalp simgesiyle kaydedebilirsin.')
              : GridView.count(
                  padding: const EdgeInsets.all(16),
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: .72,
                  children: [for (final l in items) ListingCard(item: l, onTap: () => context.push('/listings/${l['id']}').then((_) => ref.invalidate(favoritesProvider)))],
                ),
        ),
      );
}

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final api = ref.read(apiProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Bildirimler'), actions: [
        TextButton(
          onPressed: () async {
            await api.post('/notifications/read-all');
            ref.invalidate(notificationsProvider);
            ref.read(sessionProvider).refreshBadges();
          },
          child: const Text('Tümünü okundu say'),
        ),
      ]),
      body: AsyncView<List<Json>>(
        value: ref.watch(notificationsProvider),
        onRetry: () => ref.invalidate(notificationsProvider),
        builder: (items) => items.isEmpty
            ? const EmptyState(icon: LucideIcons.bell, title: 'Bildirim yok', body: 'Yeni mesaj, yanıt ve değerlendirme istekleri burada görünür.')
            : ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_, _) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final n = items[i];
                  final unread = n['readAt'] == null;
                  return ListTile(
                    tileColor: unread ? YkColors.green50 : null,
                    leading: Icon(switch (n['type']) { 'new_message' || 'first_reply' => LucideIcons.messageCircle, 'review_request' => LucideIcons.star, 'moderation' => LucideIcons.scale, 'listing_expiring' => LucideIcons.clock, _ => LucideIcons.bell }, color: YkColors.green700),
                    title: Text(n['title'] ?? '', style: TextStyle(fontWeight: unread ? FontWeight.w700 : FontWeight.w500)),
                    subtitle: Text('${n['body'] ?? ''}\n${timeAgo(n['createdAt'])}'),
                    isThreeLine: true,
                    onTap: () async {
                      if (unread) {
                        try { await api.post('/notifications/${n['id']}/read'); } catch (_) {}
                        ref.invalidate(notificationsProvider);
                        ref.read(sessionProvider).refreshBadges();
                      }
                      final link = (n['link'] ?? '/') as String;
                      if (context.mounted && link != '/') context.push(link);
                    },
                  );
                },
              ),
      ),
    );
  }
}

const _actionLabel = {'remove_content': 'İçerik kaldırıldı', 'warn': 'Uyarı', 'suspend': 'Geçici kısıtlama', 'ban': 'Hesap kapatıldı', 'reject_listing': 'İlan reddedildi', 'approve_listing': 'İlan onaylandı'};

class DecisionsScreen extends ConsumerWidget {
  const DecisionsScreen({super.key});

  Future<void> _appeal(BuildContext context, WidgetRef ref, Json d) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('İtiraz et'),
        content: TextField(controller: c, maxLines: 4, maxLength: 1000, decoration: const InputDecoration(hintText: 'Neden yanlış olduğunu düşünüyorsun? (en az 10 karakter)')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Gönder'))],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(apiProvider).post('/me/decisions/${d['id']}/appeal', {'note': c.text.trim()});
      ref.invalidate(decisionsProvider);
      if (context.mounted) toast(context, 'İtirazın alındı. Farklı bir moderatör inceleyecek.');
    } catch (e) {
      if (context.mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Kararlar ve itirazlar')),
        body: AsyncView<List<Json>>(
          value: ref.watch(decisionsProvider),
          onRetry: () => ref.invalidate(decisionsProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.scale, title: 'Hakkında karar yok', body: 'Hesabın veya ilanlarınla ilgili moderasyon kararları burada, gerekçesiyle birlikte görünür.')
              : ListView(padding: const EdgeInsets.all(16), children: [
                  for (final d in items)
                    Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(_actionLabel[d['action']] ?? d['action'], style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(timeAgo(d['createdAt']), style: const TextStyle(fontSize: 12.5, color: YkColors.n500)),
                          if ((d['rule'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Kural: ${d['rule']}', style: const TextStyle(fontWeight: FontWeight.w600))),
                          if ((d['reason'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(d['reason'])),
                          if (d['suspendDays'] != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Süre: ${d['suspendDays']} gün')),
                          const SizedBox(height: 10),
                          if (d['appeal'] != null)
                            SafetyBanner(text: switch (d['appeal']['status']) { 'accepted' => 'İtirazın kabul edildi.', 'rejected' => 'İtirazın incelendi ve karar korundu.', _ => 'İtirazın inceleniyor.' }, tone: d['appeal']['status'] == 'rejected' ? 'warning' : 'info')
                          else if (d['canAppeal'] == true)
                            OutlinedButton(onPressed: () => _appeal(context, ref, d), child: const Text('İtiraz et')),
                        ]),
                      ),
                    ),
                ]),
        ),
      );
}

const _prefLabels = {
  'new_message': 'Yeni mesajlar',
  'first_reply': 'İlanıma ilk yanıt',
  'favorite_closed': 'Favorim kapandığında',
  'nearby_help': 'Yakınımdaki yardım talepleri',
  'review_request': 'Değerlendirme istekleri',
  'listing_expiring': 'İlan süresi dolarken',
};

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});
  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  Future<void> _patch(Json p) async {
    try {
      await ref.read(sessionProvider).updateMe(p);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  Future<void> _changeHood(Json me) async {
    final hoods = await ref.read(neighborhoodsProvider.future);
    if (!mounted) return;
    final id = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      builder: (c) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .7,
        builder: (_, sc) => ListView(controller: sc, children: [
          Padding(padding: const EdgeInsets.all(16), child: Text('Mahalle değiştir · bu ay ${me['neighborhoodChangesLeft']} hakkın kaldı', style: const TextStyle(fontWeight: FontWeight.w700))),
          for (final h in hoods) ListTile(title: Text(h['name']), subtitle: Text(h['district'] ?? ''), selected: h['id'] == me['neighborhood']?['id'], onTap: () => Navigator.pop(c, h['id'] as int)),
        ]),
      ),
    );
    if (id != null && id != me['neighborhood']?['id']) {
      await _patch({'neighborhoodId': id});
      if (mounted) toast(context, 'Mahallen güncellendi.');
    }
  }

  Future<void> _support() async {
    final s = TextEditingController(), b = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Destek'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: s, decoration: const InputDecoration(labelText: 'Konu')),
          const SizedBox(height: 8),
          TextField(controller: b, maxLines: 4, decoration: const InputDecoration(labelText: 'Mesajın')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Gönder'))],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(apiProvider).post('/support', {'subject': s.text.trim(), 'body': b.text.trim()});
      if (mounted) toast(context, 'Mesajın alındı. En kısa sürede dönüş yapacağız.');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  Future<void> _export() async {
    try {
      final data = await ref.read(apiProvider).get<Json>('/me/export');
      await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(data)));
      if (mounted) toast(context, 'Verilerin JSON olarak panoya kopyalandı.');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Hesabın silinsin mi?'),
        content: const Text('İlanların yayından kalkar ve profilin gizlenir. 30 gün içinde tekrar giriş yaparsan silme talebin iptal olur. Sonrasında verilerin kalıcı olarak silinir veya anonimleştirilir.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(style: FilledButton.styleFrom(backgroundColor: YkColors.error), onPressed: () => Navigator.pop(c, true), child: const Text('Hesabımı sil'))],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(apiProvider).post('/me/delete', {});
      await ref.read(sessionProvider).signOut(remote: false);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(sessionProvider);
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        final me = session.me ?? {};
        final privacy = Map<String, dynamic>.from(me['privacy'] ?? {});
        final prefs = Map<String, dynamic>.from(me['notificationPrefs'] ?? {});
        Widget sw(String title, String? sub, bool v, ValueChanged<bool> on) => SwitchListTile(title: Text(title), subtitle: sub == null ? null : Text(sub), value: v, onChanged: on);
        return Scaffold(
          appBar: AppBar(title: const Text('Ayarlar ve gizlilik')),
          body: ListView(children: [
            const Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 4), child: SectionTitle('Konum')),
            ListTile(
              leading: const Icon(LucideIcons.mapPin),
              title: Text(me['neighborhood']?['name'] ?? 'Mahalle seç'),
              subtitle: Text('Ayda en fazla 2 kez değiştirilebilir · ${me['neighborhoodChangesLeft'] ?? 0} hak kaldı'),
              trailing: const Icon(LucideIcons.chevronRight),
              onTap: (me['neighborhoodChangesLeft'] ?? 0) > 0 ? () => _changeHood(me) : null,
            ),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: SafetyBanner(text: 'Tam adresin hiçbir zaman gösterilmez. İlanlar yalnızca yaklaşık mesafeyle görünür. Canlı konum paylaşımı yoktur.')),
            const Padding(padding: EdgeInsets.fromLTRB(16, 20, 16, 4), child: SectionTitle('Gizlilik')),
            sw('Mahallemi gizle', 'Profilinde mahalle adı görünmez', privacy['hideNeighborhood'] == true, (v) => _patch({'hideNeighborhood': v})),
            sw('Okundu bilgisi', 'Kapatırsan sen de başkalarınınkini göremezsin', privacy['showReadReceipts'] != false, (v) => _patch({'showReadReceipts': v})),
            sw('Yanıt süremi göster', null, privacy['showResponseTime'] != false, (v) => _patch({'showResponseTime': v})),
            ListTile(leading: const Icon(LucideIcons.ban), title: const Text('Engellenen kullanıcılar'), trailing: const Icon(LucideIcons.chevronRight), onTap: () => context.push('/settings/blocks')),
            const Padding(padding: EdgeInsets.fromLTRB(16, 20, 16, 4), child: SectionTitle('Bildirimler')),
            for (final e in _prefLabels.entries) sw(e.value, null, prefs[e.key] != false, (v) => _patch({'notificationPrefs': {...prefs, e.key: v}})),
            sw('Sessiz saatler', '22.00 - 08.00 arası sesli bildirim gönderilmez', prefs['quietHours'] != false, (v) => _patch({'notificationPrefs': {...prefs, 'quietHours': v}})),
            const Padding(padding: EdgeInsets.fromLTRB(16, 20, 16, 4), child: SectionTitle('Hesap ve veriler')),
            if (isStaff(me)) ListTile(leading: const Icon(LucideIcons.shieldCheck), title: const Text('İki adımlı doğrulama'), subtitle: Text(me['totpEnabled'] == true ? 'Açık' : 'Kapalı'), trailing: const Icon(LucideIcons.chevronRight), onTap: () => context.push('/settings/totp')),
            ListTile(leading: const Icon(LucideIcons.lifeBuoy), title: const Text('Destek ile iletişim'), onTap: _support),
            ListTile(leading: const Icon(LucideIcons.download), title: const Text('Verilerimi indir'), subtitle: const Text('KVKK kapsamında tüm verilerin'), onTap: _export),
            ListTile(leading: const Icon(LucideIcons.trash2, color: YkColors.error), title: const Text('Hesabımı sil', style: TextStyle(color: YkColors.error)), onTap: _delete),
            const Padding(padding: EdgeInsets.fromLTRB(16, 20, 16, 4), child: SectionTitle('Hakkında')),
            ListTile(leading: const Icon(LucideIcons.scrollText), title: const Text('Kullanım koşulları'), trailing: const Icon(LucideIcons.chevronRight), onTap: () => context.push('/legal/terms')),
            ListTile(leading: const Icon(LucideIcons.scrollText), title: const Text('KVKK aydınlatma metni'), trailing: const Icon(LucideIcons.chevronRight), onTap: () => context.push('/legal/kvkk')),
            ListTile(leading: const Icon(LucideIcons.scrollText), title: const Text('Gizlilik politikası'), trailing: const Icon(LucideIcons.chevronRight), onTap: () => context.push('/legal/privacy')),
            const ListTile(leading: Icon(LucideIcons.info), title: Text('Sürüm'), subtitle: Text(kAppVersion)),
            const SizedBox(height: 32),
          ]),
        );
      },
    );
  }
}

class BlocksScreen extends ConsumerWidget {
  const BlocksScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Engellenenler')),
        body: AsyncView<List<Json>>(
          value: ref.watch(blocksProvider),
          onRetry: () => ref.invalidate(blocksProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.ban, title: 'Kimseyi engellemedin', body: 'Engellediğin kişiler sana yazamaz ve ilanlarını görmezsin.')
              : ListView(children: [
                  for (final b in items)
                    ListTile(
                      leading: Avatar(url: (b['user'] ?? b)['avatarUrl'], name: (b['user'] ?? b)['displayName'] ?? '?'),
                      title: Text((b['user'] ?? b)['displayName'] ?? ''),
                      trailing: TextButton(
                        onPressed: () async {
                          await ref.read(apiProvider).delete('/users/${(b['user'] ?? b)['id']}/block');
                          ref.invalidate(blocksProvider);
                        },
                        child: const Text('Engeli kaldır'),
                      ),
                    ),
                ]),
        ),
      );
}
