import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

Future<void> showReportSheet(BuildContext context, WidgetRef ref, String targetType, String targetId) async {
  String? reason;
  final note = TextEditingController();
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    builder: (c) => StatefulBuilder(
      builder: (c, set) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 16 + MediaQuery.of(c).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Neden bildiriyorsun?', style: Theme.of(c).textTheme.titleLarge),
            const SizedBox(height: 4),
            const Text('Bildirimin gizli tutulur. Karşı taraf kimin bildirdiğini görmez.', style: TextStyle(color: YkColors.n600)),
            const SizedBox(height: 8),
            RadioGroup<String>(
              groupValue: reason,
              onChanged: (v) => set(() => reason = v),
              child: Column(children: [for (final e in kReportReasons.entries) RadioListTile<String>(contentPadding: EdgeInsets.zero, value: e.key, title: Text(e.value))]),
            ),
            if (reason == 'cocuk_guvenligi' || reason == 'taciz')
              const Padding(padding: EdgeInsets.only(bottom: 8), child: SafetyBanner(text: 'Acil bir tehlike varsa önce 112\'yi ara. Bu bildirim en yüksek öncelikle incelenir.', tone: 'error')),
            TextField(controller: note, maxLines: 3, maxLength: 500, decoration: const InputDecoration(hintText: 'Eklemek istediğin bir şey var mı? (isteğe bağlı)')),
            const SizedBox(height: 8),
            FilledButton(onPressed: reason == null ? null : () => Navigator.pop(c, true), child: const Text('Gönder')),
          ]),
        ),
      ),
    ),
  );
  if (ok != true || !context.mounted) return;
  try {
    await ref.read(apiProvider).post('/reports', {'targetType': targetType, 'targetId': targetId, 'reason': reason, 'note': note.text});
    if (context.mounted) toast(context, 'Teşekkürler. Bildirimin inceleme ekibine iletildi.');
  } catch (e) {
    if (context.mounted) toast(context, errorText(e));
  }
}

Future<bool> blockUser(BuildContext context, WidgetRef ref, String userId, String? name) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text('${name ?? 'Bu kişi'} engellensin mi?'),
      content: const Text('Birbirinizin ilanlarını görmezsiniz ve mesajlaşamazsınız. Engellediğin kişiye bildirim gitmez. Ayarlardan kaldırabilirsin.'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(style: FilledButton.styleFrom(backgroundColor: YkColors.error, minimumSize: const Size(0, 44)), onPressed: () => Navigator.pop(c, true), child: const Text('Engelle'))],
    ),
  );
  if (ok != true) return false;
  try {
    await ref.read(apiProvider).post('/users/$userId/block');
    if (context.mounted) toast(context, 'Kullanıcı engellendi.');
    return true;
  } catch (e) {
    if (context.mounted) toast(context, errorText(e));
    return false;
  }
}
