import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/errors.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

// ---------- Veri kaynakları ----------
List<Json> _items(dynamic r) => List<Json>.from(r is List ? r : (r['items'] ?? []));
final adminStatsProvider = FutureProvider.autoDispose<Json>((ref) => ref.watch(apiProvider).get<Json>('/admin/stats'));
final adminReportsProvider = FutureProvider.autoDispose.family<List<Json>, String>((ref, prio) async => _items(await ref.watch(apiProvider).get('/admin/reports', {'priority': prio.isEmpty ? null : prio})));
final adminCaseProvider = FutureProvider.autoDispose.family<Json, String>((ref, id) => ref.watch(apiProvider).get<Json>('/admin/reports/$id'));
final adminPendingProvider = FutureProvider.autoDispose<List<Json>>((ref) async => _items(await ref.watch(apiProvider).get('/admin/listings/pending')));
final adminUsersProvider = FutureProvider.autoDispose.family<List<Json>, String>((ref, q) async => _items(await ref.watch(apiProvider).get('/admin/users', {'q': q.isEmpty ? null : q})));
final adminUserProvider = FutureProvider.autoDispose.family<Json, String>((ref, id) => ref.watch(apiProvider).get<Json>('/admin/users/$id'));
final adminSupportProvider = FutureProvider.autoDispose.family<List<Json>, String>((ref, status) async => _items(await ref.watch(apiProvider).get('/admin/support', {'status': status})));
final adminAppealsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => _items(await ref.watch(apiProvider).get('/admin/appeals')));
final adminAuditProvider = FutureProvider.autoDispose<List<Json>>((ref) async => _items(await ref.watch(apiProvider).get('/admin/audit')));
final adminRulesProvider = FutureProvider.autoDispose<List<Json>>((ref) async => _items(await ref.watch(apiProvider).get('/admin/rules')));

const kPriorityLabel = {'critical': 'Kritik', 'high': 'Yüksek', 'normal': 'Normal'};
const kReportStatusLabel = {'open': 'Açık', 'in_review': 'İnceleniyor', 'resolved': 'Sonuçlandı', 'dismissed': 'İhlal yok'};
const kListingStatusLabel = {'active': 'Yayında', 'pending_review': 'İncelemede', 'closed': 'Kapandı', 'draft': 'Taslak', 'removed': 'Kaldırıldı', 'expired': 'Süresi doldu'};
const kTargetLabel = {'listing': 'İlan', 'user': 'Kullanıcı', 'message': 'Mesaj'};
const kDecisionLabel = {
  'no_violation': 'İhlal yok', 'remove_content': 'İçeriği kaldır', 'warn': 'Uyarı', 'suspend': 'Geçici askı', 'ban': 'Kalıcı kapatma',
  'approve_listing': 'İlan onaylandı', 'reject_listing': 'İlan reddedildi',
};
const kRoleLabel = {'user': 'Kullanıcı', 'moderator': 'Moderatör', 'admin': 'Yönetici'};
const kUserStatusLabel = {'active': 'Aktif', 'suspended': 'Askıda', 'deleted': 'Silindi'};

Color _prioColor(String? p) => switch (p) { 'critical' => YkColors.error, 'high' => YkColors.warning, _ => YkColors.n600 };

Widget _tag(String text, Color color) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: .1), borderRadius: BorderRadius.circular(6)),
      child: Text(text, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w700)),
    );

bool isStaff(Json? me) => me?['role'] == 'moderator' || me?['role'] == 'admin';

Future<void> _run(BuildContext context, Future<void> Function() f, String ok) async {
  try {
    await f();
    if (context.mounted) toast(context, ok);
  } catch (e) {
    if (context.mounted) toast(context, errorText(e));
  }
}

String _when(dynamic iso) => iso == null ? '' : timeAgo(iso.toString());

// ---------- Ana panel ----------
class AdminHomeScreen extends ConsumerWidget {
  const AdminHomeScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final me = ref.watch(sessionProvider).me;
    final isAdmin = me?['role'] == 'admin';
    return Scaffold(
      appBar: AppBar(title: const Text('Moderasyon paneli'), actions: [IconButton(tooltip: 'Yenile', icon: const Icon(LucideIcons.refreshCw), onPressed: () => ref.invalidate(adminStatsProvider))]),
      body: AsyncView<Json>(
        value: ref.watch(adminStatsProvider),
        onRetry: () => ref.invalidate(adminStatsProvider),
        builder: (s) {
          final cur = s['last7d'] as Map, prev = s['prev7d'] as Map, users = s['users'] as Map, reports = s['reports'] as Map;
          final h = cur['medianFirstReplyHours'], ph = prev['medianFirstReplyHours'];
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(adminStatsProvider),
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: YkColors.green700, borderRadius: BorderRadius.circular(YkRadius.lg)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Ana metrik · son 7 gün', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(h == null ? 'Henüz veri yok' : '$h saat', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                  const Text('İlan yayınlandıktan sonra ilk gerçek yanıta kadar geçen medyan süre', style: TextStyle(color: Colors.white, fontSize: 13)),
                  const SizedBox(height: 10),
                  Text([
                    'Önceki 7 gün: ${ph == null ? '-' : '$ph saat'}',
                    '24 saatte yanıt: ${cur['replyRate24h'] == null ? '-' : '%${cur['replyRate24h']}'}',
                    '${cur['published']} ilan',
                  ].join(' · '), style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                ]),
              ),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.9,
                children: [
                  _StatCard('Açık şikayet', '${reports['open']}', sub: '${reports['critical']} kritik', alert: (reports['critical'] ?? 0) > 0),
                  _StatCard('SLA aşımı', '${reports['slaBreached']}', alert: (reports['slaBreached'] ?? 0) > 0),
                  _StatCard('Onay bekleyen ilan', '${s['pendingListings']}'),
                  _StatCard('Bekleyen itiraz', '${s['pendingAppeals']}'),
                  _StatCard('Kullanıcı', '${users['total']}', sub: '${users['new7d']} yeni (7 gün)'),
                  _StatCard('Aktif (7 gün)', '${users['active7d']}'),
                ],
              ),
              const SizedBox(height: 16),
              _nav(context, LucideIcons.flag, 'Şikayet kuyruğu', '/admin/reports', reports['open']),
              _nav(context, LucideIcons.clipboardCheck, 'Onay bekleyen ilanlar', '/admin/listings', s['pendingListings']),
              _nav(context, LucideIcons.users, 'Kullanıcılar', '/admin/users', null),
              _nav(context, LucideIcons.scale, 'İtirazlar', '/admin/appeals', s['pendingAppeals']),
              _nav(context, LucideIcons.lifeBuoy, 'Destek talepleri', '/admin/support', s['supportOpen']),
              _nav(context, LucideIcons.scrollText, 'Denetim kaydı', '/admin/audit', null),
              if (isAdmin) _nav(context, LucideIcons.listFilter, 'İçerik kuralları', '/admin/rules', null),
              const SizedBox(height: 12),
              const SafetyBanner(text: 'Görüntülediğin her vaka ve kullanıcı denetim kaydına yazılır. Kişisel verilere yalnızca vaka için gerektiği kadar bak.'),
            ]),
          );
        },
      ),
    );
  }

  Widget _nav(BuildContext context, IconData icon, String title, String path, dynamic count) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: Icon(icon, color: YkColors.green700),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            if (count is int && count > 0) _tag('$count', YkColors.green700),
            const SizedBox(width: 4),
            const Icon(LucideIcons.chevronRight, size: 18),
          ]),
          onTap: () => context.push(path),
        ),
      );
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.label, this.value, {this.sub, this.alert = false});
  final String label, value;
  final String? sub;
  final bool alert;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: alert ? YkColors.errorBg : YkColors.n50, borderRadius: BorderRadius.circular(YkRadius.md)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(label, style: const TextStyle(fontSize: 12.5, color: YkColors.n600, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: alert ? YkColors.error : YkColors.n900)),
          if (sub != null) Text(sub!, style: const TextStyle(fontSize: 11.5, color: YkColors.n600)),
        ]),
      );
}

// ---------- Şikayet kuyruğu ----------
class AdminReportsScreen extends ConsumerStatefulWidget {
  const AdminReportsScreen({super.key});
  @override
  ConsumerState<AdminReportsScreen> createState() => _AdminReportsScreenState();
}

class _AdminReportsScreenState extends ConsumerState<AdminReportsScreen> {
  String _prio = '';

  Future<void> _next() async {
    try {
      final r = await ref.read(apiProvider).post<Json>('/admin/reports/next');
      final id = r['report']?['id'];
      if (!mounted) return;
      if (id == null) return toast(context, 'Kuyrukta atanmamış vaka yok.');
      await context.push('/admin/reports/$id');
      ref.invalidate(adminReportsProvider(_prio));
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Şikayet kuyruğu')),
      floatingActionButton: FloatingActionButton.extended(onPressed: _next, icon: const Icon(LucideIcons.inbox), label: const Text('Sıradakini al')),
      body: Column(children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Row(children: [
            for (final p in ['', 'critical', 'high', 'normal'])
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(label: Text(p.isEmpty ? 'Tümü' : kPriorityLabel[p]!), selected: _prio == p, showCheckmark: false, labelStyle: TextStyle(color: _prio == p ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600), onSelected: (_) => setState(() => _prio = p)),
              ),
          ]),
        ),
        Expanded(
          child: AsyncView<List<Json>>(
            value: ref.watch(adminReportsProvider(_prio)),
            onRetry: () => ref.invalidate(adminReportsProvider(_prio)),
            builder: (items) => items.isEmpty
                ? const EmptyState(icon: LucideIcons.circleCheck, title: 'Kuyruk boş', body: 'Bekleyen şikayet yok.')
                : RefreshIndicator(
                    onRefresh: () async => ref.invalidate(adminReportsProvider(_prio)),
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                      itemCount: items.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final r = items[i];
                        return Card(
                          margin: EdgeInsets.zero,
                          child: ListTile(
                            title: Row(children: [
                              _tag(kPriorityLabel[r['priority']] ?? r['priority'], _prioColor(r['priority'])),
                              const SizedBox(width: 6),
                              _tag(kTargetLabel[r['targetType']] ?? r['targetType'], YkColors.info),
                              const SizedBox(width: 6),
                              if (r['slaBreached'] == true) _tag('SLA aşıldı', YkColors.error),
                            ]),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text('${kReportReasons[r['reason']] ?? r['reason']} · ${kReportStatusLabel[r['status']] ?? r['status']} · ${_when(r['createdAt'])}${(r['note'] ?? '').toString().isNotEmpty ? '\n"${r['note']}"' : ''}'),
                            ),
                            trailing: const Icon(LucideIcons.chevronRight, size: 18),
                            onTap: () => context.push('/admin/reports/${r['id']}').then((_) => ref.invalidate(adminReportsProvider(_prio))),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ),
      ]),
    );
  }
}

// ---------- Vaka detayı ve karar ----------
class AdminCaseScreen extends ConsumerStatefulWidget {
  const AdminCaseScreen({super.key, required this.id});
  final String id;
  @override
  ConsumerState<AdminCaseScreen> createState() => _AdminCaseScreenState();
}

class _AdminCaseScreenState extends ConsumerState<AdminCaseScreen> {
  String _action = 'no_violation';
  final _rule = TextEditingController(), _reason = TextEditingController(), _note = TextEditingController();
  int _days = 7;
  bool _busy = false;

  Future<void> _decide() async {
    setState(() => _busy = true);
    try {
      await ref.read(apiProvider).post('/admin/reports/${widget.id}/decide', {
        'action': _action,
        if (_rule.text.trim().isNotEmpty) 'rule': _rule.text.trim(),
        if (_reason.text.trim().isNotEmpty) 'reason': _reason.text.trim(),
        if (_note.text.trim().isNotEmpty) 'internalNote': _note.text.trim(),
        if (_action == 'suspend') 'suspendDays': _days,
      });
      if (mounted) { toast(context, 'Karar kaydedildi. Taraflara bildirim gönderildi.'); context.pop(); }
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = ref.watch(sessionProvider).me?['role'] == 'admin';
    return Scaffold(
      appBar: AppBar(title: const Text('Vaka')),
      body: AsyncView<Json>(
        value: ref.watch(adminCaseProvider(widget.id)),
        onRetry: () => ref.invalidate(adminCaseProvider(widget.id)),
        builder: (c) {
          final r = c['report'] as Map, target = c['target'] as Map? ?? {};
          final owner = c['owner'] as Map?, reporter = c['reporter'] as Map?;
          final closed = r['status'] == 'resolved' || r['status'] == 'dismissed';
          final history = List<Json>.from(c['ownerHistory'] ?? []), related = List<Json>.from(c['relatedReports'] ?? []);
          return ListView(padding: const EdgeInsets.all(16), children: [
            Wrap(spacing: 6, runSpacing: 6, children: [
              _tag(kPriorityLabel[r['priority']] ?? '', _prioColor(r['priority'])),
              _tag(kTargetLabel[r['targetType']] ?? '', YkColors.info),
              _tag(kReportStatusLabel[r['status']] ?? '', YkColors.n600),
            ]),
            const SizedBox(height: 8),
            Text(kReportReasons[r['reason']] ?? r['reason'], style: Theme.of(context).textTheme.titleLarge),
            Text('${_when(r['createdAt'])} · bildiren: ${reporter?['displayName'] ?? 'sistem'} · ${related.length} bildirim', style: const TextStyle(color: YkColors.n600)),
            if ((r['note'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('"${r['note']}"')),
            const SizedBox(height: 16),
            const SectionTitle('İçerik'),
            const SizedBox(height: 8),
            if (target['listing'] != null) _listingBox(target['listing'] as Map),
            if (target['message'] != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: YkColors.n50, borderRadius: BorderRadius.circular(YkRadius.md)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final m in List<Json>.from(target['context'] ?? []))
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        '${m['senderId'] == (owner?['id']) ? (owner?['displayName'] ?? 'Sahip') : 'Karşı taraf'}: ${m['body'] ?? ''}${m['deletedAt'] != null ? ' (silinmiş)' : ''}',
                        style: TextStyle(fontWeight: m['id'] == target['message']['id'] ? FontWeight.w800 : FontWeight.w400, color: m['id'] == target['message']['id'] ? YkColors.error : YkColors.n900),
                      ),
                    ),
                ]),
              ),
            if (r['targetType'] == 'user') const Text('Kullanıcı profiline yönelik şikayet. Ayrıntılar için aşağıdaki kullanıcıyı aç.', style: TextStyle(color: YkColors.n600)),
            const SizedBox(height: 16),
            if (owner != null) ...[
              const SectionTitle('İçerik sahibi'),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Avatar(url: owner['avatarUrl'], name: owner['displayName'] ?? '?'),
                title: Text(owner['displayName'] ?? ''),
                subtitle: Text('${kUserStatusLabel[owner['status']] ?? owner['status']} · üyelik ${_when(owner['createdAt'])}${owner['phone'] != null ? ' · ${owner['phone']}' : ''}'),
                trailing: const Icon(LucideIcons.chevronRight, size: 18),
                onTap: () => context.push('/admin/users/${owner['id']}'),
              ),
              if (history.isNotEmpty) Text('Geçmiş kararlar: ${history.map((d) => kDecisionLabel[d['action']] ?? d['action']).join(', ')}', style: const TextStyle(color: YkColors.warning, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
            ],
            if (closed)
              const SafetyBanner(text: 'Bu vaka kapatıldı.')
            else ...[
              const SectionTitle('Karar'),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final a in ['no_violation', 'remove_content', 'warn', 'suspend', if (isAdmin) 'ban'])
                  ChoiceChip(label: Text(kDecisionLabel[a]!), selected: _action == a, showCheckmark: false, labelStyle: TextStyle(color: _action == a ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600), onSelected: (_) => setState(() => _action = a)),
              ]),
              if (_action == 'suspend') ...[
                const SizedBox(height: 12),
                Row(children: [
                  const Text('Süre: '),
                  for (final d in [1, 3, 7, 30]) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text('$d gün'), selected: _days == d, onSelected: (_) => setState(() => _days = d))),
                ]),
              ],
              if (_action != 'no_violation') ...[
                const SizedBox(height: 12),
                TextField(controller: _rule, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'İhlal edilen kural', hintText: 'Örneğin: 4.2 Ön ödeme talebi')),
                const SizedBox(height: 8),
                TextField(controller: _reason, onChanged: (_) => setState(() {}), maxLines: 2, maxLength: 500, decoration: const InputDecoration(labelText: 'Kullanıcıya gösterilecek gerekçe')),
              ],
              TextField(controller: _note, maxLines: 2, maxLength: 1000, decoration: const InputDecoration(labelText: 'İç not (yalnızca ekip görür)')),
              const SizedBox(height: 8),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: _action == 'ban' ? YkColors.error : null),
                onPressed: _busy || (_action != 'no_violation' && _reason.text.trim().isEmpty && _rule.text.trim().isEmpty) ? null : _decide,
                child: const Text('Kararı kaydet'),
              ),
              const SizedBox(height: 6),
              const Text('Kullanıcı kararı gerekçesiyle görür ve 14 gün içinde itiraz edebilir.', style: TextStyle(fontSize: 12.5, color: YkColors.n600)),
            ],
          ]);
        },
      ),
    );
  }

  Widget _listingBox(Map l) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: YkColors.n50, borderRadius: BorderRadius.circular(YkRadius.md)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 64, height: 64, child: ListingImage(url: l['coverUrl'], category: l['category'], subtype: l['subtype'], radius: 8)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(l['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${kSubtypeLabel[l['subtype']] ?? ''} · ${kListingStatusLabel[l['status']] ?? l['status']}', style: const TextStyle(fontSize: 12.5, color: YkColors.n600)),
            const SizedBox(height: 4),
            Text(l['description'] ?? '', maxLines: 6, overflow: TextOverflow.ellipsis),
            if ((l['moderationFlags'] as List?)?.isNotEmpty == true) Padding(padding: const EdgeInsets.only(top: 4), child: Text('İşaretler: ${(l['moderationFlags'] as List).join(', ')}', style: const TextStyle(color: YkColors.warning, fontSize: 12.5))),
          ])),
        ]),
      );
}

// ---------- Onay bekleyen ilanlar ----------
class AdminPendingListingsScreen extends ConsumerWidget {
  const AdminPendingListingsScreen({super.key});

  Future<void> _reject(BuildContext context, WidgetRef ref, Json l) async {
    final reason = TextEditingController(text: 'İlan topluluk kurallarına uygun değil.');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('İlanı reddet'),
        content: TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Kullanıcıya gösterilecek gerekçe')),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Reddet'))],
      ),
    );
    if (ok != true || !context.mounted) return;
    await _run(context, () => ref.read(apiProvider).post('/admin/listings/${l['id']}/decide', {'action': 'reject', 'reason': reason.text.trim()}), 'İlan reddedildi.');
    ref.invalidate(adminPendingProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Onay bekleyen ilanlar')),
        body: AsyncView<List<Json>>(
          value: ref.watch(adminPendingProvider),
          onRetry: () => ref.invalidate(adminPendingProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.clipboardCheck, title: 'Bekleyen ilan yok', body: 'Kurallara takılan ilanlar burada onay bekler.')
              : ListView(padding: const EdgeInsets.all(16), children: [
                  for (final l in items)
                    Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            SizedBox(width: 64, height: 64, child: ListingImage(url: l['coverUrl'], category: l['category'], subtype: l['subtype'], radius: 8)),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(l['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text('${l['owner']?['displayName'] ?? ''} · ${_when(l['createdAt'])}', style: const TextStyle(fontSize: 12.5, color: YkColors.n600)),
                              if ((l['moderationFlags'] as List?)?.isNotEmpty == true) Text('İşaret: ${(l['moderationFlags'] as List).join(', ')}', style: const TextStyle(fontSize: 12.5, color: YkColors.warning, fontWeight: FontWeight.w600)),
                            ])),
                          ]),
                          const SizedBox(height: 8),
                          Text(l['description'] ?? '', maxLines: 5, overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 10),
                          Row(children: [
                            Expanded(child: OutlinedButton(onPressed: () => _reject(context, ref, l), child: const Text('Reddet'))),
                            const SizedBox(width: 10),
                            Expanded(child: FilledButton(onPressed: () async { await _run(context, () => ref.read(apiProvider).post('/admin/listings/${l['id']}/decide', {'action': 'approve'}), 'İlan yayına alındı.'); ref.invalidate(adminPendingProvider); }, child: const Text('Onayla'))),
                          ]),
                        ]),
                      ),
                    ),
                ]),
        ),
      );
}

// ---------- Kullanıcılar ----------
class AdminUsersScreen extends ConsumerStatefulWidget {
  const AdminUsersScreen({super.key});
  @override
  ConsumerState<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends ConsumerState<AdminUsersScreen> {
  String _q = '';
  final _c = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Kullanıcılar')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(controller: _c, textInputAction: TextInputAction.search, decoration: InputDecoration(prefixIcon: const Icon(LucideIcons.search), hintText: 'Ad veya telefon (05xx...)', suffixIcon: IconButton(icon: const Icon(LucideIcons.arrowRight), onPressed: () => setState(() => _q = _c.text.trim()))), onSubmitted: (v) => setState(() => _q = v.trim())),
          ),
          Expanded(
            child: AsyncView<List<Json>>(
              value: ref.watch(adminUsersProvider(_q)),
              onRetry: () => ref.invalidate(adminUsersProvider(_q)),
              builder: (items) => items.isEmpty
                  ? const EmptyState(icon: LucideIcons.users, title: 'Sonuç yok', body: 'Başka bir ad veya numara dene.')
                  : ListView(children: [
                      for (final u in items)
                        ListTile(
                          leading: Avatar(url: u['avatarUrl'], name: u['displayName'] ?? '?'),
                          title: Text(u['displayName'] ?? ''),
                          subtitle: Text('${kRoleLabel[u['role']] ?? u['role']} · ${u['neighborhood'] ?? '-'}'),
                          trailing: u['status'] == 'active' ? null : _tag(kUserStatusLabel[u['status']] ?? u['status'], YkColors.error),
                          onTap: () => context.push('/admin/users/${u['id']}').then((_) => ref.invalidate(adminUsersProvider(_q))),
                        ),
                    ]),
            ),
          ),
        ]),
      );
}

class AdminUserScreen extends ConsumerWidget {
  const AdminUserScreen({super.key, required this.id});
  final String id;

  Future<void> _action(BuildContext context, WidgetRef ref, String action, {String? role}) async {
    final reason = TextEditingController();
    int days = 7;
    if (action != 'unsuspend' && action != 'set_role') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => StatefulBuilder(
          builder: (c, set) => AlertDialog(
            title: Text({'warn': 'Uyarı ver', 'suspend': 'Geçici askıya al', 'ban': 'Hesabı kalıcı kapat'}[action]!),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              if (action == 'suspend') Wrap(spacing: 6, children: [for (final d in [1, 3, 7, 30]) ChoiceChip(label: Text('$d gün'), selected: days == d, onSelected: (_) => set(() => days = d))]),
              const SizedBox(height: 8),
              TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Kullanıcıya gösterilecek gerekçe')),
            ]),
            actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Uygula'))],
          ),
        ),
      );
      if (ok != true) return;
    }
    if (!context.mounted) return;
    await _run(context, () => ref.read(apiProvider).post('/admin/users/$id/action', {'action': action, if (action == 'suspend') 'suspendDays': days, 'role': ?role, if (reason.text.trim().isNotEmpty) 'reason': reason.text.trim()}), 'İşlem uygulandı.');
    ref.invalidate(adminUserProvider(id));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isAdmin = ref.watch(sessionProvider).me?['role'] == 'admin';
    return Scaffold(
      appBar: AppBar(title: const Text('Kullanıcı')),
      body: AsyncView<Json>(
        value: ref.watch(adminUserProvider(id)),
        onRetry: () => ref.invalidate(adminUserProvider(id)),
        builder: (d) {
          final u = d['user'] as Map;
          final listings = List<Json>.from(d['listings']), reports = List<Json>.from(d['reports']), decisions = List<Json>.from(d['decisions']);
          return ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              Avatar(url: u['avatarUrl'], name: u['displayName'] ?? '?', size: 56),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(u['displayName'] ?? '', style: Theme.of(context).textTheme.titleLarge),
                Text('${kRoleLabel[u['role']]} · ${kUserStatusLabel[u['status']] ?? u['status']}${u['suspendedUntil'] != null ? ' (${dayLabel(u['suspendedUntil'])} tarihine kadar)' : ''}', style: const TextStyle(color: YkColors.n600)),
                if (u['phone'] != null) Text(u['phone'], style: const TextStyle(color: YkColors.n600)),
              ])),
            ]),
            const SizedBox(height: 16),
            Wrap(spacing: 8, runSpacing: 8, children: [
              OutlinedButton(onPressed: () => _action(context, ref, 'warn'), child: const Text('Uyarı')),
              if (u['status'] != 'suspended') OutlinedButton(onPressed: () => _action(context, ref, 'suspend'), child: const Text('Askıya al')),
              if (u['status'] == 'suspended') OutlinedButton(onPressed: () => _action(context, ref, 'unsuspend'), child: const Text('Askıyı kaldır')),
              if (isAdmin) OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: YkColors.error), onPressed: () => _action(context, ref, 'ban'), child: const Text('Kalıcı kapat')),
              if (isAdmin)
                PopupMenuButton<String>(
                  onSelected: (r) => _action(context, ref, 'set_role', role: r),
                  itemBuilder: (_) => [for (final e in kRoleLabel.entries) PopupMenuItem(value: e.key, child: Text(e.value))],
                  child: const Padding(padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10), child: Text('Rol değiştir', style: TextStyle(color: YkColors.green700, fontWeight: FontWeight.w600))),
                ),
            ]),
            const SizedBox(height: 20),
            SectionTitle('Kararlar (${decisions.length})'),
            for (final x in decisions) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text(kDecisionLabel[x['action']] ?? x['action']), subtitle: Text('${x['reason'] ?? ''} · ${_when(x['createdAt'])}')),
            const SizedBox(height: 12),
            SectionTitle('Hakkındaki şikayetler (${reports.length})'),
            for (final x in reports) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text(kReportReasons[x['reason']] ?? x['reason']), subtitle: Text('${kReportStatusLabel[x['status']]} · ${_when(x['createdAt'])}'), onTap: () => context.push('/admin/reports/${x['id']}')),
            const SizedBox(height: 12),
            SectionTitle('İlanlar (${listings.length})'),
            for (final l in listings) ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text(l['title'] ?? ''), subtitle: Text('${kListingStatusLabel[l['status']] ?? l['status']} · ${_when(l['createdAt'])}')),
          ]);
        },
      ),
    );
  }
}

// ---------- İtirazlar ----------
class AdminAppealsScreen extends ConsumerWidget {
  const AdminAppealsScreen({super.key});

  Future<void> _resolve(BuildContext context, WidgetRef ref, Json a, bool accept) async {
    final c = TextEditingController(text: accept ? 'Karar yeniden incelendi ve kaldırıldı.' : 'Karar yeniden incelendi ve uygun bulundu.');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(accept ? 'İtirazı kabul et' : 'İtirazı reddet'),
        content: TextField(controller: c, maxLines: 3, decoration: const InputDecoration(labelText: 'Kullanıcıya gösterilecek sonuç')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Kaydet'))],
      ),
    );
    if (ok != true || !context.mounted) return;
    await _run(context, () => ref.read(apiProvider).post('/admin/appeals/${a['id']}/resolve', {'accept': accept, 'resolution': c.text.trim()}), 'İtiraz sonuçlandı.');
    ref.invalidate(adminAppealsProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('İtirazlar')),
        body: AsyncView<List<Json>>(
          value: ref.watch(adminAppealsProvider),
          onRetry: () => ref.invalidate(adminAppealsProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.scale, title: 'Bekleyen itiraz yok', body: 'Kullanıcıların kararlara itirazları burada görünür.')
              : ListView(padding: const EdgeInsets.all(16), children: [
                  for (final a in items)
                    Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Karar: ${kDecisionLabel[a['decision']?['action']] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          if ((a['decision']?['reason'] ?? '').toString().isNotEmpty) Text('Gerekçe: ${a['decision']['reason']}', style: const TextStyle(color: YkColors.n600)),
                          const SizedBox(height: 8),
                          Text('"${a['note']}"'),
                          Text(_when(a['createdAt']), style: const TextStyle(fontSize: 12.5, color: YkColors.n500)),
                          const SizedBox(height: 10),
                          Row(children: [
                            Expanded(child: OutlinedButton(onPressed: () => _resolve(context, ref, a, false), child: const Text('Reddet'))),
                            const SizedBox(width: 10),
                            Expanded(child: FilledButton(onPressed: () => _resolve(context, ref, a, true), child: const Text('Kabul et'))),
                          ]),
                        ]),
                      ),
                    ),
                  const Text('Bir itirazı, kararı veren moderatör değerlendiremez.', style: TextStyle(fontSize: 12.5, color: YkColors.n600)),
                ]),
        ),
      );
}

// ---------- Destek talepleri ----------
class AdminSupportScreen extends ConsumerStatefulWidget {
  const AdminSupportScreen({super.key});
  @override
  ConsumerState<AdminSupportScreen> createState() => _AdminSupportScreenState();
}

class _AdminSupportScreenState extends ConsumerState<AdminSupportScreen> {
  String _status = 'open';

  Future<void> _reply(Json t) async {
    final c = TextEditingController();
    final status = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Yanıtla · ${t['ticketNo']}'),
        content: TextField(controller: c, maxLines: 5, maxLength: 2000, decoration: const InputDecoration(labelText: 'Kullanıcıya gösterilecek yanıt')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          OutlinedButton(onPressed: () => Navigator.pop(ctx, 'closed'), child: const Text('Yanıtla ve kapat')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'answered'), child: const Text('Yanıtla')),
        ],
      ),
    );
    final text = c.text.trim();
    c.dispose();
    if (status == null || !mounted) return;
    if (text.isEmpty) {
      toast(context, 'Yanıt boş olamaz.');
      return;
    }
    await _run(context, () => ref.read(apiProvider).post('/admin/support/${t['id']}/reply', {'reply': text, 'status': status}), 'Yanıt gönderildi.');
    ref.invalidate(adminSupportProvider);
    ref.invalidate(adminStatsProvider);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Destek talepleri')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Wrap(spacing: 8, children: [
              for (final e in const {'open': 'Açık', 'answered': 'Yanıtlandı', 'closed': 'Kapalı'}.entries)
                ChoiceChip(
                  label: Text(e.value),
                  selected: _status == e.key,
                  showCheckmark: false,
                  labelStyle: TextStyle(color: _status == e.key ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600),
                  onSelected: (_) => setState(() => _status = e.key),
                ),
            ]),
          ),
          Expanded(
            child: AsyncView<List<Json>>(
              value: ref.watch(adminSupportProvider(_status)),
              onRetry: () => ref.invalidate(adminSupportProvider(_status)),
              builder: (items) => items.isEmpty
                  ? const EmptyState(icon: LucideIcons.lifeBuoy, title: 'Talep yok', body: 'Bu durumda destek talebi bulunmuyor.')
                  : ListView(padding: const EdgeInsets.all(16), children: [
                      for (final t in items)
                        Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${t['ticketNo']} · ${t['subject']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                              const SizedBox(height: 2),
                              Text('${t['user']?['displayName'] ?? 'Kullanıcı'} · ${_when(t['createdAt'])}', style: const TextStyle(fontSize: 12.5, color: YkColors.n500)),
                              const SizedBox(height: 8),
                              Text('${t['body']}'),
                              if ((t['reply'] ?? '').toString().isNotEmpty) ...[
                                const SizedBox(height: 8),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(color: YkColors.green50, borderRadius: BorderRadius.circular(YkRadius.sm)),
                                  child: Text('Yanıt: ${t['reply']}'),
                                ),
                              ],
                              if (t['status'] != 'closed') ...[
                                const SizedBox(height: 10),
                                SizedBox(width: double.infinity, child: FilledButton(onPressed: () => _reply(t), child: Text(t['status'] == 'answered' ? 'Tekrar yanıtla' : 'Yanıtla'))),
                              ],
                            ]),
                          ),
                        ),
                    ]),
            ),
          ),
        ]),
      );
}

// ---------- Denetim kaydı ----------
class AdminAuditScreen extends ConsumerWidget {
  const AdminAuditScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Denetim kaydı')),
        body: AsyncView<List<Json>>(
          value: ref.watch(adminAuditProvider),
          onRetry: () => ref.invalidate(adminAuditProvider),
          builder: (items) => ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, _) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final a = items[i];
              return ListTile(
                dense: true,
                title: Text(a['action'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'monospace')),
                subtitle: Text('${a['targetType'] ?? ''} ${(a['targetId'] ?? '').toString().split('-').first} · ${_when(a['createdAt'])}'),
              );
            },
          ),
        ),
      );
}

// ---------- İçerik kuralları ----------
class AdminRulesScreen extends ConsumerWidget {
  const AdminRulesScreen({super.key});

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final p = TextEditingController(), l = TextEditingController();
    String match = 'contains', action = 'review';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: const Text('Yeni kural'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: p, decoration: const InputDecoration(labelText: 'Kelime veya ifade')),
            const SizedBox(height: 8),
            TextField(controller: l, decoration: const InputDecoration(labelText: 'Etiket (ör. Yasaklı ürün)')),
            const SizedBox(height: 12),
            const Text('Eşleşme', style: TextStyle(fontWeight: FontWeight.w600)),
            Wrap(spacing: 6, children: [for (final m in {'exact': 'Tam kelime', 'contains': 'İçerir', 'regex': 'Düzenli ifade'}.entries) ChoiceChip(label: Text(m.value), selected: match == m.key, onSelected: (_) => set(() => match = m.key))]),
            const SizedBox(height: 8),
            const Text('İşlem', style: TextStyle(fontWeight: FontWeight.w600)),
            Wrap(spacing: 6, children: [for (final m in {'block': 'Engelle', 'review': 'İncelemeye al', 'warn': 'Uyar'}.entries) ChoiceChip(label: Text(m.value), selected: action == m.key, onSelected: (_) => set(() => action = m.key))]),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ekle'))],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    await _run(context, () => ref.read(apiProvider).post('/admin/rules', {'pattern': p.text.trim(), 'matchType': match, 'action': action, if (l.text.trim().isNotEmpty) 'label': l.text.trim()}), 'Kural eklendi.');
    ref.invalidate(adminRulesProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final api = ref.read(apiProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('İçerik kuralları')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _add(context, ref), icon: const Icon(LucideIcons.plus), label: const Text('Kural ekle')),
      body: AsyncView<List<Json>>(
        value: ref.watch(adminRulesProvider),
        onRetry: () => ref.invalidate(adminRulesProvider),
        builder: (items) => ListView(padding: const EdgeInsets.only(bottom: 96), children: [
          for (final r in items)
            SwitchListTile(
              title: Text(r['pattern'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${r['label'] ?? ''} · ${{'exact': 'tam kelime', 'contains': 'içerir', 'regex': 'regex'}[r['matchType']]} · ${{'block': 'engelle', 'review': 'incelemeye al', 'warn': 'uyar'}[r['action']]}'),
              value: r['active'] != false,
              onChanged: (v) async {
                await _run(context, () => api.patch('/admin/rules/${r['id']}', {'active': v}), v ? 'Kural açıldı.' : 'Kural kapatıldı.');
                ref.invalidate(adminRulesProvider);
              },
              secondary: IconButton(
                tooltip: 'Sil',
                icon: const Icon(LucideIcons.trash2, size: 18),
                onPressed: () async {
                  await _run(context, () => api.delete('/admin/rules/${r['id']}'), 'Kural silindi.');
                  ref.invalidate(adminRulesProvider);
                },
              ),
            ),
        ]),
      ),
    );
  }
}

// ---------- Kullanıcının kendi şikayetleri ----------
final myReportsProvider = FutureProvider.autoDispose<List<Json>>((ref) async => _items(await ref.watch(apiProvider).get('/me/reports')));

class MyReportsScreen extends ConsumerWidget {
  const MyReportsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        appBar: AppBar(title: const Text('Bildirimlerim')),
        body: AsyncView<List<Json>>(
          value: ref.watch(myReportsProvider),
          onRetry: () => ref.invalidate(myReportsProvider),
          builder: (items) => items.isEmpty
              ? const EmptyState(icon: LucideIcons.flag, title: 'Bildirim göndermedin', body: 'Şikayet ettiğin içerikler ve sonuçları burada görünür.')
              : ListView(children: [
                  for (final r in items)
                    ListTile(
                      leading: const Icon(LucideIcons.flag, color: YkColors.green700),
                      title: Text('${kTargetLabel[r['targetType']]} · ${kReportReasons[r['reason']] ?? r['reason']}'),
                      subtitle: Text(_when(r['createdAt'])),
                      trailing: _tag(kReportStatusLabel[r['status']] ?? r['status'], r['status'] == 'open' || r['status'] == 'in_review' ? YkColors.warning : YkColors.green700),
                    ),
                ]),
        ),
      );
}
