import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../../core/api.dart';
import '../../core/format.dart';
import '../../core/providers.dart';
import '../../ui/theme.dart';
import '../../ui/widgets.dart';

/// Harita: ilanlar gerçek yerinden 150-300 m kaydırılmış sabit noktalarda gösterilir.
/// OpenStreetMap kullanılır (API anahtarı gerekmez). Üretimde kendi karo sunucusu veya ticari sağlayıcı önerilir.
class MapScreen extends ConsumerStatefulWidget {
  const MapScreen({super.key});
  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  final _map = MapController();
  List<Json> _items = [];
  Json? _selected;
  String? _category;
  Timer? _d;

  Future<void> _load() async {
    final b = _map.camera.visibleBounds;
    try {
      final r = await ref.read(apiProvider).get<Json>('/listings/map', {'bbox': '${b.west},${b.south},${b.east},${b.north}', 'category': _category});
      if (mounted) setState(() => _items = List<Json>.from(r['items']));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(sessionProvider).me;
    final hoods = ref.watch(neighborhoodsProvider).value ?? [];
    final myHood = hoods.where((h) => h['id'] == (me?['neighborhood'] as Map?)?['id']).firstOrNull;
    final center = myHood == null ? const LatLng(37.7210, 30.2895) : LatLng((myHood['center']['lat'] as num).toDouble(), (myHood['center']['lng'] as num).toDouble());
    return Scaffold(
      body: Stack(children: [
        FlutterMap(
          mapController: _map,
          options: MapOptions(
            initialCenter: center,
            initialZoom: 14.5,
            minZoom: 11,
            maxZoom: 17,
            onMapReady: _load,
            onMapEvent: (e) {
              if (e is MapEventMoveEnd || e is MapEventFlingAnimationEnd) { _d?.cancel(); _d = Timer(const Duration(milliseconds: 300), _load); }
            },
            onTap: (_, _) => setState(() => _selected = null),
          ),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'app.yakin.yakin'),
            if (_selected != null)
              CircleLayer(circles: [CircleMarker(point: LatLng(_selected!['lat'], _selected!['lng']), radius: 300, useRadiusInMeter: true, color: YkColors.category(_selected!['category']).withValues(alpha: .12), borderColor: YkColors.category(_selected!['category']).withValues(alpha: .5), borderStrokeWidth: 1.5)]),
            MarkerLayer(markers: [
              for (final it in _items)
                Marker(
                  point: LatLng((it['lat'] as num).toDouble(), (it['lng'] as num).toDouble()),
                  width: 36,
                  height: 36,
                  child: GestureDetector(
                    onTap: () => setState(() => _selected = it),
                    child: Semantics(
                      button: true,
                      label: it['title'],
                      child: Container(
                        decoration: BoxDecoration(color: YkColors.category(it['category']), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2.5), boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 6, offset: Offset(0, 2))]),
                        child: Icon(categoryIcon(it['category'], it['subtype']), size: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ),
            ]),
            const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap katkıcıları')]),
          ],
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  for (final (k, l) in [(null, 'Tümü'), ('esya', 'Eşya'), ('yardim', 'Yardım'), ('kayip', 'Kayıp')])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(l),
                        selected: _category == k,
                        showCheckmark: false,
                        backgroundColor: Colors.white,
                        labelStyle: TextStyle(color: _category == k ? Colors.white : YkColors.n900, fontWeight: FontWeight.w600),
                        onSelected: (_) { setState(() => _category = k); _load(); },
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: .95), borderRadius: BorderRadius.circular(999)),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(LucideIcons.shieldCheck, size: 14, color: YkColors.green700), SizedBox(width: 6), Text('Konumlar yaklaşık gösterilir', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600))]),
              ),
            ]),
          ),
        ),
        if (_selected != null)
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Material(
              color: Colors.white,
              elevation: 4,
              borderRadius: BorderRadius.circular(YkRadius.lg),
              child: InkWell(
                borderRadius: BorderRadius.circular(YkRadius.lg),
                onTap: () => context.push('/listings/${_selected!['id']}'),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    SizedBox(width: 72, height: 72, child: ListingImage(url: _selected!['coverUrl'], category: _selected!['category'], subtype: _selected!['subtype'])),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      CategoryPill(category: _selected!['category'], subtype: _selected!['subtype']),
                      const SizedBox(height: 6),
                      Text(_selected!['title'], maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(priceText(_selected!['subtype'], _selected!['priceKurus']), style: TextStyle(fontWeight: FontWeight.w700, color: YkColors.category(_selected!['category']))),
                    ])),
                    const Icon(LucideIcons.chevronRight, color: YkColors.n500),
                  ]),
                ),
              ),
            ),
          ),
      ]),
    );
  }
}
