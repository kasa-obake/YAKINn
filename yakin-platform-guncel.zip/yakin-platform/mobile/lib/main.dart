import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/router.dart';
import 'core/providers.dart';
import 'core/session.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('tr_TR');
  final session = Session()..init();
  runApp(ProviderScope(overrides: [sessionProvider.overrideWithValue(session)], child: YakinApp(session: session)));
}

class YakinApp extends StatefulWidget {
  const YakinApp({super.key, required this.session});
  final Session session;
  @override
  State<YakinApp> createState() => _YakinAppState();
}

class _YakinAppState extends State<YakinApp> {
  late final _router = buildRouter(widget.session);

  @override
  Widget build(BuildContext context) => MaterialApp.router(
        title: 'YAKIN',
        debugShowCheckedModeBanner: false,
        theme: ykTheme(),
        routerConfig: _router,
        locale: const Locale('tr', 'TR'),
        supportedLocales: const [Locale('tr', 'TR')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
      );
}
