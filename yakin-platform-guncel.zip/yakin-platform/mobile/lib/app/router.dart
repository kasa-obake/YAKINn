import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

import '../core/session.dart';
import '../features/admin/admin_screens.dart';
import '../features/auth/auth_screens.dart';
import '../features/chat/chat_screens.dart';
import '../features/home/feed_screen.dart';
import '../features/legal/legal_screen.dart';
import '../features/listing/create_screen.dart';
import '../features/listing/detail_screen.dart';
import '../features/listing/my_listings_screen.dart';
import '../features/map/map_screen.dart';
import '../features/profile/profile_screens.dart';
import '../features/profile/totp_screen.dart';
import '../ui/theme.dart';
import '../ui/widgets.dart';

const _authPaths = {'/welcome', '/auth/phone', '/auth/otp'};

GoRouter buildRouter(Session session) => GoRouter(
      initialLocation: '/',
      refreshListenable: session,
      redirect: (context, state) {
        final loc = state.matchedLocation;
        switch (session.state) {
          case AuthState.loading:
            return loc == '/splash' ? null : '/splash';
          case AuthState.signedOut:
            return (_authPaths.contains(loc) || loc.startsWith('/legal/')) ? null : '/welcome';
          case AuthState.needsProfile:
            return loc == '/auth/profile' ? null : '/auth/profile';
          case AuthState.ready:
            if (loc == '/splash' || _authPaths.contains(loc) || loc == '/auth/profile') return '/';
            if (loc.startsWith('/admin') && !isStaff(session.me)) return '/';
            return null;
        }
      },
      routes: [
        GoRoute(path: '/splash', builder: (_, _) => const _Splash()),
        GoRoute(path: '/welcome', builder: (_, _) => const WelcomeScreen()),
        GoRoute(path: '/auth/phone', builder: (_, _) => const PhoneScreen()),
        GoRoute(path: '/auth/otp', builder: (_, s) => OtpScreen(args: Map<String, dynamic>.from((s.extra as Map?) ?? {}))),
        GoRoute(path: '/auth/profile', builder: (_, _) => const ProfileSetupScreen()),
        StatefulShellRoute.indexedStack(
          builder: (context, state, shell) => _Shell(shell: shell, session: session),
          branches: [
            StatefulShellBranch(routes: [GoRoute(path: '/', builder: (_, _) => const FeedScreen())]),
            StatefulShellBranch(routes: [GoRoute(path: '/map', builder: (_, _) => const MapScreen())]),
            StatefulShellBranch(routes: [GoRoute(path: '/messages', builder: (_, _) => const ConversationsScreen())]),
            StatefulShellBranch(routes: [GoRoute(path: '/profile', builder: (_, _) => const ProfileScreen())]),
          ],
        ),
        GoRoute(path: '/create', builder: (_, _) => const CreateListingScreen()),
        GoRoute(path: '/search', builder: (_, _) => const SearchScreen()),
        GoRoute(path: '/listings/:id', builder: (_, s) => ListingDetailScreen(id: s.pathParameters['id']!)),
        GoRoute(path: '/listings/:id/review', builder: (_, s) => ReviewScreen(listingId: s.pathParameters['id']!, toName: s.extra as String?)),
        GoRoute(path: '/chat/:id', builder: (_, s) => ChatScreen(id: s.pathParameters['id']!)),
        GoRoute(path: '/users/:id', builder: (_, s) => PublicProfileScreen(id: s.pathParameters['id']!)),
        GoRoute(path: '/notifications', builder: (_, _) => const NotificationsScreen()),
        GoRoute(path: '/me/listings', builder: (_, _) => const MyListingsScreen()),
        GoRoute(path: '/me/favorites', builder: (_, _) => const FavoritesScreen()),
        GoRoute(path: '/me/pending-reviews', builder: (_, _) => const PendingReviewsScreen()),
        GoRoute(path: '/settings', builder: (_, _) => const SettingsScreen()),
        GoRoute(path: '/settings/blocks', builder: (_, _) => const BlocksScreen()),
        GoRoute(path: '/settings/totp', builder: (_, _) => const TotpScreen()),
        GoRoute(path: '/legal/:kind', builder: (_, s) => LegalScreen(kind: s.pathParameters['kind']!)),
        GoRoute(path: '/decisions', builder: (_, _) => const DecisionsScreen()),
        GoRoute(path: '/decisions/:id', builder: (_, _) => const DecisionsScreen()),
        GoRoute(path: '/me/reports', builder: (_, _) => const MyReportsScreen()),
        GoRoute(path: '/admin', builder: (_, _) => const AdminHomeScreen()),
        GoRoute(path: '/admin/reports', builder: (_, _) => const AdminReportsScreen()),
        GoRoute(path: '/admin/reports/:id', builder: (_, s) => AdminCaseScreen(id: s.pathParameters['id']!)),
        GoRoute(path: '/admin/listings', builder: (_, _) => const AdminPendingListingsScreen()),
        GoRoute(path: '/admin/users', builder: (_, _) => const AdminUsersScreen()),
        GoRoute(path: '/admin/users/:id', builder: (_, s) => AdminUserScreen(id: s.pathParameters['id']!)),
        GoRoute(path: '/admin/appeals', builder: (_, _) => const AdminAppealsScreen()),
        GoRoute(path: '/admin/support', builder: (_, _) => const AdminSupportScreen()),
        GoRoute(path: '/admin/audit', builder: (_, _) => const AdminAuditScreen()),
        GoRoute(path: '/admin/rules', builder: (_, _) => const AdminRulesScreen()),
      ],
    );

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) => const Scaffold(
        backgroundColor: YkColors.green700,
        body: Center(child: Text('YAKIN', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w800, letterSpacing: 2))),
      );
}

class _Shell extends StatelessWidget {
  const _Shell({required this.shell, required this.session});
  final StatefulNavigationShell shell;
  final Session session;

  @override
  Widget build(BuildContext context) {
    // Sekmeler: 0 Ana sayfa, 1 Harita, [İlan ver], 2 Mesajlar, 3 Profil
    final navIndex = shell.currentIndex >= 2 ? shell.currentIndex + 1 : shell.currentIndex;
    return Scaffold(
      body: shell,
      bottomNavigationBar: ValueListenableBuilder(
        valueListenable: session.badges,
        builder: (context, b, _) => NavigationBar(
          selectedIndex: navIndex,
          onDestinationSelected: (i) {
            if (i == 2) {
              context.push('/create');
              return;
            }
            final branch = i > 2 ? i - 1 : i;
            shell.goBranch(branch, initialLocation: branch == shell.currentIndex);
          },
          destinations: [
            const NavigationDestination(icon: Icon(LucideIcons.house), label: 'Ana sayfa'),
            const NavigationDestination(icon: Icon(LucideIcons.map), label: 'Harita'),
            NavigationDestination(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(color: YkColors.green700, shape: BoxShape.circle),
                child: const Icon(LucideIcons.plus, color: Colors.white, size: 22),
              ),
              label: 'İlan ver',
            ),
            NavigationDestination(icon: BadgeIcon(icon: LucideIcons.messageCircle, count: (b['messages'] ?? 0) as int), label: 'Mesajlar'),
            NavigationDestination(icon: BadgeIcon(icon: LucideIcons.user, count: (b['pendingReviews'] ?? 0) as int), label: 'Profil'),
          ],
        ),
      ),
    );
  }
}
