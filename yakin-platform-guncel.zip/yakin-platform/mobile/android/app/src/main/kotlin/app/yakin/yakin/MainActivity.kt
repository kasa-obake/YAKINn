package app.yakin.yakin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
