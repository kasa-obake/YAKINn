# YAKIN mobil uygulaması (Flutter)

Burdur için yerel yardımlaşma ve ilan uygulaması. Android ve web için derlenir. Sunucu: `../backend`.

## Çalıştırma

```bash
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000   # Android emülatörü (bilgisayardaki API)
```

Gerçek telefonda `API_URL` bilgisayarın yerel ağ adresi veya sunucu adresi olmalıdır. `API_URL` verilmezse emülatör adresi kullanılır.

## Sürüm APK

```bash
flutter build apk --release --dart-define=API_URL=https://api.ornekalanadi.com
# Çıktı: build/app/outputs/flutter-apk/app-release.apk
```

Android Studio kurmadan derlemek için GitHub'daki **Actions > Android APK** iş akışı kullanılabilir (kök README'ye bakın).
Release imzası için `android/key.properties` yoksa APK debug anahtarıyla imzalanır; doğrudan telefona yüklemek için yeterlidir, mağaza için değildir.

## Yapı

- `lib/core`: API istemcisi, oturum, hata metinleri, ayarlar
- `lib/features`: özellik ekranları (`auth`, `home`, `listing`, `chat`, `profile`, `admin`, `safety`, `map`, `legal`)
- `lib/ui`: tema ve ortak bileşenler
- `test`: birim ve widget testleri (`flutter test`)

## Yayından önce

- `lib/features/legal/legal_screen.dart` içindeki hukuki metinler **taslaktır**: hukuk danışmanı onayından sonra [köşeli parantezleri] doldurun ve `kLegalIsDraft` değerini `false` yapın.
- Sürüm numarası `pubspec.yaml` (`version`) ve `lib/core/config.dart` (`kAppVersion`) içinde birlikte güncellenmelidir.
- Push bildirim için Firebase kurulumu henüz yapılmadı (kök README, "Anlık bildirimler").
