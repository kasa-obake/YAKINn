# YAKIN platformu

"İhtiyacın varsa yakınında biri vardır."

Bu depo YAKIN'ın gerçek, çok kullanıcılı sürümünün ilk altyapısını içerir. İlk hizmet bölgesi Burdur'dur.

| Katman | Teknoloji | Klasör |
|---|---|---|
| Mobil uygulama | Flutter 3 (Android, Web) | `mobile/` |
| API | NestJS 11, TypeORM, socket.io | `backend/` |
| Veritabanı | PostgreSQL 16+ ve PostGIS | `docker-compose.yml` |

## Mimari

```
Flutter (Riverpod, go_router, dio, socket.io)
        │  REST /v1  +  WebSocket (socket.io)
        ▼
NestJS API ── Auth (OTP + JWT, yenileme belirteci rotasyonu)
          ├── Users, Geo (mahalleler, PostGIS)
          ├── Listings (akış, harita, arama, ilan yaşam döngüsü, değerlendirme)
          ├── Chat (sohbet, mesaj, okundu, yazıyor, güvenlik uyarıları)
          ├── Notifications (uygulama içi + push bağdaştırıcısı, sessiz saatler)
          ├── Safety (şikayet, öncelik/SLA, otomatik gizleme)
          ├── Moderation (kuyruk, kararlar, itiraz, denetim kaydı, yönetici API)
          └── Media (yükleme, EXIF/konum silme, boyutlandırma)
        │
        ▼
PostgreSQL + PostGIS (konum sorguları, trigram arama, Türkçe karakter duyarsız arama)
```

Güvenlik ilkeleri koda gömülüdür:

- Tam adres hiçbir zaman tutulmaz veya gösterilmez. İlan konumları 150-300 m kaydırılır, mesafeler yuvarlanır ("300 m'den yakın").
- Canlı konum paylaşımı yoktur.
- Telefon numarası diğer kullanıcılara gösterilmez; soyadın yalnızca baş harfi görünür.
- Fotoğraflardaki EXIF ve GPS bilgisi sunucuda silinir.
- Mesajlarda IBAN, kapora, bağlantı, uygulama dışı iletişim ve kargo kalıpları için uyarı kartı gösterilir; IBAN göndermeden önce onay istenir.
- 3 farklı kullanıcıdan şikayet alan veya kritik şikayet alan içerik otomatik gizlenir.
- Moderasyon kararları gerekçesiyle kullanıcıya gösterilir ve itiraz edilebilir (KVKK, 5651).
- Reklam alanı yoktur; mesajların içine veya yardım taleplerinin önüne reklam konmaz.

## Hızlı başlangıç (Docker, yerel geliştirme)

```bash
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d --build db api
docker compose -f docker-compose.yml -f docker-compose.dev.yml exec api npm run seed:prod   # mahalleler, kurallar, örnek hesaplar ve ilanlar
```

API: `http://localhost:3000/v1` · Swagger: `http://localhost:3000/docs` · Sağlık: `/v1/health`

`docker-compose.dev.yml` yalnızca kendi bilgisayarın içindir: doğrulama kodu API yanıtında döner, veritabanı portu yerelde açıktır. **Sunucuya bu dosyayla kurma.**

## Üretim kurulumu (VPS + alan adı + HTTPS)

`docker-compose.yml` güvenli varsayılanlarla gelir: veritabanı dışarı kapalı, kod API yanıtında dönmez, HTTPS'i Caddy otomatik alır. Eksik veya zayıf ayar varsa API **açılmaz** ve nedenini yazar (`docker compose logs api`).

1. Alan adının A kaydını sunucunun IP'sine yönlendir; sunucuda 80 ve 443 açık olsun.
2. `cp .env.example .env` ve doldur (`openssl rand -base64 48` ile iki farklı JWT anahtarı, veritabanı parolası, Netgsm bilgileri, alan adı).
3. `docker compose up -d --build`
4. `docker compose exec api npm run seed:prod` (yalnızca mahalleler ve içerik kuralları; örnek hesap/ilan eklenmez)
5. `docker compose exec api npm run admin:create:prod -- 5XXXXXXXXX admin` (gerçek yönetici, aşağıya bakın)
6. `docker compose exec api npm run sms:check:prod -- 5XXXXXXXXX` ile deneme SMS'i

Mobil uygulamayı bu adrese göre derle: `flutter build apk --release --dart-define=API_URL=https://api.ornekalanadi.com`

## GitHub ile otomatik test ve APK (Android Studio kurmadan)

Proje kök klasöründe `.github/workflows` altında iki iş akışı vardır:

- **CI** (`ci.yml`): her push'ta backend'i gerçek PostgreSQL + PostGIS ile test eder, mobilde `flutter analyze` ve `flutter test` çalıştırır.
- **Android APK** (`android-apk.yml`): elle çalıştırılır ve APK üretir.

Adımlar: GitHub'da (özel) bir depo aç, bu klasörün içeriğini depoya yükle (GitHub Desktop veya `git push`). Kök klasör deponun kökü olmalı (`backend`, `mobile`, `.github` yan yana). Sonra **Actions > Android APK > Run workflow** de, API adresini yaz (`https://api.ornekalanadi.com`), iş bitince sayfanın altındaki **Artifacts > yakin-apk** dosyasını indir (zip içinde `app-release.apk`).

> Mobil kod Flutter olmayan bir ortamda yazıldı: yalnızca sözdizimi denetlendi, `flutter analyze` ve `flutter test` henüz hiç çalışmadı. İlk CI çalışmasında hata çıkarsa çıktıyı paylaşın, birlikte düzeltelim.

## Yerel kurulum (Docker olmadan)

Gereken: Node.js 20+, PostgreSQL 16+ ve PostGIS 3.

```bash
createuser -s yakin && createdb -O yakin yakin    # parola: yakin
cd backend
cp .env.example .env
npm install
npm run migration:run
npm run seed
npm run start:dev
```

Testler (ayrı `yakin_test` veritabanı kullanır, `.env.test`):

```bash
createdb -O yakin yakin_test
npm test              # birim testleri (Netgsm SMS bağdaştırıcısı)
npm run test:e2e      # 14 uçtan uca senaryo: giriş, ilan, sohbet, IBAN onayı, şikayet, moderasyon, itiraz...
```

### Netgsm ile gerçek SMS

Doğrulama kodları Netgsm'in OTP kanalından (`POST https://api.netgsm.com.tr/sms/rest/v2/otp`, HTTP Basic) gönderilir. Bu kanal hızlıdır, tek SMS boyundadır ve Türkçe karakter kodlaması desteklemez. Bu yüzden metin "YAKIN dogrulama kodun: 123456. Kodu kimseyle paylasma." biçiminde gider. `NETGSM_OTP=false` ile normal SMS kanalı (`/sms/rest/v2/send`, Türkçe karakterli) kullanılabilir.

Netgsm tarafında hazırlık ([API ile SMS rehberi](https://bilgibankasi.netgsm.com.tr/sms/toplu-sms/api-ile-sms), [API hazırlık rehberi](https://bilgibankasi.netgsm.com.tr/entegrasyonlar/api-entegrasyonu-hazirlik-rehberi), [OTP SMS](https://bilgibankasi.netgsm.com.tr/sms/otp-sms)):

1. Hesapta onaylı bir gönderici adı (başlık) olmalı, örneğin `YAKIN`.
2. OTP SMS paketi tanımlanmalı. Normal SMS kanalı için SMS paketi yeterli.
3. Abonelik İşlemleri > Alt Kullanıcı Hesapları menüsünden "API Kullanıcısı" türünde bir alt kullanıcı oluşturulmalı ve SMS yetkisi verilmeli.
4. Abonelik İşlemleri > API İşlemleri menüsünden API erişimi açılmalı. IP kısıtlaması kullanılıyorsa sunucunun IP adresi eklenmeli.

Sunucuda:

```bash
SMS_PROVIDER=netgsm
NETGSM_USERCODE=850xxxxxxx     # abone numarası
NETGSM_PASSWORD=...            # API alt kullanıcısının şifresi
NETGSM_HEADER=YAKIN
OTP_DEV_ECHO=false
OTP_FIXED_CODE=

npm run sms:check                 # kimlik bilgisi ve başlık kontrolü, SMS göndermez
npm run sms:check -- 5XXXXXXXXX   # ayrıca deneme SMS'i gönderir
# Docker'da: docker compose exec api npm run sms:check:prod -- 5XXXXXXXXX
```

Davranış:
- Kalıcı hatalarda (yanlış şifre `30`, tanımsız başlık `40`, OTP kredisi yok `60` vb.) tekrar denenmez. Kullanıcıya "Kod gönderilemedi" mesajı döner (`AUTH_SMS_FAILED`, HTTP 502).
- Ağ hatası, zaman aşımı ve Netgsm sistem hatasında (`100`, `101`) bir kez daha denenir. Yine olmazsa HTTP 503 döner.
- Gönderilemeyen kod veritabanından silinir, kod isteme sınırına sayılmaz ve önceki geçerli kodu iptal etmez.
- Loglarda numara maskelenir (`532*****67`), kod ve şifre hiçbir zaman yazılmaz.

### Ortam değişkenleri

| Değişken | Açıklama |
|---|---|
| `DATABASE_URL` | PostgreSQL bağlantısı |
| `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` | Üretimde uzun, rastgele ve birbirinden farklı olmalı |
| `JWT_ACCESS_TTL`, `JWT_REFRESH_TTL_DAYS` | Varsayılan 15 dk ve 30 gün |
| `SMS_PROVIDER` | `console` (kod loga yazılır) veya `netgsm`. Üretimde `console` ile sunucu açılmaz |
| `NETGSM_USERCODE`, `NETGSM_PASSWORD`, `NETGSM_HEADER` | Netgsm abone numarası, API alt kullanıcısı şifresi, onaylı gönderici adı |
| `NETGSM_OTP` | `true` (varsayılan): hızlı OTP kanalı. `false`: normal SMS |
| `OTP_DEV_ECHO` | `true` ise kod API yanıtında da döner (yalnızca geliştirme) |
| `OTP_FIXED_CODE` | Geliştirmede sabit kod (ör. `123456`) |
| `MEDIA_DRIVER`, `MEDIA_DIR` | `local` (disk) veya `s3`. Ayrıntı: Dosya depolama |
| `S3_BUCKET`, `S3_REGION`, `S3_ENDPOINT`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_PUBLIC_BASE_URL`, `S3_FORCE_PATH_STYLE` | `MEDIA_DRIVER=s3` için |
| `SMS_DAILY_LIMIT` | Günlük en çok SMS (varsayılan 2000, `0` sınırsız). Aşılınca kod isteği `503 AUTH_SMS_BUDGET` döner |
| `ADMIN_TOTP_REQUIRED` | `true`: iki adımlı doğrulaması olmayan yönetici/moderatör yönetim uçlarını kullanamaz (varsayılan `false`) |
| `TOTP_ENCRYPTION_KEY` | TOTP sırlarını şifreler. Boşsa `JWT_REFRESH_SECRET` kullanılır |
| `ALLOW_INSECURE_HTTP` | `true`: üretimde https zorunluluğu uyarıya düşer (yalnızca geçici deneme) |
| `SEED_DEMO` | `false`: `seed` örnek hesap ve ilan eklemez (üretimde zaten eklenmez) |
| `PUBLIC_BASE_URL` | Medya bağlantılarının kök adresi |
| `CORS_ORIGINS` | Virgülle ayrılmış izinli kökenler. Üretimde `*` olamaz; boşsa tarayıcıdan çapraz köken isteği kabul edilmez (Android uygulaması için sorun değildir) |
| `JOBS_ENABLED` | Süre dolumu ve hatırlatma görevleri. Birden çok sunucuda yalnızca birinde `true` |
| `SERVICE_CITY` | MVP hizmet şehri (Burdur) |

### Örnek hesaplar (seed, yalnızca geliştirme)

Bu hesaplar ve örnek ilanlar `NODE_ENV=production` iken **eklenmez**. Geliştirmede doğrulama kodu `123456`'dır (veya ekranda gösterilen geliştirme kodu).

| Rol | Telefon |
|---|---|
| Yönetici | +90 555 000 00 01 |
| Moderatör | +90 555 000 00 02 |
| Ayşe K. | +90 555 000 00 11 |
| Mehmet D. | +90 555 000 00 12 |
| Zeynep A. | +90 555 000 00 13 |

## İşletme

### Yönetici hesabı oluşturma

Seed'deki yönetici numarası sahtedir ve üretimde yoktur. Gerçek bir numarayı yönetici yapmak için:

```bash
npm run admin:create -- 5XXXXXXXXX                    # yönetici (yoksa hesap oluşturur)
npm run admin:create -- 5XXXXXXXXX moderator          # moderatör
npm run admin:create -- 5XXXXXXXXX user               # rolü kaldırır
npm run admin:create -- 5XXXXXXXXX admin --reset-totp # iki adımlı doğrulamayı sıfırlar (telefon kaybında)
# Docker: docker compose exec api npm run admin:create:prod -- 5XXXXXXXXX admin
```

Numara normal SMS koduyla giriş yapar. İşlem denetim günlüğüne `admin.cli_role` olarak yazılır.

### İki adımlı doğrulama (TOTP, yönetici/moderatör)

Google Authenticator, Authy vb. ile uyumludur (RFC 6238). Uçlar: `POST /me/totp/setup` (sır ve `otpauth://` adresi döner), `POST /me/totp/enable {code}`, `POST /me/totp/disable {code}`. Etkinleştirilen hesap girişte `totpCode` göndermek zorundadır (`401 AUTH_TOTP_REQUIRED`, `AUTH_TOTP_INVALID`). Sırlar veritabanında AES-256-GCM ile şifrelidir. `ADMIN_TOTP_REQUIRED=true` ise kurulum yapmamış yöneticiler yönetim uçlarında `403 TOTP_SETUP_REQUIRED` alır.

> Mobilde Ayarlar > İki adımlı doğrulama (kurulum ve kapatma) ve girişte ikinci kod alanı vardır. Bu ekranlar henüz gerçek bir cihazda denenmedi. Bir yöneticide etkinleştirmeden önce başka bir yöneticinin hazır olduğundan emin olun; telefon kaybında kurtarma yolu: `npm run admin:create -- 5XXXXXXXXX admin --reset-totp`. `ADMIN_TOTP_REQUIRED=true` yapmadan önce tüm yönetici ve moderatörlerin TOTP'yi kurduğunu doğrulayın.

### Hesap silme (KVKK) ve bakım işleri

`POST /me/delete` hesabı kapatır, oturumları sonlandırır ve 30 günlük bekleme başlatır. Her saat çalışan bakım işi (`JOBS_ENABLED=true`):

- 30 günü dolan hesapları **anonimleştirir**: ad, telefon, doğum yılı, profil, mesaj metinleri ve fotoğrafları, ilan içerikleri ve fotoğrafları, favoriler, engeller, bildirimler, cihaz ve oturum kayıtları, destek talepleri silinir. Hesap `deleted` olur; aynı numara sonradan yeni hesap açabilir.
- Anonim kimlikle **kalanlar**: puanlar, moderasyon kayıtları (şikayet, itiraz, karar) ve denetim günlüğü. Hangi kayıtların ne kadar saklanacağı (KVKK, 5651) bir hukuk danışmanıyla netleştirilmelidir.
- 2 günden eski OTP kayıtlarını, süresi geçmiş oturumları ve 180 günden eski bildirimleri siler.
- 24 saatten eski olup hiçbir yerde kullanılmayan fotoğrafları (dosya dahil) siler.

### Destek talepleri

Kullanıcı `POST /support` ile talep açar (`YK-000123` numarası döner). Moderatör/yönetici `GET /admin/support?status=open|answered|closed` ile listeler, `POST /admin/support/:id/reply {reply, status?}` ile yanıtlar; yanıt kullanıcıya bildirim olarak gider. Mobilde: Profil > Moderasyon paneli > Destek talepleri (açık talep sayısı rozetle görünür).

### Kötüye kullanım sınırları

- Kod isteği: telefon başına 10 dakikada 3, IP başına 10 dakikada 15, günlük toplam `SMS_DAILY_LIMIT`. Telefon/IP sınırı bellekte tutulur (tek sunucu için yeterli).
- Doğrulama: kod başına 5 deneme. CAPTCHA/cihaz doğrulaması yoktur (hesap gerektirir).
- Socket: bağlanırken hesabın etkin olduğu kontrol edilir; askıya alınan veya silinen kullanıcının bağlantıları anında kapatılır; `typing` olayı saniyede en çok bir kez işlenir. Bağlantı kimliği yalnızca bağlanırken doğrulanır, erişim jetonu süresi dolunca bağlantı kapanmaz.

### Dosya depolama

`MEDIA_DRIVER=local` (varsayılan) fotoğrafları sunucu diskinde (`/app/uploads` hacmi) saklar. `MEDIA_DRIVER=s3` ile AWS S3, Cloudflare R2, MinIO, Wasabi gibi S3 uyumlu bir depoya geçilir: `S3_BUCKET`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_PUBLIC_BASE_URL` (CDN veya bucket'ın herkese açık adresi) zorunludur; AWS dışı sağlayıcılar için `S3_ENDPOINT` (MinIO için ayrıca `S3_FORCE_PATH_STYLE=true`). Bucket'a herkese açık okuma izni veya önünde CDN gerekir; nesnelere ACL yazılmaz. Depoyu değiştirmek, eski fotoğrafları taşımaz (eski adresler çalışmaya devam etmez, önce dosyaları kopyalayın).

### Anlık bildirimler (push)

`PushProvider` (`src/modules/core/push.provider.ts`) şimdilik yalnızca log tutar. Cihaz belirteci uçları (`/me/devices`) hazırdır, ancak mobil uygulama henüz belirteç kaydetmez. Gerçek bildirim için: Firebase projesi, `google-services.json` ve mobilde `firebase_messaging`; sunucuda FCM sağlayıcısının `PushProvider` arayüzüne uygulanması gerekir.

## API özeti

Tüm uçlar `/v1` altında, ayrıntılar Swagger'da.

- Giriş: `POST /auth/otp/request`, `POST /auth/otp/verify`, `POST /auth/refresh`, `POST /auth/logout`, `/me/devices`
- Profil: `GET/PATCH /me`, `/me/stats`, `/me/export` (KVKK), `POST /me/delete`, `/users/:id`, engelleme
- Konum: `GET /neighborhoods`, `POST /neighborhoods/resolve`
- İlanlar: `GET /listings` (akış, filtre, arama), `/listings/map`, `/listings/count`, `POST /listings`, kapat, yeniden aç, süre uzat, favori, değerlendirme, `/me/listings`, `/me/favorites`, `/me/pending-reviews`
- Sohbet: `/conversations`, mesajlar (imleçli sayfalama), okundu, arşiv, sessize alma, mesaj silme (10 dk)
- Bildirim: `/notifications`, `/badges`, `/support`, `/app/config`
- Güvenlik: `POST /reports`, `/me/reports`, `/me/decisions`, itiraz
- Yönetim (moderatör/yönetici): `/admin/stats`, şikayet kuyruğu, ilan onayı, kullanıcı işlemleri, itirazlar, denetim kaydı, kurallar
- Gerçek zamanlı olaylar (socket.io, `auth.token` ile): `message:new`, `message:read`, `message:deleted`, `typing`, `conversation:updated`, `listing:status`, `notification:new`

## Mobil uygulama

```bash
cd mobile
flutter pub get
# Android emülatörü bilgisayardaki API'ye 10.0.2.2 ile ulaşır
flutter run --dart-define=API_URL=http://10.0.2.2:3000
# Gerçek telefon için bilgisayarın yerel ağ adresini verin
flutter run --dart-define=API_URL=http://192.168.1.20:3000
# Sürüm APK
flutter build apk --release --dart-define=API_URL=https://api.ornek-alanadi.com
```

Ekranlar: karşılama, telefon ve kod ile giriş, profil kurulumu (mahalle seçimi), ana akış (kategori, filtre, yakınındaki yardım talepleri), arama, harita (OpenStreetMap, yaklaşık konumlar), ilan detayı, 4 adımlı ilan verme (fotoğraf yükleme dahil), ilanlarım (kapatma, teslim edilen kişiyi seçme, süre uzatma), sohbet listesi ve gerçek zamanlı sohbet (uyarı kartları, IBAN onayı, okundu, yazıyor), değerlendirme, profil, herkese açık profil, favoriler, bildirimler, ayarlar (gizlilik, bildirim tercihleri, sessiz saatler, mahalle değiştirme, engellenenler, veri indirme, hesap silme, destek), kararlar ve itiraz, gönderilen şikayetler, mesaj şikayeti (mesaja uzun basma).

Yönetim paneli (yalnızca moderatör ve yönetici rolünde, Profil > Moderasyon paneli): ana metrik ve özet sayılar, öncelik filtreli şikayet kuyruğu ve "Sıradakini al", vaka ekranı (içerik, mesaj bağlamı, içerik sahibinin geçmişi, karar formu), onay bekleyen ilanlar, kullanıcı arama ve işlemleri (uyarı, askıya alma, yasaklama, rol), itirazlar (kararı veren moderatör kendi kararına bakamaz), denetim kaydı, içerik kuralları (yalnızca yönetici).

### Tarayıcıda uçtan uca test

`tools/web-e2e/e2e.mjs`, uygulamanın web derlemesini Playwright ile gerçek arka uca karşı çalıştırır: fotoğraflı ilan verme, ilanı kapatıp teslim edilen kişiyi seçme, değerlendirme, ayarlar, bildirimler, mesaj şikayeti, kurala takılan ilanın onayı, moderatör kararı, kullanıcının uygulamadan itirazı, yöneticinin itirazı sonuçlandırması ve kural ekleme.

```bash
cd mobile && flutter build web --release --dart-define=API_URL=http://localhost:3000
(cd build/web && python3 -m http.server 8080) &
node tools/web-e2e/e2e.mjs   # playwright-core ve Chromium gerekir
```

Android imzası: `mobile/android/key.properties` varsa sürüm anahtarıyla, yoksa debug anahtarıyla imzalanır. `key.properties` ve anahtar dosyası depoya eklenmez.

## Henüz taslak olan kısımlar

- **Mobil uygulama:** hukuki metin, destek yönetimi ve TOTP ekranları eklendi ancak Flutter'da derlenip çalıştırılmadı (yalnızca sözdizimi denetlendi). Push belirteci kaydı yok. Testler az: hata metinleri ve hukuki metin ekranı.
- **Hukuki metinler:** kullanım koşulları, KVKK aydınlatma ve gizlilik metni **taslak** olarak uygulamada (`mobile/lib/features/legal/legal_screen.dart`). [Köşeli parantezli] yerler doldurulup hukuk danışmanı onaylayınca `kLegalIsDraft` değeri `false` yapılmalı; mağazalar için ayrıca herkese açık bir gizlilik politikası adresi gerekir.
- **SMS:** Netgsm bağlantısı hazır; gerçek hesapla uçtan uca gönderim denenmedi. CAPTCHA/cihaz doğrulaması yok.
- **Push bildirim:** FCM bağlı değil (yukarıya bakın).
- **S3:** adaptör istek biçimi birim testle doğrulandı; gerçek bir depoyla denenmedi.
- **Mahalle verisi:** yalnızca 10 mahalle (Merkez), koordinatlar yaklaşık. Resmi sınır verisiyle doğrulanmalı, diğer ilçeler eklenmeli.
- **Harita:** OpenStreetMap herkese açık karo sunucusu. Yoğun kullanımda kendi karo sunucusu veya ticari sağlayıcı gerekir.
- **iOS:** derleme eklenmedi (`flutter create --platforms ios .`, Mac ve Apple Developer hesabı gerekir).
- **Yönetim paneli** mobil uygulamanın içinde; geniş ekran için ayrı web düzeni yok.
- **Yaş kontrolü** yalnızca beyan edilen doğum yılına bakar.
- **Yedekleme, hata izleme, metrik** kurulmadı.
- **Bağımlılıklar:** `npm audit` 3 orta düzey bulgu gösterir (typeorm içindeki `glob`/`minimatch`, yalnızca yapılandırmadaki dosya yollarını işler). TypeORM 1.x'e geçişte kapanır.

## Üretime çıkış listesi

- [ ] VPS, alan adı, `.env` doldurulmuş, `docker compose up -d --build` (güvensiz ayarla API açılmaz)
- [ ] `seed:prod` ve `admin:create:prod` ile gerçek yönetici
- [ ] `sms:check:prod` ile Netgsm deneme SMS'i
- [ ] Android: release imzası (`key.properties`), `usesCleartextTraffic` kaldırılmalı (yalnızca geliştirme için açık)
- [ ] Mobil: CI'da `flutter analyze` + `flutter test` geçmeli, gerçek telefonda deneme; hukuki metinler onaylanıp `kLegalIsDraft=false`; FCM
- [ ] Kullanım koşulları, KVKK aydınlatma/açık rıza metinleri, VERBİS kaydı; 5651 kapsamında log saklama; veri saklama süreleri
- [ ] Günlük veritabanı yedeği (`pg_dump`) ve geri yükleme denemesi; fotoğraf hacmi/S3 yedeği
- [ ] Hata izleme ve metrikler (ana metrik: ilan sonrası ilk gerçek yanıta kadar geçen süre)
- [ ] `JOBS_ENABLED=true` yalnızca tek sunucuda

Not: Geliştirme ortamındaki API kalıcı bir sunucu değildir. Uygulamanın birden çok kişiyle kullanılabilmesi için yukarıdaki üretim kurulumu gerekir.
