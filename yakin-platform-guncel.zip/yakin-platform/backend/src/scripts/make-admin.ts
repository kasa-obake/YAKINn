/**
 * Gerçek bir telefon numarasını yönetici/moderatör yapar (yoksa oluşturur).
 *   npm run admin:create -- 5XXXXXXXXX            -> yönetici
 *   npm run admin:create -- 5XXXXXXXXX moderator   -> moderatör
 *   npm run admin:create -- 5XXXXXXXXX user        -> rolü kaldırır
 *   npm run admin:create -- 5XXXXXXXXX admin --reset-totp   -> iki adımlı doğrulamayı sıfırlar
 * Docker: docker compose exec api npm run admin:create:prod -- 5XXXXXXXXX admin
 */
import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { normalizePhone } from '../common/format';
import { dataSourceOptions } from '../database/data-source';
import { User, UserRole } from '../database/entities';

async function main() {
  try { require('dotenv').config({ path: process.env.ENV_FILE || '.env', quiet: true }); } catch { /* dotenv yoksa ortam değişkenleri yeterli */ }
  const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
  const resetTotp = process.argv.includes('--reset-totp');
  const phone = normalizePhone(args[0] || '');
  const role = (args[1] || 'admin') as UserRole;
  if (!phone || !Object.values(UserRole).includes(role)) {
    console.error('Kullanım: npm run admin:create -- 5XXXXXXXXX [admin|moderator|user] [--reset-totp]');
    process.exit(1);
  }
  const ds = await new DataSource(dataSourceOptions(process.env.DATABASE_URL)).initialize();
  const repo = ds.getRepository(User);
  let user = await repo.findOne({ where: { phone } });
  const created = !user;
  if (!user) user = await repo.save(repo.create({ phone, role }));
  else await repo.update(user.id, { role, ...(resetTotp ? { totpSecret: null, totpEnabledAt: null } : {}) });
  await ds.query(`INSERT INTO audit_logs ("actorId", action, "targetType", "targetId", meta) VALUES (NULL, $1, 'user', $2, $3)`, [
    'admin.cli_role', user.id, JSON.stringify({ role, created, resetTotp }),
  ]);
  console.log(`${created ? 'Hesap oluşturuldu' : 'Hesap güncellendi'}: ${phone.slice(0, 6)}***${phone.slice(-2)} -> rol: ${role}${resetTotp ? ' (iki adımlı doğrulama sıfırlandı)' : ''}`);
  console.log('Bu numarayla uygulamaya giriş yapıldığında Profil > Moderasyon paneli görünür.');
  await ds.destroy();
}

main().catch((e) => { console.error(e); process.exit(1); });
