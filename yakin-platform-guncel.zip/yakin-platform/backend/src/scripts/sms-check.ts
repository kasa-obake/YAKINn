/**
 * Netgsm bağlantısını dener.
 *   npm run sms:check                 -> kimlik bilgileri ve başlığı kontrol eder (SMS göndermez)
 *   npm run sms:check -- 5XXXXXXXXX   -> ayrıca bu numaraya deneme SMS'i gönderir
 */
import 'dotenv/config';
import { ConfigService } from '@nestjs/config';
import { NetgsmSmsProvider } from '../modules/auth/sms.provider';

async function main() {
  const p = NetgsmSmsProvider.fromConfig(new ConfigService(process.env));
  const h = await p.checkHeaders();
  console.log(`Başlık kontrolü: ${h.ok ? 'TAMAM' : 'HATA'} (kod ${h.code}) ${h.message}${h.headers.length ? ` | hesaptaki başlıklar: ${h.headers.join(', ')}` : ''}`);
  const to = process.argv[2];
  if (to) {
    await p.send(to.startsWith('+') ? to : `+90${to.replace(/^0/, '')}`, 'YAKIN deneme mesajı. Bu bir testtir.');
    console.log('Deneme SMS\'i Netgsm tarafından kabul edildi.');
  }
  if (!h.ok) process.exit(1);
}
main().catch((e) => { console.error('Hata:', e.providerCode ?? '', e.message); process.exit(1); });
