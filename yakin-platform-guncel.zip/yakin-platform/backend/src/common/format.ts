export function normalizePhone(input: string): string | null {
  const digits = String(input || '').replace(/[^\d+]/g, '');
  const m = digits.match(/^(?:\+?90|0)?(5\d{9})$/);
  return m ? `+90${m[1]}` : null;
}
export const maskPhone = (p: string) => p.replace(/^(\+90)(\d{3})\d{5}(\d{2})$/, '$1 $2 *** ** $3');

/** Cursor tabanlı sayfalama: (createdAt, id) çiftinin base64 kodu. */
export function encodeCursor(createdAt: Date, id: string) {
  return Buffer.from(`${createdAt.toISOString()}|${id}`).toString('base64url');
}
export function decodeCursor(c?: string): { createdAt: Date; id: string } | null {
  if (!c) return null;
  try {
    const [d, id] = Buffer.from(c, 'base64url').toString().split('|');
    const createdAt = new Date(d);
    return Number.isNaN(createdAt.getTime()) || !id ? null : { createdAt, id };
  } catch { return null; }
}
export const clampLimit = (n: unknown, def = 20, max = 50) => Math.min(Math.max(Number(n) || def, 1), max);
