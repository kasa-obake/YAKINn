import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from 'crypto';

/** RFC 6238 TOTP (SHA-1, 6 hane, 30 sn). Google Authenticator, Authy vb. ile uyumludur. */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(buf: Buffer): string {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(s: string): Buffer {
  let bits = 0, value = 0;
  const out: number[] = [];
  for (const ch of s.replace(/=+$/, '').toUpperCase()) {
    const i = B32.indexOf(ch);
    if (i < 0) throw new Error('Geçersiz base32');
    value = (value << 5) | i;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export const generateTotpSecret = () => base32Encode(randomBytes(20));

function hotp(secret: Buffer, counter: number): string {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const h = createHmac('sha1', secret).update(msg).digest();
  const o = h[h.length - 1] & 15;
  const code = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(code % 1_000_000).padStart(6, '0');
}

export function totpCode(secretB32: string, nowMs = Date.now(), stepSec = 30): string {
  return hotp(base32Decode(secretB32), Math.floor(nowMs / 1000 / stepSec));
}

/** Önceki ve sonraki 30 sn'lik pencereyi de kabul eder (saat farkı payı). */
export function verifyTotp(secretB32: string, code: string, nowMs = Date.now(), window = 1): boolean {
  if (!/^\d{6}$/.test(code || '')) return false;
  const secret = base32Decode(secretB32);
  const counter = Math.floor(nowMs / 1000 / 30);
  let ok = false;
  for (let w = -window; w <= window; w++) {
    const a = Buffer.from(hotp(secret, counter + w));
    if (timingSafeEqual(a, Buffer.from(code))) ok = true;
  }
  return ok;
}

export const otpauthUrl = (secretB32: string, account: string, issuer = 'YAKIN') =>
  `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secretB32}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;

const key = (k: string) => createHash('sha256').update(`yakin-totp:${k}`).digest();

/** Sırrı veritabanında şifreli saklamak için AES-256-GCM. Biçim: iv.etiket.şifreli (base64url). */
export function encryptSecret(plain: string, k: string): string {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', key(k), iv);
  const enc = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64url')).join('.');
}

export function decryptSecret(blob: string, k: string): string {
  const [iv, tag, enc] = blob.split('.').map((s) => Buffer.from(s, 'base64url'));
  const d = createDecipheriv('aes-256-gcm', key(k), iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
}
