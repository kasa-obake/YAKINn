/**
 * Kural tabanlı güvenlik sinyalleri (tasarım dokümanı F6 ve F3).
 * Mesajlar engellenmez; alıcıya bağlamsal uyarı kartı gösterilir. IBAN için gönderen onayı istenir.
 */
export type WarningType = 'payment' | 'link' | 'contact' | 'shipping';

const RULES: [WarningType, RegExp][] = [
  ['payment', /\bTR\s?\d{2}(\s?\d{4}){5}\s?\d{2}\b|\biban\b|kapora|ön\s?ödeme|havale|eft\b|papara|hediye\s?kart|kripto|bitcoin/i],
  ['link', /https?:\/\/|www\.|\b[a-z0-9-]+\.(com|net|org|xyz|io|link|ly)\b/i],
  ['contact', /whatsapp|telegram|\b0?5\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}\b/i],
  ['shipping', /kargo(yla| ile)?\s?(gönder|yolla|at)/i],
];

export function messageWarnings(text: string): WarningType[] {
  return RULES.filter(([, r]) => r.test(text)).map(([t]) => t);
}

export const IBAN_RE = /\bTR\s?\d{2}(\s?\d{4}){5}\s?\d{2}\b/i;
export const PHONE_RE = /\b(\+?90)?\s?0?5\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}\b/;

/** İlan metninde iletişim bilgisi tespiti (yayını engellemez, uyarı döner). */
export function listingContactWarnings(text: string) {
  const out: string[] = [];
  if (PHONE_RE.test(text)) out.push('phone');
  if (IBAN_RE.test(text)) out.push('iban');
  return out;
}
