/**
 * Üretimde (NODE_ENV=production) güvensiz yapılandırmayla açılışı reddeder.
 * Geliştirmede yalnızca uyarı verir. Test ortamında hiçbir şey yapmaz.
 */
export function validateEnv(env: NodeJS.ProcessEnv = process.env): { errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (env.NODE_ENV === 'test') return { errors, warnings };
  const prod = env.NODE_ENV === 'production';
  const bad = (msg: string, soft = false) => (prod && !soft ? errors : warnings).push(msg);

  const hint = ' (rastgele anahtar için: openssl rand -base64 48)';
  const a = env.JWT_ACCESS_SECRET;
  const r = env.JWT_REFRESH_SECRET;
  for (const [name, v] of [['JWT_ACCESS_SECRET', a], ['JWT_REFRESH_SECRET', r]] as const) {
    if (!v) bad(`${name} tanımlı değil${hint}`);
    else if (v.length < 32) bad(`${name} en az 32 karakter olmalı${hint}`);
    else if (/degistir|changeme|change-me|example|ornek|secret/i.test(v)) bad(`${name} varsayılan veya örnek bir değer içeriyor${hint}`);
  }
  if (a && r && a === r) bad('JWT_ACCESS_SECRET ve JWT_REFRESH_SECRET birbirinden farklı olmalı');
  if (env.OTP_DEV_ECHO === 'true') bad('OTP_DEV_ECHO=true: doğrulama kodu API yanıtında döner, herkes herhangi bir hesaba girebilir. Üretimde false olmalı');
  if (env.OTP_FIXED_CODE) bad('OTP_FIXED_CODE üretimde boş olmalı');
  if (env.SMS_PROVIDER !== 'netgsm') bad('SMS_PROVIDER=netgsm olmalı (console yalnızca geliştirme içindir)');
  if ((env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).includes('*')) bad('CORS_ORIGINS üretimde * olamaz. Mobil uygulama için boş bırakın, web için izinli adresleri yazın');
  if (!/^https:\/\//.test(env.PUBLIC_BASE_URL || '')) bad('PUBLIC_BASE_URL https:// ile başlamalı (Android\'de açık metin trafiği kapatılacak)', env.ALLOW_INSECURE_HTTP === 'true');
  if (!env.DATABASE_URL) bad('DATABASE_URL tanımlı değil');
  if (/:yakin@/.test(env.DATABASE_URL || '')) bad('Veritabanı parolası varsayılan "yakin" olamaz');
  return { errors, warnings };
}

export function assertEnv(env: NodeJS.ProcessEnv = process.env, log: (m: string) => void = console.warn) {
  const { errors, warnings } = validateEnv(env);
  warnings.forEach((w) => log(`[yapılandırma uyarısı] ${w}`));
  if (errors.length) {
    throw new Error(`Güvensiz üretim yapılandırması, sunucu açılmadı:\n - ${errors.join('\n - ')}`);
  }
}
