import { HttpException, HttpStatus } from '@nestjs/common';

/**
 * Tüm hatalar { code, message, details } zarfıyla döner (tasarım dokümanı 17.4).
 * İstemci kullanıcıya gösterilecek metni `code` alanına göre kendi kataloğundan seçer.
 */
export class AppError extends HttpException {
  constructor(public readonly code: string, message: string, status = HttpStatus.BAD_REQUEST, public readonly details: Record<string, unknown> = {}) {
    super({ code, message, details }, status);
  }
}

export const Errors = {
  unauthorized: () => new AppError('AUTH_REQUIRED', 'Oturum gerekli', HttpStatus.UNAUTHORIZED),
  forbidden: () => new AppError('FORBIDDEN', 'Bu işlem için yetkin yok', HttpStatus.FORBIDDEN),
  notFound: (what = 'Kayıt') => new AppError('NOT_FOUND', `${what} bulunamadı`, HttpStatus.NOT_FOUND),
  rateLimited: (retryAfterSec?: number) => new AppError('RATE_LIMITED', 'Çok fazla istek', HttpStatus.TOO_MANY_REQUESTS, retryAfterSec ? { retryAfterSec } : {}),
};
