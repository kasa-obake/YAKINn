import { CanActivate, createParamDecorator, ExecutionContext, Injectable, SetMetadata } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole, UserStatus } from '../database/entities';
import { AppError, Errors } from './errors';

export const IS_PUBLIC = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC, true);
export const ROLES = 'roles';
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES, roles);
/** Profili tamamlanmamış kullanıcıların da erişebileceği uç noktalar. */
export const ALLOW_INCOMPLETE = 'allowIncomplete';
export const AllowIncompleteProfile = () => SetMetadata(ALLOW_INCOMPLETE, true);
/** Askıya alınmış kullanıcıların da erişebileceği uç noktalar (itiraz, yardım). */
export const ALLOW_SUSPENDED = 'allowSuspended';
export const AllowSuspended = () => SetMetadata(ALLOW_SUSPENDED, true);

export const CurrentUser = createParamDecorator((_d: unknown, ctx: ExecutionContext): User => ctx.switchToHttp().getRequest().user);

export type JwtPayload = { sub: string; role: UserRole };

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private reflector: Reflector, private jwt: JwtService, @InjectRepository(User) private users: Repository<User>) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const targets = [ctx.getHandler(), ctx.getClass()];
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, targets)) return true;
    const req = ctx.switchToHttp().getRequest();
    const h: string = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';
    if (!token) throw Errors.unauthorized();
    let payload: JwtPayload;
    try {
      payload = await this.jwt.verifyAsync<JwtPayload>(token);
    } catch {
      throw new AppError('AUTH_TOKEN_EXPIRED', 'Oturum süresi doldu', 401);
    }
    const user = await this.users.findOne({ where: { id: payload.sub } });
    if (!user || user.status === UserStatus.DELETED) throw Errors.unauthorized();
    await this.liftExpiredSuspension(user);
    if (user.status === UserStatus.SUSPENDED && !this.reflector.getAllAndOverride<boolean>(ALLOW_SUSPENDED, targets)) {
      throw new AppError('ACCOUNT_SUSPENDED', 'Hesap askıda', 403, { until: user.suspendedUntil });
    }
    const roles = this.reflector.getAllAndOverride<UserRole[]>(ROLES, targets);
    if (roles?.length && !roles.includes(user.role)) throw Errors.forbidden();
    // ADMIN_TOTP_REQUIRED=true iken iki adımlı doğrulaması olmayan yönetici/moderatör yönetim uçlarını kullanamaz.
    if (roles?.length && process.env.ADMIN_TOTP_REQUIRED === 'true' && !user.totpEnabledAt) {
      throw new AppError('TOTP_SETUP_REQUIRED', 'Yönetim işlemleri için iki adımlı doğrulama kurulmalı', 403);
    }
    if (!user.profileComplete && !roles?.length && !this.reflector.getAllAndOverride<boolean>(ALLOW_INCOMPLETE, targets)) {
      throw new AppError('PROFILE_INCOMPLETE', 'Profil tamamlanmalı', 403);
    }
    req.user = user;
    return true;
  }

  private async liftExpiredSuspension(user: User) {
    if (user.status === UserStatus.SUSPENDED && user.suspendedUntil && user.suspendedUntil < new Date()) {
      user.status = UserStatus.ACTIVE;
      user.suspendedUntil = null;
      await this.users.update(user.id, { status: UserStatus.ACTIVE, suspendedUntil: null });
    }
  }
}
