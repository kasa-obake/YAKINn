/**
 * İzinli kökenler. Üretimde CORS_ORIGINS boşsa tarayıcıdan çapraz köken isteği kabul edilmez
 * (mobil uygulama CORS'a ihtiyaç duymaz; web sürümü için izinli adresleri virgülle yazın). Geliştirmede varsayılan *.
 */
export function corsOrigin(env: NodeJS.ProcessEnv = process.env): boolean | string[] {
  const raw = env.CORS_ORIGINS ?? (env.NODE_ENV === 'production' ? '' : '*');
  const origins = raw.split(',').map((s) => s.trim()).filter(Boolean);
  return origins.includes('*') ? true : origins.length ? origins : false;
}
