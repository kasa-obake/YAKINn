export type LatLng = { lat: number; lng: number };
export type GeoPoint = { type: 'Point'; coordinates: [number, number] };

export const toPoint = (p: LatLng): GeoPoint => ({ type: 'Point', coordinates: [p.lng, p.lat] });
export const fromPoint = (g: GeoPoint): LatLng => ({ lat: g.coordinates[1], lng: g.coordinates[0] });

/**
 * Gizlilik: Gerçek noktadan 150-300 m uzaklıkta, rastgele yönde SABİT bir görünen nokta üretir.
 * İlan oluşturulurken bir kez çağrılır ve saklanır (her istekte yeniden üretmek, ortalama
 * alınarak gerçek yerin bulunmasına yol açar). Tasarım dokümanı 17.3.
 */
export function displayPointFrom(base: LatLng, minM = 150, maxM = 300): LatLng {
  const d = minM + Math.random() * (maxM - minM);
  const bearing = Math.random() * 2 * Math.PI;
  const dLat = (d * Math.cos(bearing)) / 111_320;
  const dLng = (d * Math.sin(bearing)) / (111_320 * Math.cos((base.lat * Math.PI) / 180));
  return { lat: round6(base.lat + dLat), lng: round6(base.lng + dLng) };
}

export const round6 = (n: number) => Math.round(n * 1e6) / 1e6;

export function haversineM(a: LatLng, b: LatLng) {
  const R = 6_371_000, r = (x: number) => (x * Math.PI) / 180;
  const dLat = r(b.lat - a.lat), dLng = r(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

/** Mesafe 100 m'ye yuvarlanır; 300 m altı "300 m'den yakın" olarak işaretlenir. */
export function publicDistance(m: number | null | undefined) {
  if (m == null || Number.isNaN(m)) return null;
  if (m < 300) return { meters: 300, approx: 'lt300' as const };
  return { meters: Math.round(m / 100) * 100, approx: 'rounded' as const };
}
