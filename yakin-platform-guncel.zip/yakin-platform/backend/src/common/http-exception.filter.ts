import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { ThrottlerException } from '@nestjs/throttler';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly log = new Logger('Hata');
  catch(exception: unknown, host: ArgumentsHost) {
    if (host.getType() !== 'http') return;
    const res = host.switchToHttp().getResponse();
    if (exception instanceof ThrottlerException) {
      return res.status(429).json({ code: 'RATE_LIMITED', message: 'Çok fazla istek', details: {} });
    }
    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const body: any = exception.getResponse();
      if (status === HttpStatus.PAYLOAD_TOO_LARGE) return res.status(413).json({ code: 'MEDIA_TOO_LARGE', message: 'Dosya 15 MB sınırını aşıyor', details: { maxBytes: 15 * 1024 * 1024 } });
      if (body && typeof body === 'object' && body.code) return res.status(status).json(body);
      if (status === HttpStatus.BAD_REQUEST && Array.isArray(body?.message)) {
        return res.status(status).json({ code: 'VALIDATION_ERROR', message: body.message[0], details: { errors: body.message } });
      }
      const code = status === 404 ? 'NOT_FOUND' : status === 401 ? 'AUTH_REQUIRED' : status === 403 ? 'FORBIDDEN' : 'BAD_REQUEST';
      return res.status(status).json({ code, message: typeof body === 'string' ? body : body?.message ?? 'Hata', details: {} });
    }
    this.log.error(exception instanceof Error ? exception.stack : String(exception));
    return res.status(500).json({ code: 'UNKNOWN', message: 'Beklenmeyen hata', details: {} });
  }
}
