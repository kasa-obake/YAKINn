import { Listing, Neighborhood, User } from '../database/entities';
import { maskPhone } from './format';

export const neighborhoodView = (n?: Neighborhood | null) => (n ? { id: n.id, name: n.name, district: n.district, city: n.city } : null);

/** Oturum sahibinin kendi profili (tüm ayarlarıyla). */
export function meView(u: User) {
  return {
    id: u.id,
    phoneMasked: maskPhone(u.phone),
    firstName: u.firstName,
    lastName: u.lastName,
    displayName: u.displayName,
    birthYear: u.birthYear,
    bio: u.bio,
    avatarUrl: u.avatarUrl,
    neighborhood: neighborhoodView(u.neighborhood),
    neighborhoodChangesLeft: Math.max(0, 2 - monthlyChanges(u)),
    interests: u.interests,
    role: u.role,
    totpEnabled: !!u.totpEnabledAt,
    status: u.status,
    suspendedUntil: u.suspendedUntil,
    profileComplete: u.profileComplete,
    privacy: { hideNeighborhood: u.hideNeighborhood, showReadReceipts: u.showReadReceipts, showResponseTime: u.showResponseTime },
    consents: { analytics: u.analyticsConsent, marketing: u.marketingConsent },
    notificationPrefs: { quietHours: true, ...u.notificationPrefs },
    helpedCount: u.helpedCount,
    deletionRequestedAt: u.deletionRequestedAt,
    createdAt: u.createdAt,
  };
}

export function monthlyChanges(u: User) {
  if (!u.neighborhoodChangedAt) return 0;
  const d = u.neighborhoodChangedAt, now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() ? u.neighborhoodChanges : 0;
}

/** Başka kullanıcılara gösterilen kısa kimlik kartı. Soyadın yalnızca baş harfi görünür. */
export function userCard(u: User | null | undefined) {
  if (!u) return null;
  return {
    id: u.id,
    displayName: u.displayName,
    avatarUrl: u.avatarUrl,
    neighborhood: u.hideNeighborhood ? null : u.neighborhood?.name ?? null,
    memberSince: u.createdAt,
    helpedCount: u.helpedCount,
    verifiedPhone: true,
  };
}

export function listingCard(l: Listing, extra: { distanceM?: number | null; isFavorite?: boolean } = {}) {
  const cover = [...(l.media || [])].sort((a, b) => a.position - b.position)[0];
  return {
    id: l.id,
    category: l.category,
    subtype: l.subtype,
    title: l.title,
    priceKurus: l.priceKurus,
    coverUrl: cover?.url ?? null,
    neighborhood: l.neighborhood?.name ?? null,
    distance: distanceView(extra.distanceM),
    status: l.status,
    isNew: !!l.publishedAt && Date.now() - new Date(l.publishedAt).getTime() < 24 * 3600_000,
    isFavorite: !!extra.isFavorite,
    createdAt: l.createdAt,
    publishedAt: l.publishedAt,
  };
}

export function distanceView(m?: number | null) {
  if (m == null || Number.isNaN(m)) return null;
  if (m < 300) return { meters: 300, approx: 'lt300' as const };
  return { meters: Math.round(m / 100) * 100, approx: 'rounded' as const };
}
