import { MigrationInterface, QueryRunner } from 'typeorm';

/** Destek talebi yanıtı ve yönetici iki adımlı doğrulaması (TOTP) için sütunlar. */
export class HardeningAndTotp1793800000000 implements MigrationInterface {
  name = 'HardeningAndTotp1793800000000';

  public async up(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "support_tickets" ADD "reply" text NOT NULL DEFAULT ''`);
    await q.query(`ALTER TABLE "support_tickets" ADD "repliedBy" uuid`);
    await q.query(`ALTER TABLE "support_tickets" ADD "repliedAt" TIMESTAMP WITH TIME ZONE`);
    await q.query(`ALTER TABLE "users" ADD "totpSecret" text`);
    await q.query(`ALTER TABLE "users" ADD "totpEnabledAt" TIMESTAMP WITH TIME ZONE`);
  }

  public async down(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "users" DROP COLUMN "totpEnabledAt"`);
    await q.query(`ALTER TABLE "users" DROP COLUMN "totpSecret"`);
    await q.query(`ALTER TABLE "support_tickets" DROP COLUMN "repliedAt"`);
    await q.query(`ALTER TABLE "support_tickets" DROP COLUMN "repliedBy"`);
    await q.query(`ALTER TABLE "support_tickets" DROP COLUMN "reply"`);
  }
}
