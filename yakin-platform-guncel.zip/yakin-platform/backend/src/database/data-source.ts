import 'reflect-metadata';
import { DataSource, DataSourceOptions } from 'typeorm';
import * as path from 'path';
import { ENTITIES } from './entities';

export function dataSourceOptions(url = process.env.DATABASE_URL): DataSourceOptions {
  return {
    type: 'postgres',
    url: url || 'postgres://yakin:yakin@localhost:5432/yakin',
    entities: ENTITIES,
    migrations: [path.join(__dirname, 'migrations', '*.{ts,js}')],
    synchronize: false,
    uuidExtension: 'pgcrypto',
    logging: process.env.DB_LOG === 'true',
  };
}

// TypeORM CLI için
if (!process.env.DATABASE_URL) { try { require('dotenv').config({ quiet: true }); } catch {} }
export default new DataSource(dataSourceOptions());
