import { Column, CreateDateColumn, Entity, Index, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Listing } from './listing.entity';

@Entity('conversations')
@Index(['listingId', 'buyerId'], { unique: true })
export class Conversation {
  @PrimaryGeneratedColumn('uuid') id: string;
  @ManyToOne(() => Listing, { onDelete: 'CASCADE' }) listing: Listing;
  @Column('uuid') listingId: string;
  /** İlanla ilgilenen taraf (sohbeti başlatan). */
  @Index() @Column('uuid') buyerId: string;
  /** İlan sahibi. */
  @Index() @Column('uuid') sellerId: string;
  @Column({ type: 'timestamptz', default: () => 'now()' }) lastMessageAt: Date;
  @Column('uuid', { array: true, default: '{}' }) archivedBy: string[];
  @Column('uuid', { array: true, default: '{}' }) mutedBy: string[];
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('messages')
@Index(['conversationId', 'createdAt'])
export class Message {
  @PrimaryGeneratedColumn('uuid') id: string;
  @ManyToOne(() => Conversation, { onDelete: 'CASCADE' }) conversation: Conversation;
  @Column('uuid') conversationId: string;
  /** Sistem mesajlarında null. */
  @Column({ type: 'uuid', nullable: true }) senderId: string | null;
  @Column({ type: 'text', default: '' }) body: string;
  @Column({ type: 'text', nullable: true }) imageUrl: string | null;
  @Column({ default: 'text' }) kind: 'text' | 'image' | 'system';
  @Column({ type: 'text', array: true, default: '{}' }) warnings: string[];
  @Column({ type: 'timestamptz', nullable: true }) readAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) deletedAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}
