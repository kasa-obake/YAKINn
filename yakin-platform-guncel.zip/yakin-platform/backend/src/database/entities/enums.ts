export enum UserRole { USER = 'user', MODERATOR = 'moderator', ADMIN = 'admin' }
export enum UserStatus { ACTIVE = 'active', SUSPENDED = 'suspended', DELETED = 'deleted' }
export enum ListingCategory { ESYA = 'esya', YARDIM = 'yardim', KAYIP = 'kayip' }
export enum ListingStatus {
  DRAFT = 'draft',
  PENDING_REVIEW = 'pending_review',
  ACTIVE = 'active',
  CLOSED = 'closed',
  REMOVED = 'removed',
}
export enum CloseReason { DELIVERED = 'delivered', EXPIRED = 'expired', CANCELLED = 'cancelled' }
export enum ReportTarget { LISTING = 'listing', USER = 'user', MESSAGE = 'message' }
export enum ReportStatus { OPEN = 'open', IN_REVIEW = 'in_review', RESOLVED = 'resolved', DISMISSED = 'dismissed' }
export enum ReportPriority { CRITICAL = 'critical', HIGH = 'high', NORMAL = 'normal' }
export enum DecisionAction {
  NO_VIOLATION = 'no_violation',
  REMOVE_CONTENT = 'remove_content',
  WARN = 'warn',
  SUSPEND = 'suspend',
  BAN = 'ban',
  APPROVE_LISTING = 'approve_listing',
  REJECT_LISTING = 'reject_listing',
}
export enum AppealStatus { PENDING = 'pending', ACCEPTED = 'accepted', REJECTED = 'rejected' }

/** MVP kategorileri ve alt türleri (tasarım dokümanı 2. bölüm). */
export const SUBTYPES: Record<ListingCategory, string[]> = {
  [ListingCategory.ESYA]: ['ucretsiz', 'satilik', 'odunc', 'takas'],
  [ListingCategory.YARDIM]: ['istiyorum', 'teklif'],
  [ListingCategory.KAYIP]: ['kayip_esya', 'bulunan_esya', 'kayip_hayvan'],
};
