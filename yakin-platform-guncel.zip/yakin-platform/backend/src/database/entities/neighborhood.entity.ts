import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('neighborhoods')
@Index(['city', 'name'], { unique: true })
export class Neighborhood {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
  @Column() district: string;
  @Column() city: string;
  @Index({ spatial: true })
  @Column({ type: 'geography', spatialFeatureType: 'Point', srid: 4326 })
  centroid: { type: 'Point'; coordinates: [number, number] };
  /** Yaklaşık mahalle yarıçapı (metre). Gerçek sınır poligonu ileride `boundary` alanına eklenir. */
  @Column({ type: 'int', default: 800 }) radiusM: number;
  @Column({ default: true }) active: boolean;
}
