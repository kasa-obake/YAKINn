import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';
import { AppealStatus, DecisionAction, ReportPriority, ReportStatus, ReportTarget } from './enums';

@Entity('blocks')
export class Block {
  @Column('uuid', { primary: true }) userId: string;
  @Column('uuid', { primary: true }) blockedId: string;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('reviews')
@Index(['listingId', 'fromId'], { unique: true })
export class Review {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column('uuid') listingId: string;
  @Column('uuid') fromId: string;
  @Index() @Column('uuid') toId: string;
  @Column('int') rating: number;
  @Column('text', { array: true, default: '{}' }) tags: string[];
  @Column({ default: '' }) comment: string;
  /** Kör değerlendirme: iki taraf da yazınca veya 14 gün dolunca yayınlanır. */
  @Column({ type: 'timestamptz', nullable: true }) publishedAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('reports')
@Index(['status', 'priority', 'createdAt'])
export class Report {
  @PrimaryGeneratedColumn('uuid') id: string;
  /** Otomatik işaretlerde null. */
  @Column({ type: 'uuid', nullable: true }) reporterId: string | null;
  @Column({ type: 'enum', enum: ReportTarget }) targetType: ReportTarget;
  @Column('uuid') targetId: string;
  /** Hedef içeriğin sahibi (hızlı sorgu için). */
  @Column({ type: 'uuid', nullable: true }) targetOwnerId: string | null;
  @Column() reason: string;
  @Column({ default: '' }) note: string;
  @Column({ type: 'text', nullable: true }) screenshotUrl: string | null;
  @Column({ type: 'enum', enum: ReportPriority, default: ReportPriority.NORMAL }) priority: ReportPriority;
  @Column({ type: 'enum', enum: ReportStatus, default: ReportStatus.OPEN }) status: ReportStatus;
  @Column({ type: 'uuid', nullable: true }) assignedTo: string | null;
  @Column({ type: 'timestamptz' }) slaDueAt: Date;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('moderation_decisions')
export class ModerationDecision {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ type: 'uuid', nullable: true }) reportId: string | null;
  @Column({ type: 'enum', enum: ReportTarget }) targetType: ReportTarget;
  @Column('uuid') targetId: string;
  @Index() @Column({ type: 'uuid', nullable: true }) affectedUserId: string | null;
  @Column({ type: 'enum', enum: DecisionAction }) action: DecisionAction;
  @Column({ default: '' }) rule: string;
  /** Kullanıcıya gösterilen gerekçe. */
  @Column({ type: 'text', default: '' }) reason: string;
  @Column({ type: 'text', default: '' }) internalNote: string;
  @Column({ type: 'int', nullable: true }) suspendDays: number | null;
  @Column({ type: 'uuid', nullable: true }) moderatorId: string | null;
  @Column({ type: 'timestamptz' }) appealDeadline: Date;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('appeals')
export class Appeal {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column('uuid') decisionId: string;
  @Column('uuid') userId: string;
  @Column('text') note: string;
  @Column({ type: 'enum', enum: AppealStatus, default: AppealStatus.PENDING }) status: AppealStatus;
  @Column({ type: 'uuid', nullable: true }) resolvedBy: string | null;
  @Column({ type: 'text', default: '' }) resolution: string;
  @Column({ type: 'timestamptz', nullable: true }) resolvedAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('moderation_rules')
export class ModerationRule {
  @PrimaryGeneratedColumn() id: number;
  @Column() pattern: string;
  @Column({ default: 'contains' }) matchType: 'exact' | 'contains' | 'regex';
  /** block: yayınlanmaz, review: incelemeye alınır, warn: kullanıcı uyarılır */
  @Column({ default: 'review' }) action: 'block' | 'review' | 'warn';
  @Column({ default: '' }) label: string;
  @Column({ default: true }) active: boolean;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('notifications')
@Index(['userId', 'createdAt'])
export class Notification {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column('uuid') userId: string;
  @Column() type: string;
  @Column() title: string;
  @Column({ type: 'text', default: '' }) body: string;
  @Column({ default: '/' }) link: string;
  @Column({ type: 'jsonb', default: () => `'{}'` }) data: Record<string, unknown>;
  @Column({ type: 'timestamptz', nullable: true }) readAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('audit_logs')
@Index(['actorId', 'createdAt'])
export class AuditLog {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ type: 'uuid', nullable: true }) actorId: string | null;
  @Column() action: string;
  @Column({ default: '' }) targetType: string;
  @Column({ type: 'text', default: '' }) targetId: string;
  @Column({ type: 'jsonb', default: () => `'{}'` }) meta: Record<string, unknown>;
  @Column({ default: '' }) ip: string;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('support_tickets')
export class SupportTicket {
  @PrimaryGeneratedColumn() id: number;
  @Column('uuid') userId: string;
  @Column() subject: string;
  @Column('text') body: string;
  @Column({ default: 'open' }) status: string;
  @Column({ type: 'text', default: '' }) reply: string;
  @Column({ type: 'uuid', nullable: true }) repliedBy: string | null;
  @Column({ type: 'timestamptz', nullable: true }) repliedAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}
