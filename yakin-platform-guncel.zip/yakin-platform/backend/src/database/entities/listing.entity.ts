import { Column, CreateDateColumn, Entity, Index, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { CloseReason, ListingCategory, ListingStatus } from './enums';
import { Neighborhood } from './neighborhood.entity';
import { User } from './user.entity';

type Point = { type: 'Point'; coordinates: [number, number] };

@Entity('listings')
@Index(['status', 'createdAt'])
export class Listing {
  @PrimaryGeneratedColumn('uuid') id: string;
  @ManyToOne(() => User, { onDelete: 'CASCADE' }) user: User;
  @Index() @Column('uuid') userId: string;
  @Column({ type: 'enum', enum: ListingCategory }) category: ListingCategory;
  @Column() subtype: string;
  @Column({ length: 80 }) title: string;
  @Column({ type: 'text' }) description: string;
  /** Kuruş cinsinden fiyat. Yalnızca "satilik" alt türünde dolu. */
  @Column({ type: 'bigint', nullable: true, transformer: { to: (v) => v, from: (v) => (v == null ? null : Number(v)) } }) priceKurus: number | null;
  /** Kategoriye özel alanlar: durum, ödünç süresi, kayıp tarihi, hayvan türü vb. */
  @Column({ type: 'jsonb', default: () => `'{}'` }) details: Record<string, unknown>;
  @Column({ default: 'elden' }) handover: string;
  @ManyToOne(() => Neighborhood, { eager: true }) neighborhood: Neighborhood;
  @Column('int') neighborhoodId: number;
  /** Kayıp ilanlarında kullanıcının işaretlediği yaklaşık yer. API hiçbir zaman döndürmez. */
  @Column({ type: 'geography', spatialFeatureType: 'Point', srid: 4326, nullable: true, select: false }) exactPoint: Point | null;
  /** Haritada gösterilen, gerçek yerden 150-300 m uzaklaştırılmış sabit nokta. */
  @Index({ spatial: true })
  @Column({ type: 'geography', spatialFeatureType: 'Point', srid: 4326 }) displayPoint: Point;
  @Column({ type: 'enum', enum: ListingStatus, default: ListingStatus.ACTIVE }) status: ListingStatus;
  @Column({ type: 'enum', enum: CloseReason, nullable: true }) closeReason: CloseReason | null;
  @Column({ type: 'uuid', nullable: true }) deliveredToUserId: string | null;
  @Column({ type: 'text', array: true, default: '{}' }) moderationFlags: string[];
  @Column({ type: 'int', default: 0 }) views: number;
  @Column({ type: 'timestamptz', nullable: true }) firstReplyAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) publishedAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) closedAt: Date | null;
  @Column({ type: 'timestamptz' }) expiresAt: Date;
  @OneToMany(() => ListingMedia, (m) => m.listing, { cascade: true, eager: true }) media: ListingMedia[];
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ type: 'timestamptz' }) updatedAt: Date;
}

@Entity('listing_media')
export class ListingMedia {
  @PrimaryGeneratedColumn('uuid') id: string;
  @ManyToOne(() => Listing, (l) => l.media, { onDelete: 'CASCADE' }) listing: Listing;
  @Column('uuid') listingId: string;
  @Column() url: string;
  @Column({ type: 'int', default: 0 }) width: number;
  @Column({ type: 'int', default: 0 }) height: number;
  @Column({ type: 'int', default: 0 }) position: number;
  @Column({ default: '' }) alt: string;
}

@Entity('media_uploads')
export class MediaUpload {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column('uuid') userId: string;
  @Column() url: string;
  @Column({ type: 'int' }) width: number;
  @Column({ type: 'int' }) height: number;
  @Column({ type: 'int' }) bytes: number;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}

@Entity('favorites')
export class Favorite {
  @Column('uuid', { primary: true }) userId: string;
  @Column('uuid', { primary: true }) listingId: string;
  @ManyToOne(() => Listing, { onDelete: 'CASCADE' }) listing: Listing;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
}
