import { Column, CreateDateColumn, Entity, Index, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { UserRole, UserStatus } from './enums';
import { Neighborhood } from './neighborhood.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column() phone: string;
  @Column({ default: '' }) firstName: string;
  @Column({ default: '' }) lastName: string;
  @Column({ type: 'int', nullable: true }) birthYear: number | null;
  @Column({ default: '' }) bio: string;
  @Column({ type: 'text', nullable: true }) avatarUrl: string | null;
  @ManyToOne(() => Neighborhood, { nullable: true, eager: true }) neighborhood: Neighborhood | null;
  @Column({ type: 'int', nullable: true }) neighborhoodId: number | null;
  @Column({ type: 'int', default: 0 }) neighborhoodChanges: number;
  @Column({ type: 'timestamptz', nullable: true }) neighborhoodChangedAt: Date | null;
  @Column('text', { array: true, default: '{}' }) interests: string[];
  @Column({ type: 'enum', enum: UserRole, default: UserRole.USER }) role: UserRole;
  @Column({ type: 'enum', enum: UserStatus, default: UserStatus.ACTIVE }) status: UserStatus;
  @Column({ type: 'timestamptz', nullable: true }) suspendedUntil: Date | null;
  @Column({ default: false }) hideNeighborhood: boolean;
  @Column({ default: true }) showReadReceipts: boolean;
  @Column({ default: true }) showResponseTime: boolean;
  @Column({ default: false }) analyticsConsent: boolean;
  @Column({ default: false }) marketingConsent: boolean;
  @Column({ type: 'jsonb', default: () => `'{}'` }) notificationPrefs: Record<string, boolean | string>;
  @Column({ type: 'int', default: 0 }) helpedCount: number;
  @Column({ type: 'timestamptz', nullable: true }) termsAcceptedAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) deletionRequestedAt: Date | null;
  /** Yönetici/moderatör iki adımlı doğrulama sırrı (AES-GCM ile şifreli). Varsayılan sorgularda gelmez. */
  @Column({ type: 'text', nullable: true, select: false }) totpSecret: string | null;
  @Column({ type: 'timestamptz', nullable: true }) totpEnabledAt: Date | null;
  @CreateDateColumn({ type: 'timestamptz' }) createdAt: Date;
  @UpdateDateColumn({ type: 'timestamptz' }) updatedAt: Date;

  get displayName() {
    return this.firstName ? `${this.firstName} ${this.lastName ? this.lastName.charAt(0).toLocaleUpperCase('tr-TR') + '.' : ''}`.trim() : 'YAKIN kullanıcısı';
  }
  get profileComplete() {
    return !!(this.firstName && this.birthYear && this.neighborhoodId);
  }
}
