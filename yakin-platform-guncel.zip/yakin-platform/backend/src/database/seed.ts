/**
 * Burdur mahalleleri ve içerik kuralları her ortamda eklenir.
 * Örnek yönetici/moderatör/kullanıcı hesapları ve örnek ilanlar YALNIZCA üretim dışında (NODE_ENV!=production) eklenir.
 * Üretimde gerçek yönetici için: npm run admin:create:prod -- 5XXXXXXXXX admin
 * Çalıştırma: npm run seed   (tekrar çalıştırmak güvenlidir; mevcut kayıtlar korunur)
 * Mahalle merkezleri yaklaşıktır; üretimden önce resmi sınır verisiyle doğrulanmalıdır.
 */
import 'reflect-metadata';
import { mkdir, writeFile } from 'fs/promises';
import { join, resolve } from 'path';
import sharp from 'sharp';
import { DataSource } from 'typeorm';
import { displayPointFrom, toPoint } from '../common/geo';
import { dataSourceOptions } from './data-source';
import { Listing, ListingCategory, ListingStatus, ModerationRule, Neighborhood, User, UserRole } from './entities';

const NEIGHBORHOODS: [string, number, number][] = [
  ['Bahçelievler', 37.7262, 30.2842], ['Emek', 37.7158, 30.2795], ['Konak', 37.7212, 30.2905], ['Özgür', 37.724, 30.2968],
  ['Sakarya', 37.7175, 30.299], ['Yeni Mahalle', 37.729, 30.2925], ['Burç', 37.7128, 30.288], ['Değirmenler', 37.732, 30.286],
  ['Pazar', 37.7195, 30.285], ['Cumhuriyet', 37.723, 30.277],
];

const RULES: Partial<ModerationRule>[] = [
  { pattern: 'silah', matchType: 'exact', action: 'block', label: 'Silah' },
  { pattern: 'tabanca', matchType: 'contains', action: 'block', label: 'Silah' },
  { pattern: 'uyuşturucu', matchType: 'contains', action: 'block', label: 'Uyuşturucu' },
  { pattern: 'reçeteli ilaç', matchType: 'contains', action: 'block', label: 'İlaç' },
  { pattern: 'sahte kimlik', matchType: 'contains', action: 'block', label: 'Sahte belge' },
  { pattern: 'kapora', matchType: 'contains', action: 'review', label: 'Ön ödeme talebi' },
  { pattern: 'ön ödeme', matchType: 'contains', action: 'review', label: 'Ön ödeme talebi' },
  { pattern: 'yavru köpek satılık', matchType: 'contains', action: 'review', label: 'Hayvan satışı' },
  { pattern: 'yavru kedi satılık', matchType: 'contains', action: 'review', label: 'Hayvan satışı' },
];

async function photo(dir: string, name: string, hex: string) {
  const file = `seed-${name}.jpg`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900"><rect width="100%" height="100%" fill="${hex}"/><circle cx="600" cy="450" r="220" fill="#ffffff" fill-opacity="0.25"/></svg>`;
  await writeFile(join(dir, file), await sharp(Buffer.from(svg)).jpeg({ quality: 80 }).toBuffer());
  return `${(process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '')}/uploads/${file}`;
}

async function main() {
  require('dotenv').config({ path: process.env.ENV_FILE || '.env' });
  const ds = await new DataSource(dataSourceOptions(process.env.DATABASE_URL)).initialize();
  const city = process.env.SERVICE_CITY || 'Burdur';
  const nRepo = ds.getRepository(Neighborhood);
  for (const [name, lat, lng] of NEIGHBORHOODS) {
    if (!(await nRepo.exist({ where: { city, name } }))) await nRepo.insert({ name, district: 'Merkez', city, centroid: toPoint({ lat, lng }), radiusM: 700 });
  }
  const hoods = await nRepo.find({ where: { city } });
  const hood = (n: string) => hoods.find((h) => h.name === n)!;

  const demo = process.env.NODE_ENV !== 'production' && process.env.SEED_DEMO !== 'false';
  const uRepo = ds.getRepository(User);
  const mkUser = async (phone: string, firstName: string, lastName: string, n: string, role = UserRole.USER, birthYear = 1990) => {
    const existing = await uRepo.findOne({ where: { phone } });
    if (existing) return existing;
    return uRepo.save(uRepo.create({ phone, firstName, lastName, birthYear, neighborhoodId: hood(n).id, role, termsAcceptedAt: new Date() }));
  };
  if (demo) await mkUser('+905550000001', 'Yönetici', 'Yakın', 'Konak', UserRole.ADMIN, 1985);
  if (demo) await mkUser('+905550000002', 'Moderatör', 'Yakın', 'Konak', UserRole.MODERATOR, 1988);
  const ayse = demo ? await mkUser('+905550000011', 'Ayşe', 'Kaya', 'Bahçelievler') : null!;
  const mehmet = demo ? await mkUser('+905550000012', 'Mehmet', 'Demir', 'Emek', UserRole.USER, 1979) : null!;
  const zeynep = demo ? await mkUser('+905550000013', 'Zeynep', 'Arslan', 'Özgür', UserRole.USER, 1996) : null!;

  const rRepo = ds.getRepository(ModerationRule);
  if (!(await rRepo.count())) await rRepo.insert(RULES);

  const lRepo = ds.getRepository(Listing);
  if (demo && !(await lRepo.count())) {
    const dir = resolve(process.env.MEDIA_DIR || 'uploads');
    await mkdir(dir, { recursive: true });
    const samples: [User, ListingCategory, string, string, string, number | null, string, string][] = [
      [ayse, ListingCategory.ESYA, 'ucretsiz', 'Çocuk bisikleti, 16 jant', 'Oğlum büyüdü, bisiklet sağlam. Frenleri yeni ayarlandı. Bahçelievler parkında teslim edebilirim.', null, 'Bahçelievler', '#2F7A57'],
      [mehmet, ListingCategory.ESYA, 'satilik', 'Arçelik çamaşır makinesi', '7 kg, 4 yıllık, düzenli çalışıyor. Taşıma alıcıya aittir.', 2_500_00, 'Emek', '#5E6B64'],
      [zeynep, ListingCategory.ESYA, 'odunc', 'Matkap ödünç verebilirim', 'Bosch darbeli matkap. Bir haftaya kadar ödünç verebilirim, uçlarıyla birlikte.', null, 'Özgür', '#145A3E'],
      [ayse, ListingCategory.YARDIM, 'istiyorum', 'Pazar alışverişi için yardım', 'Annem için cumartesi sabahı pazardan alışveriş getirecek bir komşu arıyorum. Liste hazır.', null, 'Bahçelievler', ''],
      [mehmet, ListingCategory.YARDIM, 'teklif', 'Ortaokul matematik desteği', 'Emekli öğretmenim. Hafta içi akşamları 7 ve 8. sınıflara ücretsiz matematik desteği verebilirim.', null, 'Emek', ''],
      [zeynep, ListingCategory.KAYIP, 'kayip_hayvan', 'Gri tekir kedi kayboldu', 'Pazartesi akşamı Özgür Mahallesi civarında kayboldu. Boynunda mavi tasma var, adı Duman.', null, 'Özgür', '#7C8A83'],
      [ayse, ListingCategory.KAYIP, 'bulunan_esya', 'Anahtarlık bulundu', 'Konak civarında içinde üç anahtar olan kırmızı bir anahtarlık buldum. Tarif eden sahibine teslim ederim.', null, 'Konak', ''],
    ];
    let i = 0;
    for (const [u, category, subtype, title, description, price, n, color] of samples) {
      const h = hood(n);
      const media = color ? [{ url: await photo(dir, String(++i), color), width: 1200, height: 900, position: 0 }] : [];
      const publishedAt = new Date(Date.now() - (samples.length - i) * 3_600_000);
      await lRepo.save(lRepo.create({
        userId: u.id, category, subtype, title, description, priceKurus: price, neighborhoodId: h.id, handover: 'elden',
        displayPoint: toPoint(displayPointFrom({ lat: h.centroid.coordinates[1], lng: h.centroid.coordinates[0] })),
        status: ListingStatus.ACTIVE, publishedAt, expiresAt: new Date(Date.now() + 30 * 86_400_000), media: media as never,
      }));
    }
  }
  console.log(`${demo ? 'Geliştirme' : 'Üretim'} tohum verisi hazır: ${hoods.length} mahalle, ${await uRepo.count()} kullanıcı, ${await lRepo.count()} ilan, ${await rRepo.count()} kural`);
  await ds.destroy();
}

main().catch((e) => { console.error(e); process.exit(1); });
