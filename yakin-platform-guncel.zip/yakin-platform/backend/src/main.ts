import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { IoAdapter } from '@nestjs/platform-socket.io';
import { ServerOptions } from 'socket.io';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { resolve } from 'path';
import { AppModule } from './app.module';
import { corsOrigin } from './common/cors';
import { assertEnv } from './common/env';

/** Socket.IO için de aynı CORS kuralı (ortam değişkenleri uygulama başlarken okunur). */
class CorsIoAdapter extends IoAdapter {
  createIOServer(port: number, options?: ServerOptions) {
    return super.createIOServer(port, { ...options, cors: { origin: corsOrigin(), credentials: true } });
  }
}

export async function createApp() {
  assertEnv();
  const app = await NestFactory.create<NestExpressApplication>(AppModule, { logger: process.env.NODE_ENV === 'test' ? ['error'] : undefined });
  app.set('trust proxy', 1);
  app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  app.enableCors({ origin: corsOrigin(), credentials: true });
  app.useWebSocketAdapter(new CorsIoAdapter(app));
  app.setGlobalPrefix('v1', { exclude: ['docs', 'docs-json'] });
  app.useStaticAssets(resolve(process.env.MEDIA_DIR || 'uploads'), { prefix: '/uploads/', maxAge: '30d', index: false });
  app.enableShutdownHooks();
  const doc = SwaggerModule.createDocument(
    app,
    new DocumentBuilder().setTitle('YAKIN API').setDescription('YAKIN mahalle dayanışma platformu, sürüm 1').setVersion('1.0').addBearerAuth().build(),
  );
  SwaggerModule.setup('docs', app, doc);
  return app;
}

if (require.main === module) {
  createApp().then(async (app) => {
    const port = Number(process.env.PORT || 3000);
    await app.listen(port, '0.0.0.0');
    console.log(`YAKIN API http://localhost:${port}/v1  |  Belgeler: /docs`);
  });
}
