import { Body, Controller, Get, HttpCode, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsLatitude, IsLongitude } from 'class-validator';
import { AllowIncompleteProfile, Public } from '../../common/auth.guard';
import { neighborhoodView } from '../../common/presenters';
import { GeoService } from '../core/geo.service';

class ResolveDto {
  @Type(() => Number) @IsLatitude() lat: number;
  @Type(() => Number) @IsLongitude() lng: number;
}

@ApiTags('geo')
@Controller('neighborhoods')
export class GeoController {
  constructor(private geo: GeoService) {}

  @Public() @Get()
  async list() {
    const items = await this.geo.list();
    return { city: this.geo.city(), items: items.map((n) => ({ ...neighborhoodView(n), center: { lat: n.centroid.coordinates[1], lng: n.centroid.coordinates[0] } })) };
  }

  @AllowIncompleteProfile() @Post('resolve') @HttpCode(200)
  async resolve(@Body() dto: ResolveDto) {
    return neighborhoodView(await this.geo.resolve(dto.lat, dto.lng));
  }
}
