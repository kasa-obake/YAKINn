import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { SmsProvider, smsProviderFactory } from './sms.provider';

@Module({
  controllers: [AuthController],
  providers: [AuthService, { provide: SmsProvider, useFactory: smsProviderFactory, inject: [ConfigService] }],
  exports: [AuthService],
})
export class AuthModule {}
