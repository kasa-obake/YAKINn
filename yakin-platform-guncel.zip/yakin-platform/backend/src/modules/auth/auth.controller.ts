import { Body, Controller, HttpCode, Ip, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { AllowIncompleteProfile, AllowSuspended, CurrentUser, Public } from '../../common/auth.guard';
import { DeviceToken, User } from '../../database/entities';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DeviceTokenDto, OtpRequestDto, OtpVerifyDto, RefreshDto, TotpCodeDto } from './auth.dto';
import { AuthService } from './auth.service';

@ApiTags('auth')
@Controller()
export class AuthController {
  constructor(private auth: AuthService, @InjectRepository(DeviceToken) private devices: Repository<DeviceToken>) {}

  /** IP başına 10 dakikada 15 kod isteği (operatör NAT'ı arkasındaki gerçek kullanıcılar için payı vardır). Telefon başına ve günlük toplam sınırlar serviste. */
  @Public() @Throttle({ default: { limit: 15, ttl: 600_000 } })
  @Post('auth/otp/request') @HttpCode(200)
  request(@Body() dto: OtpRequestDto) {
    return this.auth.requestOtp(dto.phone);
  }

  @Public() @Throttle({ default: { limit: 10, ttl: 60_000 } })
  @Post('auth/otp/verify') @HttpCode(200)
  verify(@Body() dto: OtpVerifyDto, @Ip() ip: string) {
    return this.auth.verifyOtp(dto.phone, dto.code, dto.device, dto.termsAccepted, ip, dto.totpCode);
  }

  @Public() @Post('auth/refresh') @HttpCode(200)
  refresh(@Body() dto: RefreshDto) {
    return this.auth.rotate(dto.refreshToken);
  }

  @Public() @Post('auth/logout') @HttpCode(200)
  logout(@Body() dto: RefreshDto) {
    return this.auth.logout(dto.refreshToken);
  }

  @AllowIncompleteProfile() @AllowSuspended()
  @Post('me/devices') @HttpCode(200)
  async device(@CurrentUser() u: User, @Body() dto: DeviceTokenDto) {
    await this.devices.upsert({ userId: u.id, token: dto.token, platform: dto.platform || 'android' }, ['userId', 'token']);
    return { ok: true };
  }

  // ---- Yönetici/moderatör iki adımlı doğrulama (TOTP) ----
  @AllowIncompleteProfile() @Post('me/totp/setup') @HttpCode(200)
  totpSetup(@CurrentUser() u: User) {
    return this.auth.totpSetup(u);
  }

  @AllowIncompleteProfile() @Post('me/totp/enable') @HttpCode(200)
  totpEnable(@CurrentUser() u: User, @Body() dto: TotpCodeDto) {
    return this.auth.totpEnable(u, dto.code);
  }

  @AllowIncompleteProfile() @Post('me/totp/disable') @HttpCode(200)
  totpDisable(@CurrentUser() u: User, @Body() dto: TotpCodeDto) {
    return this.auth.totpDisable(u, dto.code);
  }
}
