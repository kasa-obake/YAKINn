import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { createHash, randomBytes, randomInt, timingSafeEqual } from 'crypto';
import { IsNull, MoreThan, Not, Repository } from 'typeorm';
import { AppError } from '../../common/errors';
import { maskPhone, normalizePhone } from '../../common/format';
import { meView } from '../../common/presenters';
import { OtpCode, RefreshToken, User, UserRole, UserStatus } from '../../database/entities';
import { decryptSecret, encryptSecret, generateTotpSecret, otpauthUrl, verifyTotp } from '../../common/totp';
import { AuditService } from '../core/audit.service';
import { SmsProvider, SmsSendError } from './sms.provider';

const OTP_TTL_MS = 2 * 60_000;
const OTP_WINDOW_MS = 10 * 60_000;
const OTP_MAX_PER_WINDOW = 3;
const OTP_MAX_ATTEMPTS = 5;
const RESEND_AFTER_SEC = 60;

@Injectable()
export class AuthService {
  private log = new Logger('Auth');
  constructor(
    @InjectRepository(OtpCode) private otps: Repository<OtpCode>,
    @InjectRepository(RefreshToken) private refresh: Repository<RefreshToken>,
    @InjectRepository(User) private users: Repository<User>,
    private jwt: JwtService,
    private cfg: ConfigService,
    private sms: SmsProvider,
    private audit: AuditService,
  ) {}

  private hash(v: string) {
    return createHash('sha256').update(`${v}:${this.cfg.get('JWT_REFRESH_SECRET')}`).digest('hex');
  }
  private phoneOrThrow(p: string) {
    const phone = normalizePhone(p);
    if (!phone) throw new AppError('AUTH_PHONE_INVALID', 'Telefon numarası geçersiz', 400);
    return phone;
  }

  async requestOtp(rawPhone: string) {
    const phone = this.phoneOrThrow(rawPhone);
    const dailyCap = Number(this.cfg.get('SMS_DAILY_LIMIT') ?? 2000);
    if (dailyCap > 0 && (await this.otps.count({ where: { createdAt: MoreThan(new Date(Date.now() - 86_400_000)) } })) >= dailyCap) {
      this.log.error(`Günlük SMS sınırına ulaşıldı (${dailyCap}). Olağan dışı bir artış varsa kötüye kullanım olabilir`);
      throw new AppError('AUTH_SMS_BUDGET', 'Şu an doğrulama kodu gönderemiyoruz, daha sonra tekrar dene', 503);
    }
    const since = new Date(Date.now() - OTP_WINDOW_MS);
    const recent = await this.otps.find({ where: { phone, createdAt: MoreThan(since) }, order: { createdAt: 'ASC' } });
    if (recent.length >= OTP_MAX_PER_WINDOW) {
      const retryAfterSec = Math.ceil((recent[0].createdAt.getTime() + OTP_WINDOW_MS - Date.now()) / 1000);
      throw new AppError('AUTH_RATE_LIMITED', 'Çok fazla kod istendi', 429, { retryAfterSec });
    }
    const last = recent[recent.length - 1];
    if (last && Date.now() - last.createdAt.getTime() < RESEND_AFTER_SEC * 1000) {
      const retryAfterSec = Math.ceil((last.createdAt.getTime() + RESEND_AFTER_SEC * 1000 - Date.now()) / 1000);
      throw new AppError('AUTH_RESEND_TOO_SOON', 'Yeni kod için biraz bekle', 429, { retryAfterSec });
    }
    const fixed = this.cfg.get<string>('OTP_FIXED_CODE');
    const code = fixed && this.cfg.get('NODE_ENV') !== 'production' ? fixed : String(randomInt(0, 1_000_000)).padStart(6, '0');
    const ins = await this.otps.insert({ phone, codeHash: this.hash(`${phone}:${code}`), expiresAt: new Date(Date.now() + OTP_TTL_MS) });
    const newId = ins.identifiers[0].id as string;
    try {
      await this.sms.send(phone, `YAKIN doğrulama kodun: ${code}. Kodu kimseyle paylaşma.`);
    } catch (e) {
      // Gönderilemeyen kod sayılmaz ve önceki geçerli kod iptal edilmez; kullanıcı hemen tekrar deneyebilir.
      await this.otps.delete(newId);
      const retryable = e instanceof SmsSendError ? e.retryable : true;
      this.log.error(`OTP SMS gönderilemedi (${maskPhone(phone)}): ${e instanceof SmsSendError ? `${e.providerCode} ${e.message}` : (e as Error)?.message}`);
      throw new AppError('AUTH_SMS_FAILED', retryable ? 'Kod şu an gönderilemedi, biraz sonra tekrar dene' : 'Kod gönderilemedi. Sorun sürerse destek ekibine yaz', retryable ? 503 : 502);
    }
    await this.otps.update({ phone, usedAt: IsNull(), id: Not(newId) }, { usedAt: new Date() });
    const echo = this.cfg.get('OTP_DEV_ECHO') === 'true' && this.cfg.get('NODE_ENV') !== 'production';
    return { phoneMasked: maskPhone(phone), expiresInSec: OTP_TTL_MS / 1000, resendInSec: RESEND_AFTER_SEC, ...(echo ? { devCode: code } : {}) };
  }

  async verifyOtp(rawPhone: string, code: string, device = '', termsAccepted = false, ip = '', totpCode?: string) {
    const phone = this.phoneOrThrow(rawPhone);
    const otp = await this.otps.findOne({ where: { phone, usedAt: IsNull() }, order: { createdAt: 'DESC' } });
    if (!otp) throw new AppError('AUTH_OTP_INVALID', 'Kod hatalı', 400, { attemptsLeft: 0 });
    if (otp.expiresAt < new Date()) throw new AppError('AUTH_OTP_EXPIRED', 'Kodun süresi doldu', 400);
    if (otp.attempts >= OTP_MAX_ATTEMPTS) throw new AppError('AUTH_OTP_LOCKED', 'Çok fazla hatalı deneme', 429);
    const a = Buffer.from(otp.codeHash), b = Buffer.from(this.hash(`${phone}:${code}`));
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      await this.otps.increment({ id: otp.id }, 'attempts', 1);
      throw new AppError('AUTH_OTP_INVALID', 'Kod hatalı', 400, { attemptsLeft: OTP_MAX_ATTEMPTS - otp.attempts - 1 });
    }
    let user = await this.users.findOne({ where: { phone } });
    const isNew = !user;
    // Koşullar onaylanmadan kod tüketilmez; istemci onay alıp aynı kodla tekrar dener.
    if (!user && !termsAccepted) throw new AppError('AUTH_TERMS_REQUIRED', 'Kullanım koşulları onaylanmalı', 400);
    // İki adımlı doğrulama etkinse kod gerekir; eksik veya hatalıysa SMS kodu tüketilmez (hatalı denemeler SMS kodunun deneme hakkından düşer).
    if (user?.totpEnabledAt) {
      if (!totpCode) throw new AppError('AUTH_TOTP_REQUIRED', 'İki adımlı doğrulama kodu gerekli', 401);
      if (!verifyTotp(await this.totpSecretOf(user.id), totpCode)) {
        await this.otps.increment({ id: otp.id }, 'attempts', 1);
        throw new AppError('AUTH_TOTP_INVALID', 'İki adımlı doğrulama kodu hatalı', 401, { attemptsLeft: OTP_MAX_ATTEMPTS - otp.attempts - 1 });
      }
    }
    await this.otps.update(otp.id, { usedAt: new Date() });
    if (!user) {
      user = await this.users.save(this.users.create({ phone, termsAcceptedAt: new Date() }));
    } else if (user.status === UserStatus.DELETED) {
      throw new AppError('ACCOUNT_DELETED', 'Bu hesap silinmiş', 403);
    } else if (user.deletionRequestedAt) {
      // 30 günlük bekleme süresinde tekrar giriş, silme talebini iptal eder.
      await this.users.update(user.id, { deletionRequestedAt: null });
      user.deletionRequestedAt = null;
    }
    await this.audit.log(user.id, isNew ? 'auth.register' : 'auth.login', 'user', user.id, { device }, ip);
    return { ...(await this.issue(user, device)), isNew, user: meView(user) };
  }

  async issue(user: User, device = '') {
    const accessToken = await this.jwt.signAsync({ sub: user.id, role: user.role });
    const refreshToken = randomBytes(32).toString('base64url');
    const days = Number(this.cfg.get('JWT_REFRESH_TTL_DAYS') || 30);
    await this.refresh.insert({ userId: user.id, tokenHash: this.hash(refreshToken), device, expiresAt: new Date(Date.now() + days * 86_400_000) });
    return { accessToken, refreshToken, expiresIn: this.cfg.get('JWT_ACCESS_TTL') || '15m' };
  }

  /** Yenileme belirteci döndürülür (rotation). Kullanılmış bir belirteç tekrar gelirse tüm oturumlar kapatılır. */
  async rotate(token: string) {
    const row = await this.refresh.findOne({ where: { tokenHash: this.hash(token) } });
    if (!row || row.expiresAt < new Date()) throw new AppError('AUTH_REFRESH_INVALID', 'Oturum yenilenemedi', 401);
    if (row.revokedAt) {
      await this.refresh.update({ userId: row.userId, revokedAt: IsNull() }, { revokedAt: new Date() });
      await this.audit.log(row.userId, 'auth.refresh_reuse', 'user', row.userId);
      throw new AppError('AUTH_REFRESH_INVALID', 'Oturum yenilenemedi', 401);
    }
    const user = await this.users.findOne({ where: { id: row.userId } });
    if (!user || user.status === UserStatus.DELETED) throw new AppError('AUTH_REFRESH_INVALID', 'Oturum yenilenemedi', 401);
    await this.refresh.update(row.id, { revokedAt: new Date() });
    return this.issue(user, row.device);
  }

  async logout(token: string) {
    await this.refresh.update({ tokenHash: this.hash(token), revokedAt: IsNull() }, { revokedAt: new Date() });
    return { ok: true };
  }

  async revokeAll(userId: string) {
    await this.refresh.update({ userId, revokedAt: IsNull() }, { revokedAt: new Date() });
  }

  // ---------- İki adımlı doğrulama (yalnızca yönetici/moderatör) ----------

  private totpKey() {
    return this.cfg.get<string>('TOTP_ENCRYPTION_KEY') || this.cfg.getOrThrow<string>('JWT_REFRESH_SECRET');
  }

  private async totpSecretOf(userId: string): Promise<string> {
    const row = await this.users.createQueryBuilder('u').addSelect('u.totpSecret').where('u.id = :id', { id: userId }).getOne();
    if (!row?.totpSecret) throw new AppError('TOTP_NOT_SETUP', 'İki adımlı doğrulama kurulmamış', 409);
    return decryptSecret(row.totpSecret, this.totpKey());
  }

  private requireStaff(user: User) {
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.MODERATOR) throw new AppError('FORBIDDEN', 'Bu işlem yalnızca yönetici ve moderatörler içindir', 403);
  }

  /** Yeni sır üretir (henüz etkin değil). Kod ile /me/totp/enable çağrılınca etkinleşir. */
  async totpSetup(user: User) {
    this.requireStaff(user);
    if (user.totpEnabledAt) throw new AppError('TOTP_ALREADY_ENABLED', 'İki adımlı doğrulama zaten etkin', 409);
    const secret = generateTotpSecret();
    await this.users.update(user.id, { totpSecret: encryptSecret(secret, this.totpKey()) });
    return { secret, otpauthUrl: otpauthUrl(secret, maskPhone(user.phone)) };
  }

  async totpEnable(user: User, code: string) {
    this.requireStaff(user);
    if (user.totpEnabledAt) throw new AppError('TOTP_ALREADY_ENABLED', 'İki adımlı doğrulama zaten etkin', 409);
    if (!verifyTotp(await this.totpSecretOf(user.id), code)) throw new AppError('AUTH_TOTP_INVALID', 'İki adımlı doğrulama kodu hatalı', 400);
    await this.users.update(user.id, { totpEnabledAt: new Date() });
    await this.audit.log(user.id, 'auth.totp_enabled', 'user', user.id);
    return { ok: true };
  }

  async totpDisable(user: User, code: string) {
    this.requireStaff(user);
    if (!user.totpEnabledAt) throw new AppError('TOTP_NOT_SETUP', 'İki adımlı doğrulama etkin değil', 409);
    if (!verifyTotp(await this.totpSecretOf(user.id), code)) throw new AppError('AUTH_TOTP_INVALID', 'İki adımlı doğrulama kodu hatalı', 400);
    await this.users.update(user.id, { totpSecret: null, totpEnabledAt: null });
    await this.audit.log(user.id, 'auth.totp_disabled', 'user', user.id);
    return { ok: true };
  }
}
