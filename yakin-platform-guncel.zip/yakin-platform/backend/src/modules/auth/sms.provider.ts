import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

/** SMS sağlayıcı arayüzü. */
export abstract class SmsProvider {
  /** Doğrulama kodu gönderir. Başarısız olursa SmsSendError fırlatır. */
  abstract send(phone: string, text: string): Promise<void>;
}

/** Sağlayıcıdan gelen hata. `retryable` ise kullanıcı biraz sonra tekrar deneyebilir. */
export class SmsSendError extends Error {
  constructor(public readonly providerCode: string, message: string, public readonly retryable: boolean) {
    super(message);
  }
}

/** Geliştirme: kodu yalnızca loga yazar. */
@Injectable()
export class ConsoleSmsProvider extends SmsProvider {
  private log = new Logger('SMS');
  async send(phone: string, text: string) {
    this.log.log(`${phone} -> ${text}`);
  }
}

/** Netgsm REST v2 yanıt kodları (OTP ve normal gönderim). */
const NETGSM_CODES: Record<string, { msg: string; retryable: boolean }> = {
  '20': { msg: 'Mesaj metni hatalı veya çok uzun', retryable: false },
  '30': { msg: 'Kullanıcı adı, şifre veya API erişimi geçersiz (IP kısıtlaması olabilir)', retryable: false },
  '40': { msg: 'Gönderici adı (başlık) sistemde tanımlı değil', retryable: false },
  '41': { msg: 'Gönderici adı geçersiz', retryable: false },
  '50': { msg: 'Numara kontrolü başarısız', retryable: false },
  '51': { msg: 'Numara kontrolü başarısız', retryable: false },
  '52': { msg: 'Numara kontrolü başarısız', retryable: false },
  '60': { msg: 'OTP paketi veya kredi yetersiz', retryable: false },
  '70': { msg: 'Parametre hatası', retryable: false },
  '80': { msg: 'Gönderim hız sınırı aşıldı', retryable: true },
  '85': { msg: 'Aynı numaraya 1 dakikada çok fazla gönderim', retryable: true },
  '100': { msg: 'Netgsm sistem hatası', retryable: true },
  '101': { msg: 'Netgsm sistem hatası', retryable: true },
};

/** OTP kanalı Türkçe karakter kodlaması desteklemez; tek SMS boyunda (160) kalmak için ASCII'ye çevrilir. */
export function toGsmAscii(text: string) {
  const map: Record<string, string> = { ç: 'c', Ç: 'C', ğ: 'g', Ğ: 'G', ı: 'i', İ: 'I', ö: 'o', Ö: 'O', ş: 's', Ş: 'S', ü: 'u', Ü: 'U' };
  return text.replace(/[çÇğĞıİöÖşŞüÜ]/g, (c) => map[c]);
}

/** +905XXXXXXXXX -> 5XXXXXXXXX (Netgsm biçimi). */
export function toNetgsmNumber(phone: string) {
  const m = phone.replace(/\D/g, '').match(/^(?:90|0)?(5\d{9})$/);
  if (!m) throw new SmsSendError('NUMBER', 'Numara Netgsm biçimine çevrilemedi', false);
  return m[1];
}

export interface NetgsmConfig {
  usercode: string;
  password: string;
  header: string;
  /** true: OTP kanalı (/sms/rest/v2/otp, hızlı, tek boy). false: normal SMS (/sms/rest/v2/send). */
  otp: boolean;
  baseUrl: string;
  appname?: string;
  timeoutMs: number;
}

/**
 * Netgsm bağdaştırıcısı. Kimlik doğrulama: HTTP Basic (abone numarası + API alt kullanıcısı şifresi).
 * Belge: https://www.netgsm.com.tr/dokuman/#otp-sms ve #sms-gonderimi
 */
@Injectable()
export class NetgsmSmsProvider extends SmsProvider {
  private log = new Logger('SMS:Netgsm');
  constructor(private c: NetgsmConfig, private fetchFn: typeof fetch = fetch) {
    super();
  }

  static fromConfig(cfg: ConfigService) {
    const usercode = cfg.get<string>('NETGSM_USERCODE')?.trim();
    const password = cfg.get<string>('NETGSM_PASSWORD');
    const header = cfg.get<string>('NETGSM_HEADER')?.trim();
    const missing = [!usercode && 'NETGSM_USERCODE', !password && 'NETGSM_PASSWORD', !header && 'NETGSM_HEADER'].filter(Boolean);
    if (missing.length) throw new Error(`SMS_PROVIDER=netgsm için eksik ortam değişkenleri: ${missing.join(', ')}`);
    return new NetgsmSmsProvider({
      usercode: usercode!,
      password: password!,
      header: header!,
      otp: (cfg.get<string>('NETGSM_OTP') ?? 'true') !== 'false',
      baseUrl: (cfg.get<string>('NETGSM_BASE_URL') || 'https://api.netgsm.com.tr').replace(/\/$/, ''),
      appname: cfg.get<string>('NETGSM_APPNAME') || undefined,
      timeoutMs: Number(cfg.get('NETGSM_TIMEOUT_MS') || 10_000),
    });
  }

  /** İstek gövdesi; test için ayrı tutuldu. */
  buildRequest(phone: string, text: string): { url: string; body: Record<string, unknown> } {
    const no = toNetgsmNumber(phone);
    const app = this.c.appname ? { appname: this.c.appname } : {};
    if (this.c.otp) {
      const msg = toGsmAscii(text);
      if (msg.length > 160) throw new SmsSendError('20', 'OTP mesajı 160 karakteri aşıyor', false);
      return { url: `${this.c.baseUrl}/sms/rest/v2/otp`, body: { msgheader: this.c.header, msg, no, ...app } };
    }
    return { url: `${this.c.baseUrl}/sms/rest/v2/send`, body: { msgheader: this.c.header, encoding: 'TR', messages: [{ msg: text, no }], ...app } };
  }

  async send(phone: string, text: string) {
    const { url, body } = this.buildRequest(phone, text);
    const no = toNetgsmNumber(phone);
    const masked = `${no.slice(0, 3)}*****${no.slice(-2)}`;
    const auth = Buffer.from(`${this.c.usercode}:${this.c.password}`).toString('base64');
    let lastErr: SmsSendError | null = null;
    // Ağ hatası veya geçici Netgsm hatasında bir kez daha denenir.
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const res = await this.fetchFn(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Basic ${auth}` },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(this.c.timeoutMs),
        });
        const raw = await res.text();
        let data: { code?: string; jobid?: string; jobId?: string; description?: string } = {};
        try { data = JSON.parse(raw); } catch { /* düz metin yanıt */ }
        const code = String(data.code ?? '').trim();
        if ((res.status === 200 || res.status === 406) && code === '00') {
          this.log.log(`gönderildi ${masked} jobid=${data.jobid ?? data.jobId ?? '-'} kanal=${this.c.otp ? 'otp' : 'sms'}`);
          return;
        }
        const known = NETGSM_CODES[code];
        lastErr = new SmsSendError(code || `HTTP_${res.status}`, known?.msg ?? `Beklenmeyen yanıt (HTTP ${res.status}): ${raw.slice(0, 120)}`, known?.retryable ?? res.status >= 500);
      } catch (e) {
        if (e instanceof SmsSendError) throw e;
        const timeout = (e as Error)?.name === 'TimeoutError' || (e as Error)?.name === 'AbortError';
        lastErr = new SmsSendError(timeout ? 'TIMEOUT' : 'NETWORK', timeout ? 'Netgsm zaman aşımı' : `Netgsm'e bağlanılamadı: ${(e as Error)?.message}`, true);
      }
      this.log.warn(`gönderilemedi ${masked} deneme=${attempt} kod=${lastErr.providerCode} ${lastErr.message}`);
      // Hız sınırı hatalarında hemen tekrar denemek sorunu büyütür.
      if (!lastErr.retryable || ['80', '85'].includes(lastErr.providerCode)) break;
    }
    throw lastErr!;
  }

  /** Kimlik bilgilerini ve başlığı SMS göndermeden doğrular (GET /sms/rest/v2/msgheader). */
  async checkHeaders(): Promise<{ ok: boolean; headers: string[]; code: string; message: string }> {
    const auth = Buffer.from(`${this.c.usercode}:${this.c.password}`).toString('base64');
    const res = await this.fetchFn(`${this.c.baseUrl}/sms/rest/v2/msgheader`, { headers: { Authorization: `Basic ${auth}` }, signal: AbortSignal.timeout(this.c.timeoutMs) });
    const raw = await res.text();
    let data: { code?: string; msgheaders?: string[]; msgheader?: string[]; description?: string } = {};
    try { data = JSON.parse(raw); } catch { /* */ }
    const code = String(data.code ?? `HTTP_${res.status}`);
    const headers = data.msgheaders ?? data.msgheader ?? [];
    if (code !== '00') return { ok: false, headers, code, message: NETGSM_CODES[code]?.msg ?? data.description ?? raw.slice(0, 120) };
    const ok = headers.length === 0 || headers.includes(this.c.header);
    return { ok, headers, code, message: ok ? 'Kimlik bilgileri ve başlık geçerli' : `"${this.c.header}" başlığı hesapta yok` };
  }
}

/** SMS_PROVIDER değişkenine göre sağlayıcıyı seçer. */
export function smsProviderFactory(cfg: ConfigService): SmsProvider {
  const name = (cfg.get<string>('SMS_PROVIDER') || 'console').toLowerCase();
  if (name === 'netgsm') return NetgsmSmsProvider.fromConfig(cfg);
  if (name !== 'console') throw new Error(`Bilinmeyen SMS_PROVIDER: ${name} (console veya netgsm)`);
  if (cfg.get('NODE_ENV') === 'production') throw new Error('Üretimde SMS_PROVIDER=console kullanılamaz; netgsm ayarlayın');
  return new ConsoleSmsProvider();
}
