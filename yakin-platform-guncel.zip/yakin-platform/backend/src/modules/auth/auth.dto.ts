import { IsBoolean, IsOptional, IsString, Length, MaxLength } from 'class-validator';

export class OtpRequestDto {
  @IsString() @MaxLength(20) phone: string;
  /** Kullanım koşulları ve KVKK aydınlatma metni onayı (ilk girişte zorunlu). */
  @IsOptional() @IsBoolean() termsAccepted?: boolean;
}
export class OtpVerifyDto {
  @IsString() @MaxLength(20) phone: string;
  @IsString() @Length(6, 6) code: string;
  @IsOptional() @IsString() @MaxLength(120) device?: string;
  @IsOptional() @IsBoolean() termsAccepted?: boolean;
  /** Yönetici/moderatör iki adımlı doğrulama kodu (etkinse zorunlu). */
  @IsOptional() @IsString() @Length(6, 6) totpCode?: string;
}
export class TotpCodeDto {
  @IsString() @Length(6, 6) code: string;
}
export class RefreshDto {
  @IsString() refreshToken: string;
}
export class DeviceTokenDto {
  @IsString() @MaxLength(400) token: string;
  @IsOptional() @IsString() platform?: string;
}
