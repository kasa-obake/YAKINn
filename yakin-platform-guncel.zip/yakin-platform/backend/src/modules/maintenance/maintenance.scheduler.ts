import { Injectable, Logger, OnApplicationBootstrap, OnApplicationShutdown } from '@nestjs/common';
import { MaintenanceService } from './maintenance.service';

/** Saatlik bakım. Birden fazla sunucuda yalnızca birinde JOBS_ENABLED=true olmalıdır. */
@Injectable()
export class MaintenanceScheduler implements OnApplicationBootstrap, OnApplicationShutdown {
  private timer?: NodeJS.Timeout;
  private log = new Logger('Bakım');
  constructor(private svc: MaintenanceService) {}
  onApplicationBootstrap() {
    if (process.env.JOBS_ENABLED === 'false' || process.env.NODE_ENV === 'test') return;
    this.timer = setInterval(() => this.run(), 60 * 60_000);
    setTimeout(() => this.run(), 30_000).unref();
  }
  async run() {
    try {
      const r = await this.svc.runAll();
      if (Object.values(r).some((n) => n)) this.log.log(`Silinen hesap: ${r.purged}, OTP: ${r.otp}, oturum: ${r.refreshTokens}, bildirim: ${r.notifications}, sahipsiz fotoğraf: ${r.orphans}`);
    } catch (e) {
      this.log.error(e);
    }
  }
  onApplicationShutdown() {
    if (this.timer) clearInterval(this.timer);
  }
}
