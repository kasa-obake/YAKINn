import { Module } from '@nestjs/common';
import { MediaModule } from '../media/media.module';
import { MaintenanceScheduler } from './maintenance.scheduler';
import { MaintenanceService } from './maintenance.service';

@Module({ imports: [MediaModule], providers: [MaintenanceService, MaintenanceScheduler], exports: [MaintenanceService] })
export class MaintenanceModule {}
