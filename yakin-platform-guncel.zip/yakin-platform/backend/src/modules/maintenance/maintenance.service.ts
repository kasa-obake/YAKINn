import { Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { MediaStorage } from '../media/storage';
import { RealtimeGateway } from '../core/realtime.gateway';

export const DELETION_GRACE_DAYS = 30;

/** Periyodik bakım: hesap silme (KVKK), eski kayıtların temizliği, sahipsiz fotoğrafların silinmesi. */
@Injectable()
export class MaintenanceService {
  private log = new Logger('Bakım');
  constructor(@InjectDataSource() private ds: DataSource, private storage: MediaStorage, private rt: RealtimeGateway) {}

  async runAll() {
    const purged = await this.purgeDeletedAccounts();
    const cleaned = await this.cleanupOldRecords();
    const orphans = await this.cleanupOrphanMedia();
    return { purged, ...cleaned, orphans };
  }

  /** Silme talebinden 30 gün geçen hesapların kişisel verisini kalıcı olarak siler (kayıt anonimleştirilir). */
  async purgeDeletedAccounts(graceDays = DELETION_GRACE_DAYS) {
    const rows: { id: string; phone: string }[] = await this.ds.query(
      `SELECT id, phone FROM users WHERE "deletionRequestedAt" IS NOT NULL AND "deletionRequestedAt" <= now() - make_interval(days => $1) AND status <> 'deleted' ORDER BY "deletionRequestedAt" LIMIT 50`,
      [graceDays],
    );
    for (const u of rows) await this.purgeUser(u.id, u.phone);
    return rows.length;
  }

  /**
   * Bir hesabı anonimleştirir. Silinenler: profil, telefon, mesaj metinleri, favoriler, engeller, bildirimler,
   * cihaz ve oturum kayıtları, destek talepleri, fotoğraf dosyaları, ilan içerikleri.
   * Kalanlar (anonim kimlikle): puanlar, moderasyon kayıtları ve denetim günlüğü (yasal saklama için).
   */
  async purgeUser(id: string, phone: string) {
    const urls: string[] = await this.ds.transaction(async (m) => {
      const found: { url: string }[] = await m.query(
        `SELECT url FROM media_uploads WHERE "userId"=$1
         UNION SELECT url FROM listing_media WHERE "listingId" IN (SELECT id FROM listings WHERE "userId"=$1)
         UNION SELECT "imageUrl" FROM messages WHERE "senderId"=$1 AND "imageUrl" IS NOT NULL
         UNION SELECT "avatarUrl" FROM users WHERE id=$1 AND "avatarUrl" IS NOT NULL`,
        [id],
      );
      const kept: { u: string }[] = await m.query(`SELECT "screenshotUrl" AS u FROM reports WHERE "screenshotUrl" IS NOT NULL`);
      const keep = new Set(kept.map((k) => k.u));
      const deletable = found.map((f) => f.url).filter((u) => u && !keep.has(u));

      await m.query(`DELETE FROM listing_media WHERE "listingId" IN (SELECT id FROM listings WHERE "userId"=$1)`, [id]);
      await m.query(`UPDATE listings SET title='Silinmiş ilan', description='', details='{}'::jsonb, "priceKurus"=NULL, "exactPoint"=NULL WHERE "userId"=$1`, [id]);
      await m.query(`UPDATE messages SET body='', "imageUrl"=NULL, "deletedAt"=COALESCE("deletedAt", now()) WHERE "senderId"=$1`, [id]);
      await m.query(`UPDATE reviews SET comment='' WHERE "fromId"=$1`, [id]);
      await m.query(`DELETE FROM favorites WHERE "userId"=$1`, [id]);
      await m.query(`DELETE FROM blocks WHERE "userId"=$1 OR "blockedId"=$1`, [id]);
      await m.query(`DELETE FROM notifications WHERE "userId"=$1`, [id]);
      await m.query(`DELETE FROM device_tokens WHERE "userId"=$1`, [id]);
      await m.query(`DELETE FROM refresh_tokens WHERE "userId"=$1`, [id]);
      await m.query(`DELETE FROM otp_codes WHERE phone=$1`, [phone]);
      await m.query(`DELETE FROM support_tickets WHERE "userId"=$1`, [id]);
      if (deletable.length) await m.query(`DELETE FROM media_uploads WHERE "userId"=$1 AND url = ANY($2)`, [id, deletable]);
      await m.query(
        `UPDATE users SET phone='deleted:'||id::text, "firstName"='', "lastName"='', "birthYear"=NULL, bio='', "avatarUrl"=NULL, "neighborhoodId"=NULL,
           interests='{}', "notificationPrefs"='{}'::jsonb, "suspendedUntil"=NULL, "totpSecret"=NULL, "totpEnabledAt"=NULL, status='deleted' WHERE id=$1`,
        [id],
      );
      await m.query(`INSERT INTO audit_logs ("actorId", action, "targetType", "targetId", meta) VALUES (NULL, 'user.purged', 'user', $1, '{}')`, [id]);
      return deletable;
    });
    this.rt.disconnectUser(id);
    await this.deleteFiles(urls);
    this.log.log(`Hesap kalıcı olarak anonimleştirildi: ${id} (${urls.length} dosya silindi)`);
  }

  /** Süresi geçmiş OTP, oturum ve eski bildirim kayıtlarını siler. */
  async cleanupOldRecords() {
    const otp = await this.ds.query(`DELETE FROM otp_codes WHERE "createdAt" < now() - interval '2 days' RETURNING 1`);
    const rt = await this.ds.query(`DELETE FROM refresh_tokens WHERE "expiresAt" < now() - interval '1 day' RETURNING 1`);
    const nt = await this.ds.query(`DELETE FROM notifications WHERE "createdAt" < now() - interval '180 days' RETURNING 1`);
    return { otp: (otp[0] ?? []).length, refreshTokens: (rt[0] ?? []).length, notifications: (nt[0] ?? []).length };
  }

  /** 24 saatten eski olup hiçbir ilanda, mesajda, profilde veya şikayette kullanılmayan yüklemeleri siler. */
  async cleanupOrphanMedia(limit = 200) {
    const rows: { id: string; url: string }[] = await this.ds.query(
      `SELECT mu.id, mu.url FROM media_uploads mu
       WHERE mu."createdAt" < now() - interval '24 hours'
         AND NOT EXISTS (SELECT 1 FROM listing_media lm WHERE lm.url = mu.url)
         AND NOT EXISTS (SELECT 1 FROM messages m WHERE m."imageUrl" = mu.url)
         AND NOT EXISTS (SELECT 1 FROM users u WHERE u."avatarUrl" = mu.url)
         AND NOT EXISTS (SELECT 1 FROM reports r WHERE r."screenshotUrl" = mu.url)
       ORDER BY mu."createdAt" LIMIT $1`,
      [limit],
    );
    if (!rows.length) return 0;
    await this.deleteFiles(rows.map((r) => r.url));
    await this.ds.query(`DELETE FROM media_uploads WHERE id = ANY($1::uuid[])`, [rows.map((r) => r.id)]);
    return rows.length;
  }

  private async deleteFiles(urls: string[]) {
    const res = await Promise.allSettled(urls.map((u) => this.storage.delete(u)));
    const failed = res.filter((r) => r.status === 'rejected').length;
    if (failed) this.log.warn(`${failed} dosya silinemedi (sonraki turda tekrar denenmez, kayıtları kontrol edin)`);
  }
}
