import { Body, Controller, Delete, Get, HttpCode, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../../common/auth.guard';
import { User } from '../../database/entities';
import { ListConversationsDto, MessagesQueryDto, SendMessageDto, StartConversationDto } from './chat.dto';
import { ChatService } from './chat.service';

@ApiTags('chat')
@Controller()
export class ChatController {
  constructor(private svc: ChatService) {}

  @Get('conversations') list(@CurrentUser() u: User, @Query() q: ListConversationsDto) { return this.svc.list(u, q); }
  @Post('conversations') @HttpCode(200) start(@CurrentUser() u: User, @Body() dto: StartConversationDto) { return this.svc.start(u, dto.listingId); }
  @Get('conversations/:id') get(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.get(u, id); }
  @Get('conversations/:id/messages') messages(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Query() q: MessagesQueryDto) { return this.svc.messages(u, id, q); }
  @Post('conversations/:id/messages') send(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: SendMessageDto) { return this.svc.send(u, id, dto); }
  @Post('conversations/:id/read') @HttpCode(200) read(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.markRead(u, id); }
  @Post('conversations/:id/archive') @HttpCode(200) archive(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.toggle(u, id, 'archivedBy', true); }
  @Delete('conversations/:id/archive') unarchive(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.toggle(u, id, 'archivedBy', false); }
  @Post('conversations/:id/mute') @HttpCode(200) mute(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.toggle(u, id, 'mutedBy', true); }
  @Delete('conversations/:id/mute') unmute(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.toggle(u, id, 'mutedBy', false); }
  @Delete('messages/:id') del(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.deleteMessage(u, id); }
}
