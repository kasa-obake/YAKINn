import { Type } from 'class-transformer';
import { IsBoolean, IsIn, IsInt, IsOptional, IsString, IsUUID, Max, MaxLength, Min } from 'class-validator';

export class StartConversationDto {
  @IsUUID() listingId: string;
}
export class SendMessageDto {
  @IsOptional() @IsString() @MaxLength(2000) body?: string;
  /** Önce /media ile yüklenen fotoğrafın kimliği. */
  @IsOptional() @IsUUID() mediaId?: string;
  /** IBAN içeren mesajda gönderen onayı. */
  @IsOptional() @IsBoolean() confirmPayment?: boolean;
  /** İstemcinin geçici kimliği; iyimser arayüz için geri döndürülür. */
  @IsOptional() @IsString() @MaxLength(64) clientId?: string;
}
export class ListConversationsDto {
  @IsOptional() @IsIn(['all', 'mine', 'interested']) filter?: 'all' | 'mine' | 'interested';
  @IsOptional() @IsIn(['true', 'false']) archived?: string;
}
export class MessagesQueryDto {
  @IsOptional() @IsString() before?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit?: number;
}
