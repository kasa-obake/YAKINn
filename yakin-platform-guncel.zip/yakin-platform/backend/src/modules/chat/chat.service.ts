import { Injectable } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, In, IsNull, MoreThan, Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { clampLimit, decodeCursor, encodeCursor } from '../../common/format';
import { listingCard, userCard } from '../../common/presenters';
import { IBAN_RE, messageWarnings } from '../../common/safety';
import { Conversation, Listing, ListingStatus, MediaUpload, Message, User } from '../../database/entities';
import { BlocksService } from '../core/blocks.service';
import { NotificationsService } from '../core/notifications.service';
import { RealtimeGateway } from '../core/realtime.gateway';
import { ListConversationsDto, MessagesQueryDto, SendMessageDto } from './chat.dto';

const DELETE_WINDOW_MS = 10 * 60_000;
const READONLY_AFTER_CLOSE_MS = 7 * 86_400_000;
const MAX_MSG_PER_MIN = 30;
const NEW_CONV_PER_DAY = 30;

@Injectable()
export class ChatService {
  constructor(
    @InjectDataSource() private ds: DataSource,
    @InjectRepository(Conversation) private convs: Repository<Conversation>,
    @InjectRepository(Message) private msgs: Repository<Message>,
    @InjectRepository(Listing) private listings: Repository<Listing>,
    @InjectRepository(User) private users: Repository<User>,
    @InjectRepository(MediaUpload) private uploads: Repository<MediaUpload>,
    private blocks: BlocksService,
    private notify: NotificationsService,
    private rt: RealtimeGateway,
  ) {}

  private other(c: Conversation, me: string) {
    return c.buyerId === me ? c.sellerId : c.buyerId;
  }
  private async mine(me: User, id: string) {
    const c = await this.convs.findOne({ where: { id }, relations: { listing: true } });
    if (!c || (c.buyerId !== me.id && c.sellerId !== me.id)) throw Errors.notFound('Sohbet');
    return c;
  }

  messageView(m: Message) {
    return { id: m.id, conversationId: m.conversationId, senderId: m.senderId, kind: m.kind, body: m.deletedAt ? '' : m.body, imageUrl: m.deletedAt ? null : m.imageUrl, warnings: m.warnings, readAt: m.readAt, deleted: !!m.deletedAt, createdAt: m.createdAt };
  }

  private readOnlyReason(c: Conversation, blocked: boolean): string | null {
    if (blocked) return 'blocked';
    const l = c.listing;
    if (l.status === ListingStatus.REMOVED) return 'listing_removed';
    if (l.status === ListingStatus.CLOSED && l.closedAt && Date.now() - l.closedAt.getTime() > READONLY_AFTER_CLOSE_MS) return 'listing_closed';
    return null;
  }

  async start(me: User, listingId: string) {
    const l = await this.listings.findOne({ where: { id: listingId } });
    if (!l) throw Errors.notFound('İlan');
    if (l.userId === me.id) throw new AppError('CHAT_OWN_LISTING', 'Kendi ilanına mesaj gönderemezsin', 400);
    const existing = await this.convs.findOne({ where: { listingId, buyerId: me.id } });
    if (existing) return { id: existing.id, created: false };
    if (l.status !== ListingStatus.ACTIVE) throw new AppError('LISTING_NOT_AVAILABLE', 'Bu ilan artık yayında değil', 410);
    if (await this.blocks.isBlockedBetween(me.id, l.userId)) throw new AppError('CHAT_BLOCKED', 'Bu kişiyle mesajlaşamazsın', 403);
    const today = await this.convs.count({ where: { buyerId: me.id, createdAt: MoreThan(new Date(Date.now() - 86_400_000)) } });
    if (today >= NEW_CONV_PER_DAY) throw new AppError('CHAT_RATE_LIMITED', 'Bugün çok fazla yeni sohbet başlattın', 429);
    const c = await this.convs.save(this.convs.create({ listingId, buyerId: me.id, sellerId: l.userId }));
    return { id: c.id, created: true };
  }

  async list(me: User, q: ListConversationsDto) {
    const params: unknown[] = [me.id];
    const where = [`(c."buyerId"=$1 OR c."sellerId"=$1)`, `EXISTS (SELECT 1 FROM messages mm WHERE mm."conversationId"=c.id)`];
    if (q.filter === 'mine') where.push(`c."sellerId"=$1`);
    if (q.filter === 'interested') where.push(`c."buyerId"=$1`);
    where.push(q.archived === 'true' ? `$1 = ANY(c."archivedBy")` : `NOT ($1 = ANY(c."archivedBy"))`);
    const rows = await this.ds.query(
      `SELECT c.id, c."listingId", c."buyerId", c."sellerId", c."lastMessageAt", ($1 = ANY(c."mutedBy")) AS muted,
              (SELECT COUNT(*)::int FROM messages m WHERE m."conversationId"=c.id AND m."senderId" IS NOT NULL AND m."senderId"<>$1 AND m."readAt" IS NULL) AS unread
         FROM conversations c WHERE ${where.join(' AND ')} ORDER BY c."lastMessageAt" DESC LIMIT 200`,
      params,
    );
    if (!rows.length) return { items: [] };
    const otherIds = rows.map((r: Conversation) => (r.buyerId === me.id ? r.sellerId : r.buyerId));
    const [users, listings, lasts, hidden] = await Promise.all([
      this.users.find({ where: { id: In(otherIds) } }),
      this.listings.find({ where: { id: In(rows.map((r: Conversation) => r.listingId)) } }),
      this.ds.query(`SELECT DISTINCT ON ("conversationId") * FROM messages WHERE "conversationId" = ANY($1::uuid[]) ORDER BY "conversationId", "createdAt" DESC`, [rows.map((r: Conversation) => r.id)]),
      this.blocks.hiddenIds(me.id),
    ]);
    return {
      items: rows.map((r: Conversation & { muted: boolean; unread: number }) => {
        const oid = r.buyerId === me.id ? r.sellerId : r.buyerId;
        const last = lasts.find((m: Message) => m.conversationId === r.id);
        const l = listings.find((x) => x.id === r.listingId)!;
        return {
          id: r.id, role: r.sellerId === me.id ? 'owner' : 'interested', other: userCard(users.find((u) => u.id === oid)),
          listing: { ...listingCard(l), status: l.status }, lastMessage: last ? this.messageView(last) : null,
          unread: r.unread, muted: r.muted, blocked: hidden.includes(oid), lastMessageAt: r.lastMessageAt,
        };
      }),
    };
  }

  async get(me: User, id: string) {
    const c = await this.mine(me, id);
    const oid = this.other(c, me.id);
    const other = await this.users.findOne({ where: { id: oid } });
    const blocked = await this.blocks.isBlockedBetween(me.id, oid);
    return {
      id: c.id, role: c.sellerId === me.id ? 'owner' : 'interested', other: userCard(other), listing: listingCard(c.listing),
      readOnly: this.readOnlyReason(c, blocked), muted: c.mutedBy.includes(me.id), archived: c.archivedBy.includes(me.id),
      showReadReceipts: !!other?.showReadReceipts && me.showReadReceipts,
    };
  }

  async messages(me: User, id: string, q: MessagesQueryDto) {
    await this.mine(me, id);
    const limit = clampLimit(q.limit, 30, 100);
    const cur = decodeCursor(q.before);
    const qb = this.msgs.createQueryBuilder('m').where('m."conversationId" = :id', { id }).orderBy(`date_trunc('milliseconds', m."createdAt")`, 'DESC').addOrderBy('m.id', 'DESC').take(limit + 1);
    if (cur) qb.andWhere('(date_trunc(\'milliseconds\', m."createdAt"), m.id) < (:d, :mid)', { d: cur.createdAt, mid: cur.id });
    const rows = await qb.getMany();
    const page = rows.slice(0, limit);
    const last = page[page.length - 1];
    return { items: page.reverse().map((m) => this.messageView(m)), nextCursor: rows.length > limit && last ? encodeCursor(last.createdAt, last.id) : null };
  }

  async send(me: User, id: string, dto: SendMessageDto) {
    const c = await this.mine(me, id);
    const oid = this.other(c, me.id);
    const ro = this.readOnlyReason(c, await this.blocks.isBlockedBetween(me.id, oid));
    if (ro === 'blocked') throw new AppError('CHAT_BLOCKED', 'Bu kişiyle mesajlaşamazsın', 403);
    if (ro) throw new AppError('CHAT_LISTING_CLOSED', 'Bu sohbet artık yalnızca okunabilir', 409, { reason: ro });
    const body = (dto.body ?? '').trim();
    if (!body && !dto.mediaId) throw new AppError('VALIDATION_ERROR', 'Mesaj boş olamaz', 400, { fields: { body: 'required' } });
    const recent = await this.msgs.count({ where: { senderId: me.id, createdAt: MoreThan(new Date(Date.now() - 60_000)) } });
    if (recent >= MAX_MSG_PER_MIN) throw new AppError('CHAT_RATE_LIMITED', 'Çok hızlı mesaj gönderiyorsun', 429, { retryAfterSec: 30 });
    if (IBAN_RE.test(body) && !dto.confirmPayment) throw new AppError('CHAT_PAYMENT_CONFIRM', 'IBAN paylaşmadan önce onay gerekli', 409, { tip: 'Ürünü görmeden ödeme yapmamanı öneririz.' });
    let imageUrl: string | null = null;
    if (dto.mediaId) {
      const up = await this.uploads.findOne({ where: { id: dto.mediaId, userId: me.id } });
      if (!up) throw new AppError('MEDIA_NOT_FOUND', 'Fotoğraf bulunamadı', 400);
      imageUrl = up.url;
    }
    const warnings = messageWarnings(body);
    const m = await this.msgs.save(this.msgs.create({ conversationId: id, senderId: me.id, body, imageUrl, kind: imageUrl && !body ? 'image' : 'text', warnings }));
    await this.convs.update(id, { lastMessageAt: m.createdAt, archivedBy: [] });

    // Ana metrik: ilan sahibine ilk gerçek yanıtın zamanı.
    const l = c.listing;
    let isFirstReply = false;
    if (me.id !== l.userId && !l.firstReplyAt) {
      const res = await this.listings.update({ id: l.id, firstReplyAt: IsNull() }, { firstReplyAt: m.createdAt });
      isFirstReply = !!res.affected;
    }
    const view = this.messageView(m);
    for (const uid of [me.id, oid]) {
      this.rt.toUser(uid, 'message:new', { conversationId: id, message: view, clientId: uid === me.id ? dto.clientId : undefined });
      this.rt.toUser(uid, 'conversation:updated', { id });
    }
    if (!c.mutedBy.includes(oid)) {
      const preview = imageUrl && !body ? 'Fotoğraf gönderdi' : body.slice(0, 120);
      if (isFirstReply) {
        const mins = Math.max(1, Math.round((m.createdAt.getTime() - (l.publishedAt ?? l.createdAt).getTime()) / 60_000));
        await this.notify.notify(oid, 'first_reply', 'İlanına ilk yanıt geldi', `${me.displayName}: ${preview}`, `/chat/${id}`, { conversationId: id, listingId: l.id, minutes: mins });
      } else {
        await this.notify.notify(oid, 'new_message', me.displayName, preview, `/chat/${id}`, { conversationId: id });
      }
    }
    return { message: view, clientId: dto.clientId ?? null };
  }

  async markRead(me: User, id: string) {
    const c = await this.mine(me, id);
    const oid = this.other(c, me.id);
    const now = new Date();
    const res = await this.msgs.update({ conversationId: id, senderId: oid, readAt: IsNull() }, { readAt: now });
    const other = await this.users.findOne({ where: { id: oid } });
    if (res.affected && me.showReadReceipts && other?.showReadReceipts) this.rt.toUser(oid, 'message:read', { conversationId: id, readAt: now });
    this.rt.toUser(me.id, 'conversation:updated', { id });
    return { ok: true, marked: res.affected ?? 0 };
  }

  async deleteMessage(me: User, messageId: string) {
    const m = await this.msgs.findOne({ where: { id: messageId, senderId: me.id, deletedAt: IsNull() } });
    if (!m) throw Errors.notFound('Mesaj');
    if (Date.now() - m.createdAt.getTime() > DELETE_WINDOW_MS) throw new AppError('CHAT_DELETE_WINDOW', 'Mesaj yalnızca ilk 10 dakika içinde silinebilir', 409);
    // İçerik kullanıcıya görünmez ama şikâyet incelemesi için veritabanında saklanır.
    await this.msgs.update(m.id, { deletedAt: new Date() });
    const c = await this.convs.findOneOrFail({ where: { id: m.conversationId } });
    for (const uid of [c.buyerId, c.sellerId]) this.rt.toUser(uid, 'message:deleted', { conversationId: c.id, messageId: m.id });
    return { ok: true };
  }

  async toggle(me: User, id: string, field: 'archivedBy' | 'mutedBy', on: boolean) {
    const c = await this.mine(me, id);
    const set = new Set(c[field]);
    if (on) set.add(me.id); else set.delete(me.id);
    await this.convs.update(id, { [field]: [...set] });
    return { [field === 'archivedBy' ? 'archived' : 'muted']: on };
  }

  async unreadCount(me: User) {
    const [r] = await this.ds.query(
      `SELECT COUNT(*)::int AS n FROM messages m JOIN conversations c ON c.id=m."conversationId"
        WHERE (c."buyerId"=$1 OR c."sellerId"=$1) AND m."senderId" IS NOT NULL AND m."senderId"<>$1 AND m."readAt" IS NULL AND m."deletedAt" IS NULL`,
      [me.id],
    );
    return r.n as number;
  }
}

