import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { LocalMediaStorage, MediaStorage } from './storage';
import { S3MediaStorage } from './storage.s3';
import { MediaController } from './media.controller';

export function mediaStorageFactory(cfg: ConfigService): MediaStorage {
  const driver = cfg.get<string>('MEDIA_DRIVER') || 'local';
  if (driver === 'local') return new LocalMediaStorage(cfg);
  if (driver === 's3') return new S3MediaStorage(cfg);
  throw new Error(`Bilinmeyen MEDIA_DRIVER: ${driver} (local veya s3 olmalı)`);
}

@Module({
  controllers: [MediaController],
  providers: [{ provide: MediaStorage, inject: [ConfigService], useFactory: mediaStorageFactory }],
  exports: [MediaStorage],
})
export class MediaModule {}
