import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DeleteObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { MediaStorage, SAFE_KEY } from './storage';

/**
 * S3 uyumlu depo. Ortam değişkenleri:
 *   S3_BUCKET, S3_REGION (varsayılan auto), S3_ENDPOINT (AWS dışı sağlayıcılar için),
 *   S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_PUBLIC_BASE_URL (CDN veya bucket'ın herkese açık adresi),
 *   S3_FORCE_PATH_STYLE=true (MinIO gibi sağlayıcılar için)
 * Bucket'a herkese açık okuma izni (veya önünde CDN) gerekir. Nesnelere ACL yazılmaz.
 */
@Injectable()
export class S3MediaStorage extends MediaStorage {
  private bucket: string;
  private base: string;
  private client: Pick<S3Client, 'send'>;

  constructor(cfg: ConfigService, client?: Pick<S3Client, 'send'>) {
    super();
    const need = (k: string) => {
      const v = cfg.get<string>(k);
      if (!v) throw new Error(`MEDIA_DRIVER=s3 için ${k} gerekli`);
      return v;
    };
    this.bucket = need('S3_BUCKET');
    this.base = need('S3_PUBLIC_BASE_URL').replace(/\/$/, '');
    this.client =
      client ??
      new S3Client({
        region: cfg.get('S3_REGION') || 'auto',
        endpoint: cfg.get('S3_ENDPOINT') || undefined,
        forcePathStyle: cfg.get('S3_FORCE_PATH_STYLE') === 'true',
        credentials: { accessKeyId: need('S3_ACCESS_KEY_ID'), secretAccessKey: need('S3_SECRET_ACCESS_KEY') },
      });
  }

  async put(key: string, data: Buffer, contentType: string) {
    await this.client.send(new PutObjectCommand({ Bucket: this.bucket, Key: key, Body: data, ContentType: contentType, CacheControl: 'public, max-age=31536000, immutable' }));
    return `${this.base}/${key}`;
  }

  async delete(url: string) {
    if (!url.startsWith(`${this.base}/`)) return;
    const key = decodeURIComponent(url.slice(this.base.length + 1).split('?')[0]);
    if (!SAFE_KEY.test(key)) return;
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}
