import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { mkdir, unlink, writeFile } from 'fs/promises';
import { join, resolve } from 'path';

/**
 * Dosya deposu arayüzü. `MEDIA_DRIVER=local` (varsayılan) yerel disk, `MEDIA_DRIVER=s3` S3 uyumlu depo
 * (AWS S3, Cloudflare R2, MinIO, Wasabi vb.) kullanır.
 */
export abstract class MediaStorage {
  /** Dosyayı yazar ve herkese açık adresini döndürür. */
  abstract put(key: string, data: Buffer, contentType: string): Promise<string>;
  /** Daha önce `put` ile verilen adresteki dosyayı siler. Dosya yoksa veya bu depoya ait değilse sessizce döner. */
  abstract delete(url: string): Promise<void>;
}

/** Yol gezintisini (../) önlemek için yalnızca bu desene uyan anahtarlar kabul edilir. */
export const SAFE_KEY = /^[A-Za-z0-9][A-Za-z0-9._-]{0,150}$/;

@Injectable()
export class LocalMediaStorage extends MediaStorage {
  constructor(private cfg: ConfigService) {
    super();
  }
  dir() {
    return resolve(this.cfg.get('MEDIA_DIR') || 'uploads');
  }
  async put(key: string, data: Buffer) {
    await mkdir(this.dir(), { recursive: true });
    await writeFile(join(this.dir(), key), data);
    const base = (this.cfg.get<string>('PUBLIC_BASE_URL') || '').replace(/\/$/, '');
    return `${base}/uploads/${key}`;
  }
  async delete(url: string) {
    const i = url.indexOf('/uploads/');
    if (i < 0) return;
    const key = decodeURIComponent(url.slice(i + '/uploads/'.length).split('?')[0]);
    if (!SAFE_KEY.test(key)) return;
    try {
      await unlink(join(this.dir(), key));
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e;
    }
  }
}
