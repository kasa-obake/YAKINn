import { Controller, HttpCode, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { InjectRepository } from '@nestjs/typeorm';
import { randomUUID } from 'crypto';
import sharp from 'sharp';
import { MoreThan, Repository } from 'typeorm';
import { AllowIncompleteProfile, CurrentUser } from '../../common/auth.guard';
import { AppError } from '../../common/errors';
import { MediaUpload, User } from '../../database/entities';
import { MediaStorage } from './storage';

export const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;
const DAILY_LIMIT = 60;

@ApiTags('media')
@Controller('media')
export class MediaController {
  constructor(private storage: MediaStorage, @InjectRepository(MediaUpload) private uploads: Repository<MediaUpload>) {}

  /**
   * Fotoğraf yükleme. Görsel yeniden kodlanır: EXIF/GPS dahil tüm üst veri silinir,
   * yönü düzeltilir, uzun kenar 1600 px'e indirilir, JPEG kalite 80.
   */
  @AllowIncompleteProfile() @Post() @HttpCode(201)
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } })
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_UPLOAD_BYTES } }))
  async upload(@CurrentUser() u: User, @UploadedFile() file?: Express.Multer.File) {
    if (!file) throw new AppError('MEDIA_REQUIRED', 'Dosya seçilmedi', 400);
    const today = await this.uploads.count({ where: { userId: u.id, createdAt: MoreThan(new Date(Date.now() - 86_400_000)) } });
    if (today >= DAILY_LIMIT) throw new AppError('MEDIA_DAILY_LIMIT', 'Günlük fotoğraf sınırına ulaştın', 429);
    let out: { data: Buffer; info: { width: number; height: number } };
    try {
      out = await sharp(file.buffer, { failOn: 'error', limitInputPixels: 50_000_000 })
        .rotate()
        .resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 80, mozjpeg: true })
        .toBuffer({ resolveWithObject: true });
    } catch {
      throw new AppError('MEDIA_UNSUPPORTED', 'Bu dosya türü desteklenmiyor', 415);
    }
    const key = `${randomUUID()}.jpg`;
    const url = await this.storage.put(key, out.data, 'image/jpeg');
    const row = await this.uploads.save(this.uploads.create({ userId: u.id, url, width: out.info.width, height: out.info.height, bytes: out.data.length }));
    return { id: row.id, url, width: row.width, height: row.height };
  }
}
