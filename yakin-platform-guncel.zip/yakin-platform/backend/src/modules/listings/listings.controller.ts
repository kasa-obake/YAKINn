import { Body, Controller, Delete, Get, HttpCode, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../../common/auth.guard';
import { User } from '../../database/entities';
import { CloseListingDto, CreateListingDto, FeedQueryDto, MapQueryDto, MyListingsQueryDto, ReviewDto, UpdateListingDto } from './listings.dto';
import { ListingsService } from './listings.service';

@ApiTags('listings')
@Controller()
export class ListingsController {
  constructor(private svc: ListingsService) {}

  @Get('listings') feed(@CurrentUser() u: User, @Query() q: FeedQueryDto) { return this.svc.feed(u, q); }
  @Get('listings/count') count(@CurrentUser() u: User, @Query() q: FeedQueryDto) { return this.svc.count(u, q); }
  @Get('listings/map') map(@CurrentUser() u: User, @Query() q: MapQueryDto) { return this.svc.map(u, q); }
  @Get('listings/:id') detail(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.detail(u, id); }
  @Post('listings') create(@CurrentUser() u: User, @Body() dto: CreateListingDto) { return this.svc.create(u, dto); }
  @Patch('listings/:id') update(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateListingDto) { return this.svc.update(u, id, dto); }
  @Post('listings/:id/close') @HttpCode(200) close(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: CloseListingDto) { return this.svc.close(u, id, dto); }
  @Post('listings/:id/reopen') @HttpCode(200) reopen(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.reopen(u, id); }
  @Post('listings/:id/extend') @HttpCode(200) extend(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.extend(u, id); }
  @Delete('listings/:id') remove(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.remove(u, id); }
  @Post('listings/:id/favorite') @HttpCode(200) fav(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.favorite(u, id, true); }
  @Delete('listings/:id/favorite') unfav(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.favorite(u, id, false); }
  @Post('listings/:id/reviews') review(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: ReviewDto) { return this.svc.review(u, id, dto); }

  @Get('me/listings') mine(@CurrentUser() u: User, @Query() q: MyListingsQueryDto) { return this.svc.mine(u, q.status); }
  @Get('me/listings/draft') draft(@CurrentUser() u: User) { return this.svc.draft(u); }
  @Get('me/favorites') favorites(@CurrentUser() u: User) { return this.svc.favorites(u); }
  @Get('me/pending-reviews') pending(@CurrentUser() u: User) { return this.svc.pendingReviews(u); }
}
