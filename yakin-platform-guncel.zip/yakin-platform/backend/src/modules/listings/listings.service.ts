import { Injectable } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, In, IsNull, MoreThan, Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { clampLimit, decodeCursor, encodeCursor } from '../../common/format';
import { displayPointFrom, fromPoint, toPoint } from '../../common/geo';
import { distanceView, listingCard, neighborhoodView, userCard } from '../../common/presenters';
import { listingContactWarnings } from '../../common/safety';
import {
  CloseReason, Conversation, Favorite, Listing, ListingCategory, ListingMedia, ListingStatus, MediaUpload, Message,
  Report, ReportPriority, ReportTarget, Review, SUBTYPES, User, UserRole,
} from '../../database/entities';
import { AuditService } from '../core/audit.service';
import { BlocksService } from '../core/blocks.service';
import { GeoService } from '../core/geo.service';
import { NotificationsService } from '../core/notifications.service';
import { RealtimeGateway } from '../core/realtime.gateway';
import { ContentRulesService } from './content-rules.service';
import { CloseListingDto, CreateListingDto, FeedQueryDto, ListingBaseDto, MapQueryDto, ReviewDto, UpdateListingDto } from './listings.dto';

export const MAX_ACTIVE_LISTINGS = 10;
const MAX_PUBLISH_PER_HOUR = 5;
const LISTING_TTL_DAYS = 30;
const MAX_NEIGHBOR_DISTANCE_M = 3000;
const REVIEW_WINDOW_DAYS = 14;
const MAX_FAVORITES = 100;
const DETAIL_KEYS: Record<ListingCategory, string[]> = {
  [ListingCategory.ESYA]: ['condition', 'loanDays', 'swapFor', 'brand'],
  [ListingCategory.YARDIM]: ['when', 'date', 'duration', 'skill'],
  [ListingCategory.KAYIP]: ['date', 'animalType', 'color', 'distinctive', 'reward'],
};
const ACTIVE_LIKE = [ListingStatus.ACTIVE, ListingStatus.PENDING_REVIEW];

type FeedRow = { id: string; dist: number; publishedAt: Date };

@Injectable()
export class ListingsService {
  constructor(
    @InjectDataSource() private ds: DataSource,
    @InjectRepository(Listing) private repo: Repository<Listing>,
    @InjectRepository(ListingMedia) private mediaRepo: Repository<ListingMedia>,
    @InjectRepository(MediaUpload) private uploads: Repository<MediaUpload>,
    @InjectRepository(Favorite) private favs: Repository<Favorite>,
    @InjectRepository(Conversation) private convs: Repository<Conversation>,
    @InjectRepository(Message) private messages: Repository<Message>,
    @InjectRepository(Review) private reviews: Repository<Review>,
    @InjectRepository(Report) private reports: Repository<Report>,
    @InjectRepository(User) private users: Repository<User>,
    private geo: GeoService,
    private blocks: BlocksService,
    private rules: ContentRulesService,
    private notify: NotificationsService,
    private audit: AuditService,
    private rt: RealtimeGateway,
  ) {}

  // ---------- Okuma ----------

  private async center(user: User, neighborhoodId?: number) {
    const n = await this.geo.get(neighborhoodId ?? user.neighborhoodId!);
    return fromPoint(n.centroid);
  }

  private async buildWhere(user: User, q: FeedQueryDto, params: unknown[]) {
    const c = await this.center(user, q.neighborhoodId);
    params.push(c.lng, c.lat);
    const where = [`l.status='active'`, `l."expiresAt" > now()`];
    const radius = (q.radiusKm ?? 5) * 1000;
    params.push(radius);
    where.push(`ST_DWithin(l."displayPoint", ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, $3)`);
    const hidden = await this.blocks.hiddenIds(user.id);
    if (hidden.length) {
      params.push(hidden);
      where.push(`l."userId" <> ALL($${params.length}::uuid[])`);
    }
    if (q.category) { params.push(q.category); where.push(`l.category=$${params.length}`); }
    if (q.subtype) { params.push(q.subtype.split(',')); where.push(`l.subtype = ANY($${params.length}::text[])`); }
    if (q.freeOnly === 'true' || q.freeOnly === '1') where.push(`(l."priceKurus" IS NULL OR l."priceKurus"=0) AND l.subtype <> 'satilik'`);
    if (q.minPrice != null) { params.push(q.minPrice); where.push(`l."priceKurus" >= $${params.length}`); }
    if (q.maxPrice != null) { params.push(q.maxPrice); where.push(`COALESCE(l."priceKurus",0) <= $${params.length}`); }
    if (q.since) {
      const iv = { '24h': '24 hours', '7d': '7 days', '30d': '30 days' }[q.since];
      where.push(`l."publishedAt" > now() - interval '${iv}'`);
    }
    if (q.q?.trim()) {
      params.push(`%${q.q.trim().replace(/[%_\\]/g, (m) => '\\' + m)}%`);
      where.push(`immutable_unaccent(lower(l.title || ' ' || l.description)) LIKE immutable_unaccent(lower($${params.length}))`);
    }
    return where;
  }

  async feed(user: User, q: FeedQueryDto) {
    const params: unknown[] = [];
    const where = await this.buildWhere(user, q, params);
    const limit = clampLimit(q.limit, 20, 50);
    const sort = q.sort ?? 'new';
    let order: string, offset = 0;
    if (sort === 'near') {
      offset = Number(q.cursor?.startsWith('o') ? q.cursor.slice(1) : 0) || 0;
      order = `dist ASC, l.id ASC`;
    } else {
      const cur = decodeCursor(q.cursor);
      if (cur) {
        params.push(cur.createdAt, cur.id);
        where.push(`(date_trunc('milliseconds', l."publishedAt"), l.id) < ($${params.length - 1}, $${params.length})`);
      }
      order = `date_trunc('milliseconds', l."publishedAt") DESC, l.id DESC`;
    }
    const rows: FeedRow[] = await this.ds.query(
      `SELECT l.id, l."publishedAt", ST_Distance(l."displayPoint", ST_SetSRID(ST_MakePoint($1,$2),4326)::geography) AS dist
         FROM listings l WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ${limit + 1} OFFSET ${offset}`,
      params,
    );
    const page = rows.slice(0, limit);
    const items = await this.cards(user, page);
    const last = page[page.length - 1];
    const nextCursor = rows.length > limit && last ? (sort === 'near' ? `o${offset + limit}` : encodeCursor(new Date(last.publishedAt), last.id)) : null;
    return { items, nextCursor };
  }

  async count(user: User, q: FeedQueryDto) {
    const params: unknown[] = [];
    const where = await this.buildWhere(user, q, params);
    const [r] = await this.ds.query(`SELECT COUNT(*)::int AS n FROM listings l WHERE ${where.join(' AND ')}`, params);
    return { count: r.n };
  }

  private async cards(user: User, rows: { id: string; dist?: number | null }[]) {
    if (!rows.length) return [];
    const ids = rows.map((r) => r.id);
    const [list, favs] = await Promise.all([
      this.repo.find({ where: { id: In(ids) } }),
      this.favs.find({ where: { userId: user.id, listingId: In(ids) } }),
    ]);
    const fav = new Set(favs.map((f) => f.listingId));
    return rows.map((r) => list.find((l) => l.id === r.id)).filter(Boolean).map((l, i) => listingCard(l!, { distanceM: rows[i].dist, isFavorite: fav.has(l!.id) }));
  }

  async map(user: User, q: MapQueryDto) {
    const b = q.bbox.split(',').map(Number);
    if (b.length !== 4 || b.some((x) => !Number.isFinite(x))) throw new AppError('VALIDATION_ERROR', 'bbox geçersiz', 400, { fields: { bbox: 'invalid' } });
    const params: unknown[] = [...b];
    const where = [`l.status='active'`, `l."expiresAt" > now()`, `l."displayPoint" && ST_MakeEnvelope($1,$2,$3,$4,4326)::geography`];
    const hidden = await this.blocks.hiddenIds(user.id);
    if (hidden.length) { params.push(hidden); where.push(`l."userId" <> ALL($${params.length}::uuid[])`); }
    if (q.category) { params.push(q.category); where.push(`l.category=$${params.length}`); }
    const rows = await this.ds.query(
      `SELECT l.id, l.category, l.subtype, l.title, l."priceKurus", ST_Y(l."displayPoint"::geometry) AS lat, ST_X(l."displayPoint"::geometry) AS lng,
              (SELECT url FROM listing_media m WHERE m."listingId"=l.id ORDER BY position LIMIT 1) AS "coverUrl"
         FROM listings l WHERE ${where.join(' AND ')} ORDER BY l."publishedAt" DESC LIMIT 300`,
      params,
    );
    return { items: rows.map((r: Record<string, unknown>) => ({ ...r, priceKurus: r.priceKurus == null ? null : Number(r.priceKurus), approxRadiusM: 300 })) };
  }

  private canModerate(u: User) {
    return u.role === UserRole.MODERATOR || u.role === UserRole.ADMIN;
  }

  async detail(user: User, id: string) {
    const l = await this.repo.findOne({ where: { id }, relations: { user: true } });
    if (!l) throw Errors.notFound('İlan');
    const isOwner = l.userId === user.id;
    const myConv = isOwner ? null : await this.convs.findOne({ where: { listingId: id, buyerId: user.id } });
    if (!isOwner && !this.canModerate(user)) {
      if (await this.blocks.isBlockedBetween(user.id, l.userId)) throw Errors.notFound('İlan');
      const visible = l.status === ListingStatus.ACTIVE || (l.status === ListingStatus.CLOSED && !!myConv);
      if (!visible) throw new AppError('LISTING_NOT_AVAILABLE', 'Bu ilan artık yayında değil', 410, { status: l.status });
      await this.repo.increment({ id }, 'views', 1);
    }
    const c = await this.center(user);
    const [d] = await this.ds.query(
      `SELECT ST_Distance("displayPoint", ST_SetSRID(ST_MakePoint($1,$2),4326)::geography) AS d, ST_Y("displayPoint"::geometry) AS lat, ST_X("displayPoint"::geometry) AS lng FROM listings WHERE id=$3`,
      [c.lng, c.lat, id],
    );
    const fav = await this.favs.exist({ where: { userId: user.id, listingId: id } });
    const similar = l.status === ListingStatus.ACTIVE ? await this.feed(user, { category: l.category, radiusKm: 5, limit: 7 } as FeedQueryDto) : { items: [] };
    const ownerStats = isOwner
      ? { views: l.views, conversations: await this.convs.count({ where: { listingId: id } }), favorites: await this.favs.count({ where: { listingId: id } }) }
      : null;
    return {
      id: l.id,
      category: l.category,
      subtype: l.subtype,
      title: l.title,
      description: l.description,
      priceKurus: l.priceKurus,
      details: l.details,
      handover: l.handover,
      media: [...l.media].sort((a, b) => a.position - b.position).map((m) => ({ id: m.id, url: m.url, width: m.width, height: m.height, alt: m.alt })),
      neighborhood: neighborhoodView(l.neighborhood),
      approxLocation: { lat: Number(d.lat), lng: Number(d.lng), radiusM: 300 },
      distance: distanceView(Number(d.d)),
      status: l.status,
      closeReason: l.closeReason,
      moderationFlags: isOwner || this.canModerate(user) ? l.moderationFlags : undefined,
      publishedAt: l.publishedAt,
      expiresAt: l.expiresAt,
      createdAt: l.createdAt,
      owner: userCard(l.user),
      isOwner,
      isFavorite: fav,
      myConversationId: myConv?.id ?? null,
      ownerStats,
      similar: similar.items.filter((s) => s.id !== id).slice(0, 6),
    };
  }

  async mine(user: User, status?: string) {
    const where = status ? { userId: user.id, status: status as ListingStatus } : { userId: user.id };
    const list = await this.repo.find({ where, order: { createdAt: 'DESC' }, take: 100 });
    const ids = list.map((l) => l.id);
    const convCounts: { listingId: string; n: number }[] = ids.length
      ? await this.ds.query(`SELECT "listingId", COUNT(*)::int AS n FROM conversations WHERE "listingId" = ANY($1::uuid[]) GROUP BY 1`, [ids])
      : [];
    return {
      items: list.map((l) => ({
        ...listingCard(l),
        views: l.views,
        conversations: convCounts.find((c) => c.listingId === l.id)?.n ?? 0,
        expiresAt: l.expiresAt,
        closeReason: l.closeReason,
        moderationFlags: l.moderationFlags,
      })),
    };
  }

  // ---------- Yazma ----------

  private validateCore(category: ListingCategory, dto: ListingBaseDto & { subtype?: string }) {
    if (dto.subtype && !SUBTYPES[category].includes(dto.subtype)) throw new AppError('LISTING_SUBTYPE_INVALID', 'Alt tür bu kategoriye ait değil', 400, { allowed: SUBTYPES[category] });
    if (dto.details) {
      const allowed = DETAIL_KEYS[category];
      const clean: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(dto.details)) {
        if (!allowed.includes(k)) continue;
        if (typeof v === 'string') clean[k] = v.slice(0, 200);
        else if (typeof v === 'number' || typeof v === 'boolean') clean[k] = v;
      }
      dto.details = clean;
    }
  }

  private async attachMedia(user: User, ids: string[]) {
    if (!ids.length) return [];
    const ups = await this.uploads.find({ where: { id: In(ids), userId: user.id } });
    if (ups.length !== new Set(ids).size) throw new AppError('MEDIA_NOT_FOUND', 'Fotoğraf bulunamadı', 400);
    return ids.map((id, position) => {
      const u = ups.find((x) => x.id === id)!;
      return this.mediaRepo.create({ url: u.url, width: u.width, height: u.height, position });
    });
  }

  private async publishChecks(user: User, l: Listing) {
    if (!l.title || l.title.length < 5 || !l.description || l.description.length < 10) throw new AppError('VALIDATION_ERROR', 'Başlık ve açıklama gerekli', 400, { fields: { title: 'required', description: 'required' } });
    if (l.subtype === 'satilik' && !(l.priceKurus && l.priceKurus > 0)) throw new AppError('LISTING_PRICE_REQUIRED', 'Satılık ilanda fiyat gerekli', 400, { fields: { priceKurus: 'required' } });
    if (l.subtype !== 'satilik') l.priceKurus = null;
    if ((l.category === ListingCategory.ESYA || l.subtype === 'kayip_hayvan') && !l.media?.length) throw new AppError('LISTING_PHOTO_REQUIRED', 'En az bir fotoğraf ekle', 400, { fields: { mediaIds: 'required' } });
    const active = await this.repo.count({ where: { userId: user.id, status: In(ACTIVE_LIKE) } });
    const alreadyActive = l.id && ACTIVE_LIKE.includes(l.status);
    if (!alreadyActive && active >= MAX_ACTIVE_LISTINGS) throw new AppError('LISTING_LIMIT_REACHED', `Aynı anda en fazla ${MAX_ACTIVE_LISTINGS} aktif ilanın olabilir`, 409, { limit: MAX_ACTIVE_LISTINGS });
    if (!alreadyActive) {
      const lastHour = await this.repo.count({ where: { userId: user.id, publishedAt: MoreThan(new Date(Date.now() - 3600_000)) } });
      if (lastHour >= MAX_PUBLISH_PER_HOUR) throw new AppError('LISTING_RATE_LIMITED', 'Kısa sürede çok fazla ilan verdin, biraz sonra tekrar dene', 429);
    }
    const verdict = await this.rules.check(`${l.title}\n${l.description}`);
    if (verdict.action === 'block') throw new AppError('LISTING_CONTENT_BLOCKED', 'Bu içerik topluluk kurallarına aykırı', 422, { labels: verdict.labels });
    return verdict;
  }

  async create(user: User, dto: CreateListingDto) {
    this.validateCore(dto.category, dto);
    const nId = dto.neighborhoodId ?? user.neighborhoodId!;
    if ((await this.geo.distanceBetween(user.neighborhoodId!, nId)) > MAX_NEIGHBOR_DISTANCE_M) throw new AppError('LISTING_NEIGHBORHOOD_TOO_FAR', 'Yalnızca kendi mahallende veya yakın mahallelerde ilan verebilirsin', 400);
    const n = await this.geo.get(nId);
    let base = fromPoint(n.centroid), exact = null;
    if (dto.point && dto.category === ListingCategory.KAYIP) {
      await this.geo.resolve(dto.point.lat, dto.point.lng);
      base = dto.point;
      exact = toPoint(dto.point);
    }
    const publish = dto.publish !== false;
    const l = this.repo.create({
      userId: user.id, category: dto.category, subtype: dto.subtype, title: (dto.title ?? '').trim(), description: (dto.description ?? '').trim(),
      priceKurus: dto.priceKurus ?? null, details: dto.details ?? {}, handover: dto.handover ?? 'elden', neighborhoodId: nId,
      exactPoint: exact, displayPoint: toPoint(displayPointFrom(base)), status: ListingStatus.DRAFT,
      media: await this.attachMedia(user, dto.mediaIds ?? []), expiresAt: new Date(Date.now() + LISTING_TTL_DAYS * 86_400_000),
    });
    if (!publish) {
      // Kullanıcı başına tek taslak tutulur.
      await this.repo.delete({ userId: user.id, status: ListingStatus.DRAFT });
      const saved = await this.repo.save(l);
      return { id: saved.id, status: saved.status, warnings: [] };
    }
    const verdict = await this.publishChecks(user, l);
    this.applyVerdict(l, verdict);
    const saved = await this.repo.save(l);
    await this.repo.delete({ userId: user.id, status: ListingStatus.DRAFT });
    if (saved.status === ListingStatus.PENDING_REVIEW) await this.autoReport(saved, verdict.labels);
    else await this.fanOutHelp(saved);
    await this.audit.log(user.id, 'listing.create', 'listing', saved.id, { status: saved.status });
    return { id: saved.id, status: saved.status, warnings: listingContactWarnings(`${l.title} ${l.description}`) };
  }

  private applyVerdict(l: Listing, verdict: { action: string | null; labels: string[] }) {
    l.moderationFlags = verdict.labels;
    if (verdict.action === 'review') {
      l.status = ListingStatus.PENDING_REVIEW;
    } else {
      l.status = ListingStatus.ACTIVE;
      l.publishedAt = l.publishedAt ?? new Date();
    }
  }

  private async autoReport(l: Listing, labels: string[]) {
    await this.reports.insert({
      reporterId: null, targetType: ReportTarget.LISTING, targetId: l.id, targetOwnerId: l.userId, reason: 'auto_rule',
      note: labels.join(', '), priority: ReportPriority.NORMAL, slaDueAt: new Date(Date.now() + 24 * 3600_000),
    });
  }

  /** Yardım isteği yayınlanınca 1 km içindeki, bildirimi açık komşulara haber verilir (en fazla 50 kişi). */
  private async fanOutHelp(l: Listing) {
    if (l.category !== ListingCategory.YARDIM || l.subtype !== 'istiyorum') return;
    const rows: { id: string }[] = await this.ds.query(
      `SELECT u.id FROM users u JOIN neighborhoods n ON n.id=u."neighborhoodId"
        WHERE u.id <> $1 AND u.status='active' AND u."deletionRequestedAt" IS NULL
          AND COALESCE((u."notificationPrefs"->>'nearby_help')::boolean, true)
          AND ST_DWithin(n.centroid, (SELECT "displayPoint" FROM listings WHERE id=$2), 1000)
          AND NOT EXISTS (SELECT 1 FROM blocks b WHERE (b."userId"=u.id AND b."blockedId"=$1) OR (b."userId"=$1 AND b."blockedId"=u.id))
        LIMIT 50`,
      [l.userId, l.id],
    );
    await Promise.all(rows.map((r) => this.notify.notify(r.id, 'nearby_help', 'Yakınında yardım isteniyor', l.title, `/listings/${l.id}`, { listingId: l.id })));
  }

  private async ownOrThrow(user: User, id: string) {
    const l = await this.repo.findOne({ where: { id } });
    if (!l) throw Errors.notFound('İlan');
    if (l.userId !== user.id) throw Errors.forbidden();
    return l;
  }

  async update(user: User, id: string, dto: UpdateListingDto) {
    const l = await this.ownOrThrow(user, id);
    if (l.status === ListingStatus.REMOVED) throw new AppError('LISTING_REMOVED', 'Kaldırılan ilan düzenlenemez', 409);
    if (l.status === ListingStatus.CLOSED) throw new AppError('LISTING_CLOSED', 'Kapalı ilan düzenlenemez, önce yeniden yayınla', 409);
    this.validateCore(l.category, dto);
    for (const k of ['subtype', 'title', 'description', 'priceKurus', 'details', 'handover'] as const) if (dto[k] !== undefined) (l as unknown as Record<string, unknown>)[k] = typeof dto[k] === 'string' ? (dto[k] as string).trim() : dto[k];
    if (dto.neighborhoodId && dto.neighborhoodId !== l.neighborhoodId) {
      if ((await this.geo.distanceBetween(user.neighborhoodId!, dto.neighborhoodId)) > MAX_NEIGHBOR_DISTANCE_M) throw new AppError('LISTING_NEIGHBORHOOD_TOO_FAR', 'Bu mahalle çok uzak', 400);
      const n = await this.geo.get(dto.neighborhoodId);
      l.neighborhoodId = n.id;
      l.neighborhood = n;
      l.displayPoint = toPoint(displayPointFrom(fromPoint(n.centroid)));
    }
    if (dto.mediaIds) {
      await this.mediaRepo.delete({ listingId: l.id });
      l.media = await this.attachMedia(user, dto.mediaIds);
    }
    const wasDraft = l.status === ListingStatus.DRAFT;
    let warnings: string[] = [];
    if (!wasDraft || dto.publish) {
      const verdict = await this.publishChecks(user, l);
      if (verdict.action === 'review') l.status = ListingStatus.PENDING_REVIEW;
      else if (wasDraft) this.applyVerdict(l, verdict);
      l.moderationFlags = verdict.labels;
      warnings = listingContactWarnings(`${l.title} ${l.description}`);
    }
    const saved = await this.repo.save(l);
    if (saved.status === ListingStatus.PENDING_REVIEW && (wasDraft || l.moderationFlags.length)) await this.autoReport(saved, l.moderationFlags);
    if (wasDraft && saved.status === ListingStatus.ACTIVE) await this.fanOutHelp(saved);
    await this.audit.log(user.id, 'listing.update', 'listing', id);
    return { id: saved.id, status: saved.status, warnings };
  }

  async close(user: User, id: string, dto: CloseListingDto) {
    const l = await this.ownOrThrow(user, id);
    if (!ACTIVE_LIKE.includes(l.status)) throw new AppError('LISTING_NOT_ACTIVE', 'İlan aktif değil', 409);
    let toUser: string | null = null;
    if (dto.reason === 'delivered' && dto.deliveredToUserId) {
      const conv = await this.convs.findOne({ where: { listingId: id, buyerId: dto.deliveredToUserId } });
      if (!conv) throw new AppError('LISTING_RECIPIENT_INVALID', 'Bu kişiyle ilan üzerinden mesajlaşmadın', 400);
      toUser = dto.deliveredToUserId;
    }
    await this.repo.update(id, {
      status: ListingStatus.CLOSED, closeReason: dto.reason === 'delivered' ? CloseReason.DELIVERED : CloseReason.CANCELLED,
      closedAt: new Date(), deliveredToUserId: toUser,
    });
    if (toUser) {
      // İhtiyacı olan tarafa ulaşan kişi "yardım etti" sayılır.
      const helper = l.category === ListingCategory.YARDIM && l.subtype === 'istiyorum' ? toUser : user.id;
      await this.users.increment({ id: helper }, 'helpedCount', 1);
      for (const [who, other] of [[user.id, toUser], [toUser, user.id]]) {
        await this.notify.notify(who, 'review_request', 'Deneyimini değerlendir', `"${l.title}" tamamlandı. Kısa bir değerlendirme komşularına yol gösterir.`, `/listings/${id}/review`, { listingId: id, toUserId: other });
      }
    }
    const convs = await this.convs.find({ where: { listingId: id } });
    for (const c of convs) {
      const text = dto.reason === 'delivered' ? (c.buyerId === toUser ? 'İlan seninle tamamlandı olarak kapatıldı.' : 'İlan sahibi bu ilanı kapattı.') : 'İlan sahibi bu ilanı kapattı.';
      const m = await this.messages.save(this.messages.create({ conversationId: c.id, senderId: null, kind: 'system', body: text }));
      for (const uid of [c.buyerId, c.sellerId]) {
        this.rt.toUser(uid, 'message:new', { conversationId: c.id, message: m });
        this.rt.toUser(uid, 'listing:status', { listingId: id, status: ListingStatus.CLOSED });
      }
    }
    const favUsers = await this.favs.find({ where: { listingId: id } });
    for (const f of favUsers) if (f.userId !== toUser) await this.notify.notify(f.userId, 'favorite_closed', 'Favori ilanın kapandı', l.title, `/listings/${id}`, { listingId: id });
    await this.audit.log(user.id, 'listing.close', 'listing', id, { reason: dto.reason, toUser });
    return { id, status: ListingStatus.CLOSED };
  }

  async reopen(user: User, id: string) {
    const l = await this.ownOrThrow(user, id);
    if (l.status !== ListingStatus.CLOSED) throw new AppError('LISTING_NOT_CLOSED', 'Yalnızca kapalı ilan yeniden yayınlanabilir', 409);
    if (l.closeReason === CloseReason.DELIVERED) throw new AppError('LISTING_DELIVERED', 'Teslim edilen ilan yeniden açılamaz, yeni ilan oluştur', 409);
    l.status = ListingStatus.ACTIVE;
    await this.publishChecks(user, { ...l, id: '' } as Listing);
    await this.repo.update(id, { status: ListingStatus.ACTIVE, closeReason: null, closedAt: null, publishedAt: new Date(), expiresAt: new Date(Date.now() + LISTING_TTL_DAYS * 86_400_000) });
    return { id, status: ListingStatus.ACTIVE };
  }

  async extend(user: User, id: string) {
    const l = await this.ownOrThrow(user, id);
    if (l.status !== ListingStatus.ACTIVE) throw new AppError('LISTING_NOT_ACTIVE', 'İlan aktif değil', 409);
    const expiresAt = new Date(Date.now() + LISTING_TTL_DAYS * 86_400_000);
    await this.repo.update(id, { expiresAt });
    return { id, expiresAt };
  }

  async remove(user: User, id: string) {
    const l = await this.ownOrThrow(user, id);
    // Mesajlar ve raporlar delil olarak korunur; ilan kaldırılmış olarak işaretlenir. Taslaklar tamamen silinir.
    if (l.status === ListingStatus.DRAFT) await this.repo.delete(id);
    else await this.repo.update(id, { status: ListingStatus.CLOSED, closeReason: CloseReason.CANCELLED, closedAt: new Date() });
    await this.audit.log(user.id, 'listing.delete', 'listing', id);
    return { ok: true };
  }

  async draft(user: User) {
    const l = await this.repo.findOne({ where: { userId: user.id, status: ListingStatus.DRAFT } });
    return l ? { ...listingCard(l), description: l.description, details: l.details, handover: l.handover, media: l.media } : null;
  }

  /** Süresi dolan ilanları kapatır, 3 gün kalanlar için sahibine hatırlatma gönderir (zamanlanmış görev). */
  async sweep() {
    const expired = await this.ds.query(
      `UPDATE listings SET status='closed', "closeReason"='expired', "closedAt"=now() WHERE status='active' AND "expiresAt" <= now() RETURNING id`,
    );
    const soon: { id: string; userId: string; title: string }[] = await this.ds.query(
      `SELECT l.id, l."userId", l.title FROM listings l WHERE l.status='active' AND l."expiresAt" BETWEEN now() + interval '71 hours' AND now() + interval '72 hours'
         AND NOT EXISTS (SELECT 1 FROM notifications n WHERE n."userId"=l."userId" AND n.type='listing_expiring' AND n.data->>'listingId' = l.id::text)`,
    );
    for (const l of soon) await this.notify.notify(l.userId, 'listing_expiring', 'İlanın 3 gün içinde kapanacak', `"${l.title}" için süreyi uzatabilirsin.`, `/listings/${l.id}`, { listingId: l.id });
    return { expired: (expired[0] ?? []).length, reminded: soon.length };
  }

  // ---------- Favoriler ----------

  async favorite(user: User, id: string, on: boolean) {
    if (!on) {
      await this.favs.delete({ userId: user.id, listingId: id });
      return { isFavorite: false };
    }
    const l = await this.repo.findOne({ where: { id } });
    if (!l || l.status !== ListingStatus.ACTIVE) throw Errors.notFound('İlan');
    if (l.userId === user.id) throw new AppError('FAVORITE_OWN_LISTING', 'Kendi ilanını favoriye ekleyemezsin', 400);
    if ((await this.favs.count({ where: { userId: user.id } })) >= MAX_FAVORITES) throw new AppError('FAVORITE_LIMIT_REACHED', `En fazla ${MAX_FAVORITES} favori ekleyebilirsin`, 409);
    await this.favs.upsert({ userId: user.id, listingId: id }, ['userId', 'listingId']);
    return { isFavorite: true };
  }

  async favorites(user: User) {
    const rows = await this.favs.find({ where: { userId: user.id }, order: { createdAt: 'DESC' } });
    const list = rows.length ? await this.repo.find({ where: { id: In(rows.map((r) => r.listingId)) } }) : [];
    return {
      items: rows.map((r) => list.find((l) => l.id === r.listingId)).filter(Boolean).map((l) => ({ ...listingCard(l!, { isFavorite: true }), available: l!.status === ListingStatus.ACTIVE })),
    };
  }

  // ---------- Değerlendirme ----------

  async review(user: User, id: string, dto: ReviewDto) {
    const l = await this.repo.findOne({ where: { id } });
    if (!l || l.closeReason !== CloseReason.DELIVERED || !l.deliveredToUserId) throw new AppError('REVIEW_NOT_ALLOWED', 'Bu ilan için değerlendirme yapılamaz', 403);
    const parties = [l.userId, l.deliveredToUserId];
    if (!parties.includes(user.id)) throw new AppError('REVIEW_NOT_ALLOWED', 'Bu ilan için değerlendirme yapılamaz', 403);
    if (Date.now() - (l.closedAt?.getTime() ?? 0) > REVIEW_WINDOW_DAYS * 86_400_000) throw new AppError('REVIEW_WINDOW_CLOSED', 'Değerlendirme süresi doldu', 409);
    if (await this.reviews.exist({ where: { listingId: id, fromId: user.id } })) throw new AppError('REVIEW_DUPLICATE', 'Bu ilanı zaten değerlendirdin', 409);
    const toId = parties.find((p) => p !== user.id)!;
    await this.reviews.insert({ listingId: id, fromId: user.id, toId, rating: dto.rating, tags: dto.tags ?? [], comment: (dto.comment ?? '').trim() });
    const other = await this.reviews.findOne({ where: { listingId: id, fromId: toId } });
    // Kör değerlendirme: iki taraf da yazdığında ikisi birlikte yayınlanır.
    if (other) await this.reviews.update({ listingId: id, publishedAt: IsNull() }, { publishedAt: new Date() });
    return { ok: true, published: !!other };
  }

  async pendingReviews(user: User) {
    const rows = await this.ds.query(
      `SELECT l.id, l.title, l.category, CASE WHEN l."userId"=$1 THEN l."deliveredToUserId" ELSE l."userId" END AS "toUserId", l."closedAt"
         FROM listings l WHERE l."closeReason"='delivered' AND l."closedAt" > now() - interval '${REVIEW_WINDOW_DAYS} days'
          AND ($1 = l."userId" OR $1 = l."deliveredToUserId")
          AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r."listingId"=l.id AND r."fromId"=$1)
        ORDER BY l."closedAt" DESC`,
      [user.id],
    );
    const users = rows.length ? await this.users.find({ where: { id: In(rows.map((r: { toUserId: string }) => r.toUserId)) } }) : [];
    return { items: rows.map((r: Record<string, string>) => ({ listingId: r.id, title: r.title, category: r.category, closedAt: r.closedAt, to: userCard(users.find((u) => u.id === r.toUserId)) })) };
  }
}
