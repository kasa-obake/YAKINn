import { Module } from '@nestjs/common';
import { ContentRulesService } from './content-rules.service';
import { ListingsController } from './listings.controller';
import { ListingsScheduler } from './listings.scheduler';
import { ListingsService } from './listings.service';

@Module({ controllers: [ListingsController], providers: [ListingsService, ContentRulesService, ListingsScheduler], exports: [ListingsService, ContentRulesService] })
export class ListingsModule {}
