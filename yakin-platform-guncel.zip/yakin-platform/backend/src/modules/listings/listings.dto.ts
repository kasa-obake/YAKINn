import { Type } from 'class-transformer';
import { ArrayMaxSize, IsArray, IsBoolean, IsEnum, IsIn, IsInt, IsLatitude, IsLongitude, IsObject, IsOptional, IsString, IsUUID, Length, Max, MaxLength, Min, ValidateNested } from 'class-validator';
import { ListingCategory } from '../../database/entities';

export class LatLngDto {
  @Type(() => Number) @IsLatitude() lat: number;
  @Type(() => Number) @IsLongitude() lng: number;
}

export class ListingBaseDto {
  @IsOptional() @IsString() subtype?: string;
  @IsOptional() @IsString() @Length(5, 80) title?: string;
  @IsOptional() @IsString() @Length(10, 1000) description?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(100_000_000_00) priceKurus?: number | null;
  @IsOptional() @IsObject() details?: Record<string, unknown>;
  @IsOptional() @IsIn(['elden', 'kapida', 'ortak_nokta']) handover?: string;
  @IsOptional() @Type(() => Number) @IsInt() neighborhoodId?: number;
  /** Kayıp/bulunan ilanlarda işaretlenen yaklaşık yer. Saklanır ama hiçbir zaman döndürülmez. */
  @IsOptional() @ValidateNested() @Type(() => LatLngDto) point?: LatLngDto;
  @IsOptional() @IsArray() @ArrayMaxSize(8) @IsUUID('4', { each: true }) mediaIds?: string[];
}

export class CreateListingDto extends ListingBaseDto {
  @IsEnum(ListingCategory) category: ListingCategory;
  @IsString() declare subtype: string;
  /** false: taslak olarak kaydet. */
  @IsOptional() @IsBoolean() publish?: boolean;
}

export class UpdateListingDto extends ListingBaseDto {
  @IsOptional() @IsBoolean() publish?: boolean;
}

export class CloseListingDto {
  @IsIn(['delivered', 'cancelled']) reason: 'delivered' | 'cancelled';
  @IsOptional() @IsUUID() deliveredToUserId?: string;
}

export class FeedQueryDto {
  @IsOptional() @IsEnum(ListingCategory) category?: ListingCategory;
  @IsOptional() @IsString() subtype?: string;
  @IsOptional() @IsString() @MaxLength(80) q?: string;
  @IsOptional() @Type(() => Number) @IsIn([1, 3, 5, 10, 20]) radiusKm?: number;
  @IsOptional() @IsIn(['new', 'near']) sort?: 'new' | 'near';
  @IsOptional() @IsIn(['true', 'false', '1', '0']) freeOnly?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) minPrice?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) maxPrice?: number;
  @IsOptional() @IsIn(['24h', '7d', '30d']) since?: '24h' | '7d' | '30d';
  @IsOptional() @Type(() => Number) @IsInt() neighborhoodId?: number;
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) limit?: number;
}

export class MapQueryDto {
  /** minLng,minLat,maxLng,maxLat */
  @IsString() bbox: string;
  @IsOptional() @IsEnum(ListingCategory) category?: ListingCategory;
}

export class ReviewDto {
  @Type(() => Number) @IsInt() @Min(1) @Max(5) rating: number;
  @IsOptional() @IsArray() @ArrayMaxSize(5) @IsIn(['dakik', 'nazik', 'aciklamaya_uygun', 'iletisim_kolay', 'guvenilir'], { each: true }) tags?: string[];
  @IsOptional() @IsString() @MaxLength(300) comment?: string;
}

export class MyListingsQueryDto {
  @IsOptional() @IsIn(['active', 'pending_review', 'closed', 'draft', 'removed']) status?: string;
}
