import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ModerationRule } from '../../database/entities';

const fold = (s: string) => s.toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ı/g, 'i');

/** Yasaklı/şüpheli içerik kuralları (yönetim panelinden yönetilir, 30 sn önbellek). */
@Injectable()
export class ContentRulesService {
  private cache: { at: number; rules: ModerationRule[] } | null = null;
  constructor(@InjectRepository(ModerationRule) private repo: Repository<ModerationRule>) {}

  invalidate() {
    this.cache = null;
  }
  private async rules() {
    if (!this.cache || Date.now() - this.cache.at > 30_000) this.cache = { at: Date.now(), rules: await this.repo.find({ where: { active: true } }) };
    return this.cache.rules;
  }

  /** En ağır eşleşen eylemi döner: block > review > warn. */
  async check(text: string): Promise<{ action: 'block' | 'review' | 'warn' | null; labels: string[] }> {
    const t = fold(text);
    const hits = (await this.rules()).filter((r) => {
      const p = fold(r.pattern);
      if (r.matchType === 'exact') return new RegExp(`(^|[^\\p{L}\\d])${p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^\\p{L}\\d]|$)`, 'u').test(t);
      if (r.matchType === 'regex') {
        try { return new RegExp(r.pattern, 'iu').test(text); } catch { return false; }
      }
      return t.includes(p);
    });
    const order = ['block', 'review', 'warn'] as const;
    const action = order.find((a) => hits.some((h) => h.action === a)) ?? null;
    return { action, labels: [...new Set(hits.map((h) => h.label || h.pattern))] };
  }
}
