import { Injectable, Logger, OnApplicationBootstrap, OnApplicationShutdown } from '@nestjs/common';
import { ListingsService } from './listings.service';

/** Basit zamanlayıcı. Birden fazla sunucu örneğinde yalnızca birinde JOBS_ENABLED=true olmalıdır. */
@Injectable()
export class ListingsScheduler implements OnApplicationBootstrap, OnApplicationShutdown {
  private timer?: NodeJS.Timeout;
  private log = new Logger('Zamanlayıcı');
  constructor(private svc: ListingsService) {}
  onApplicationBootstrap() {
    if (process.env.JOBS_ENABLED === 'false' || process.env.NODE_ENV === 'test') return;
    this.timer = setInterval(() => this.run(), 60 * 60_000);
    setTimeout(() => this.run(), 5_000).unref();
  }
  async run() {
    try {
      const r = await this.svc.sweep();
      if (r.expired || r.reminded) this.log.log(`Süresi dolan: ${r.expired}, hatırlatma: ${r.reminded}`);
    } catch (e) {
      this.log.error(e);
    }
  }
  onApplicationShutdown() {
    if (this.timer) clearInterval(this.timer);
  }
}
