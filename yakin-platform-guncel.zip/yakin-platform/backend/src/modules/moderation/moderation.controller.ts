import { Body, Controller, Delete, Get, HttpCode, Param, ParseIntPipe, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AllowSuspended, CurrentUser, Roles } from '../../common/auth.guard';
import { User, UserRole } from '../../database/entities';
import { AppealDto, DecideListingDto, DecideReportDto, ReportsQueryDto, ResolveAppealDto, RuleDto, SupportReplyDto, UserActionDto, UsersQueryDto } from './moderation.dto';
import { ModerationService } from './moderation.service';

/** Kullanıcının kendisi hakkındaki kararlar ve itirazlar. Askıdaki kullanıcı da erişebilir. */
@ApiTags('moderation')
@Controller('me/decisions')
export class MyDecisionsController {
  constructor(private svc: ModerationService) {}
  @AllowSuspended() @Get() list(@CurrentUser() u: User) { return this.svc.myDecisions(u); }
  @AllowSuspended() @Post(':id/appeal') @HttpCode(201) appeal(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: AppealDto) { return this.svc.appeal(u, id, dto); }
}

@ApiTags('admin')
@Roles(UserRole.MODERATOR, UserRole.ADMIN)
@Controller('admin')
export class AdminController {
  constructor(private svc: ModerationService) {}

  @Get('stats') stats() { return this.svc.stats(); }
  @Get('reports') reports(@CurrentUser() u: User, @Query() q: ReportsQueryDto) { return this.svc.queue(q, u); }
  @Post('reports/next') @HttpCode(200) next(@CurrentUser() u: User) { return this.svc.claimNext(u); }
  @Get('reports/:id') report(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.caseDetail(id, u); }
  @Post('reports/:id/decide') @HttpCode(200) decide(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: DecideReportDto) { return this.svc.decideReport(u, id, dto); }
  @Get('listings/pending') pending() { return this.svc.pendingListings(); }
  @Post('listings/:id/decide') @HttpCode(200) decideListing(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: DecideListingDto) { return this.svc.decideListing(u, id, dto); }
  @Get('users') users(@Query() q: UsersQueryDto) { return this.svc.searchUsers(q.q); }
  @Get('users/:id') user(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) { return this.svc.userDetail(id, u); }
  @Post('users/:id/action') @HttpCode(200) userAction(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UserActionDto) { return this.svc.userAction(u, id, dto); }
  @Get('appeals') appeals() { return this.svc.listAppeals(); }
  @Post('appeals/:id/resolve') @HttpCode(200) resolve(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string, @Body() dto: ResolveAppealDto) { return this.svc.resolveAppeal(u, id, dto); }
  @Get('audit') audit(@CurrentUser() u: User, @Query('actorId') actorId?: string) { return this.svc.auditLog(u, actorId); }

  @Get('support') support(@Query('status') status?: string) { return this.svc.listSupport(status); }
  @Post('support/:id/reply') @HttpCode(200) supportReply(@CurrentUser() u: User, @Param('id', ParseIntPipe) id: number, @Body() dto: SupportReplyDto) { return this.svc.replySupport(u, id, dto); }

  @Roles(UserRole.ADMIN) @Get('rules') rules() { return this.svc.listRules(); }
  @Roles(UserRole.ADMIN) @Post('rules') createRule(@CurrentUser() u: User, @Body() dto: RuleDto) { return this.svc.createRule(u, dto); }
  @Roles(UserRole.ADMIN) @Patch('rules/:id') updateRule(@CurrentUser() u: User, @Param('id', ParseIntPipe) id: number, @Body() dto: RuleDto) { return this.svc.updateRule(u, id, dto); }
  @Roles(UserRole.ADMIN) @Delete('rules/:id') deleteRule(@CurrentUser() u: User, @Param('id', ParseIntPipe) id: number) { return this.svc.deleteRule(u, id); }
}
