import { Injectable } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, ILike, In, IsNull, Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { normalizePhone } from '../../common/format';
import { listingCard, userCard } from '../../common/presenters';
import {
  Appeal, AppealStatus, AuditLog, Conversation, DecisionAction, Listing, ListingStatus, Message, ModerationDecision,
  ModerationRule, Report, ReportStatus, ReportTarget, SupportTicket, User, UserRole, UserStatus,
} from '../../database/entities';
import { AuthService } from '../auth/auth.service';
import { AuditService } from '../core/audit.service';
import { NotificationsService } from '../core/notifications.service';
import { RealtimeGateway } from '../core/realtime.gateway';
import { ContentRulesService } from '../listings/content-rules.service';
import { AppealDto, DecideListingDto, DecideReportDto, ReportsQueryDto, ResolveAppealDto, RuleDto, SupportReplyDto, UserActionDto } from './moderation.dto';

const APPEAL_DAYS = 14;
const PRIORITY_ORDER = `CASE r.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 ELSE 2 END`;
const ACTION_TEXT: Record<string, string> = {
  remove_content: 'İçeriğin topluluk kurallarına aykırı bulunduğu için kaldırıldı.',
  warn: 'Hesabına bir uyarı verildi.',
  suspend: 'Hesabın geçici olarak askıya alındı.',
  ban: 'Hesabın kalıcı olarak kapatıldı.',
  reject_listing: 'İlanın yayına alınmadı.',
};

@Injectable()
export class ModerationService {
  constructor(
    @InjectDataSource() private ds: DataSource,
    @InjectRepository(Report) private reports: Repository<Report>,
    @InjectRepository(ModerationDecision) private decisions: Repository<ModerationDecision>,
    @InjectRepository(Appeal) private appeals: Repository<Appeal>,
    @InjectRepository(Listing) private listings: Repository<Listing>,
    @InjectRepository(Message) private messages: Repository<Message>,
    @InjectRepository(Conversation) private convs: Repository<Conversation>,
    @InjectRepository(User) private users: Repository<User>,
    @InjectRepository(ModerationRule) private rulesRepo: Repository<ModerationRule>,
    @InjectRepository(AuditLog) private auditRepo: Repository<AuditLog>,
    @InjectRepository(SupportTicket) private tickets: Repository<SupportTicket>,
    private audit: AuditService,
    private notify: NotificationsService,
    private rules: ContentRulesService,
    private auth: AuthService,
    private rt: RealtimeGateway,
  ) {}

  // ---------- Kuyruk ----------

  async queue(q: ReportsQueryDto, mod: User) {
    const qb = this.reports.createQueryBuilder('r')
      .where(q.status ? 'r.status = :s' : `r.status IN ('open','in_review')`, { s: q.status })
      .orderBy(PRIORITY_ORDER, 'ASC').addOrderBy('r."slaDueAt"', 'ASC').take(100);
    if (q.priority) qb.andWhere('r.priority = :p', { p: q.priority });
    if (q.mine) qb.andWhere('r."assignedTo" = :m', { m: mod.id });
    const rows = await qb.getMany();
    const now = Date.now();
    return { items: rows.map((r) => ({ ...r, slaBreached: r.slaDueAt.getTime() < now && [ReportStatus.OPEN, ReportStatus.IN_REVIEW].includes(r.status) })) };
  }

  /** Sıradaki en öncelikli, atanmamış vakayı moderatöre atar. */
  async claimNext(mod: User) {
    const [r] = await this.ds.query(
      `UPDATE reports SET "assignedTo"=$1, status='in_review' WHERE id = (
         SELECT id FROM reports r WHERE status='open' AND "assignedTo" IS NULL ORDER BY ${PRIORITY_ORDER}, "slaDueAt" LIMIT 1 FOR UPDATE SKIP LOCKED)
       RETURNING id`,
      [mod.id],
    );
    const id = r?.[0]?.id ?? r?.id;
    if (!id) return { id: null };
    await this.audit.log(mod.id, 'report.claim', 'report', id);
    return this.caseDetail(id, mod);
  }

  async caseDetail(id: string, mod: User) {
    const r = await this.reports.findOne({ where: { id } });
    if (!r) throw Errors.notFound('Şikâyet');
    let target: Record<string, unknown> = {};
    if (r.targetType === ReportTarget.LISTING) {
      const l = await this.listings.findOne({ where: { id: r.targetId } });
      if (l) target = { listing: { ...listingCard(l), description: l.description, details: l.details, media: l.media, moderationFlags: l.moderationFlags, status: l.status } };
    } else if (r.targetType === ReportTarget.MESSAGE) {
      const m = await this.messages.findOne({ where: { id: r.targetId } });
      if (m) {
        // JS Date milisaniye, PostgreSQL mikrosaniye tutar; hedef mesaj id ile dışlanır.
        // Bağlam: önceki ve sonraki 5 mesaj. Moderatör dışında kimse silinen mesaj içeriğini görmez.
        const ctx = await this.ds.query(
          `(SELECT * FROM messages WHERE "conversationId"=$1 AND id<>$3 AND "createdAt" <= $2 ORDER BY "createdAt" DESC LIMIT 5)
           UNION ALL (SELECT * FROM messages WHERE id=$3)
           UNION ALL (SELECT * FROM messages WHERE "conversationId"=$1 AND id<>$3 AND "createdAt" > $2 ORDER BY "createdAt" ASC LIMIT 5)`,
          [m.conversationId, m.createdAt, m.id],
        );
        ctx.sort((a: Message, b: Message) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        target = { message: m, context: ctx };
      }
    }
    const owner = r.targetOwnerId ? await this.users.findOne({ where: { id: r.targetOwnerId } }) : null;
    const reporter = r.reporterId ? await this.users.findOne({ where: { id: r.reporterId } }) : null;
    const [history, otherReports] = await Promise.all([
      r.targetOwnerId ? this.decisions.find({ where: { affectedUserId: r.targetOwnerId }, order: { createdAt: 'DESC' }, take: 10 }) : [],
      this.reports.find({ where: { targetType: r.targetType, targetId: r.targetId }, order: { createdAt: 'DESC' } }),
    ]);
    await this.audit.log(mod.id, 'report.view', 'report', id);
    return {
      report: r, target,
      owner: owner ? { ...userCard(owner), status: owner.status, createdAt: owner.createdAt, phone: mod.role === UserRole.ADMIN ? owner.phone : undefined } : null,
      reporter: reporter ? userCard(reporter) : null,
      ownerHistory: history,
      relatedReports: otherReports.map((x) => ({ id: x.id, reason: x.reason, status: x.status, createdAt: x.createdAt })),
    };
  }

  // ---------- Kararlar ----------

  private async record(mod: User | null, d: Partial<ModerationDecision>) {
    const dec = await this.decisions.save(this.decisions.create({ ...d, moderatorId: mod?.id ?? null, appealDeadline: new Date(Date.now() + APPEAL_DAYS * 86_400_000) }));
    await this.audit.log(mod?.id ?? null, `decision.${d.action}`, d.targetType, d.targetId, { decisionId: dec.id, rule: d.rule, suspendDays: d.suspendDays });
    if (d.affectedUserId && d.action !== DecisionAction.NO_VIOLATION && d.action !== DecisionAction.APPROVE_LISTING) {
      const text = [ACTION_TEXT[d.action!] ?? 'Hesabınla ilgili bir karar verildi.', d.reason].filter(Boolean).join(' ');
      await this.notify.notify(d.affectedUserId, 'moderation', 'Moderasyon kararı', text, `/decisions/${dec.id}`, { decisionId: dec.id });
    }
    return dec;
  }

  private async suspend(userId: string, days: number | null) {
    await this.users.update(userId, { status: UserStatus.SUSPENDED, suspendedUntil: days ? new Date(Date.now() + days * 86_400_000) : null });
    this.rt.disconnectUser(userId);
    if (!days) {
      await this.listings.update({ userId, status: In([ListingStatus.ACTIVE, ListingStatus.PENDING_REVIEW]) }, { status: ListingStatus.REMOVED });
      await this.auth.revokeAll(userId);
    }
  }

  async decideReport(mod: User, id: string, dto: DecideReportDto) {
    const r = await this.reports.findOne({ where: { id } });
    if (!r) throw Errors.notFound('Şikâyet');
    if ([ReportStatus.RESOLVED, ReportStatus.DISMISSED].includes(r.status)) throw new AppError('REPORT_ALREADY_DECIDED', 'Bu vaka kapatılmış', 409);
    if (dto.action === DecisionAction.BAN && mod.role !== UserRole.ADMIN) throw new AppError('FORBIDDEN', 'Kalıcı kapatma yalnızca yönetici yetkisindedir', 403);
    if (dto.action === DecisionAction.SUSPEND && !dto.suspendDays) throw new AppError('VALIDATION_ERROR', 'Askı süresi gerekli', 400, { fields: { suspendDays: 'required' } });
    if (r.targetOwnerId === mod.id) throw new AppError('FORBIDDEN', 'Kendinle ilgili vakaya karar veremezsin', 403);

    if (dto.action === DecisionAction.NO_VIOLATION) {
      if (r.targetType === ReportTarget.LISTING) {
        const others = await this.reports.count({ where: { targetType: r.targetType, targetId: r.targetId, status: In([ReportStatus.OPEN, ReportStatus.IN_REVIEW]) } });
        if (others <= 1) {
          await this.listings.update({ id: r.targetId, status: ListingStatus.PENDING_REVIEW, publishedAt: IsNull() }, { publishedAt: new Date() });
          await this.listings.update({ id: r.targetId, status: ListingStatus.PENDING_REVIEW }, { status: ListingStatus.ACTIVE, moderationFlags: [] });
        }
      }
    } else {
      if (dto.action === DecisionAction.REMOVE_CONTENT || dto.action === DecisionAction.SUSPEND || dto.action === DecisionAction.BAN) {
        if (r.targetType === ReportTarget.LISTING) await this.listings.update(r.targetId, { status: ListingStatus.REMOVED });
        if (r.targetType === ReportTarget.MESSAGE) await this.messages.update(r.targetId, { deletedAt: new Date() });
      }
      if (r.targetOwnerId && dto.action === DecisionAction.SUSPEND) await this.suspend(r.targetOwnerId, dto.suspendDays!);
      if (r.targetOwnerId && dto.action === DecisionAction.BAN) await this.suspend(r.targetOwnerId, null);
    }
    const dec = await this.record(mod, {
      reportId: r.id, targetType: r.targetType, targetId: r.targetId, affectedUserId: r.targetOwnerId, action: dto.action,
      rule: dto.rule ?? '', reason: dto.reason ?? '', internalNote: dto.internalNote ?? '', suspendDays: dto.suspendDays ?? null,
    });
    // Aynı hedefe ait açık tüm şikâyetler bu kararla kapanır.
    const status = dto.action === DecisionAction.NO_VIOLATION ? ReportStatus.DISMISSED : ReportStatus.RESOLVED;
    await this.reports.update({ targetType: r.targetType, targetId: r.targetId, status: In([ReportStatus.OPEN, ReportStatus.IN_REVIEW]) }, { status });
    if (r.reporterId) await this.notify.notify(r.reporterId, 'system', 'Bildirimin incelendi', 'Gönderdiğin şikâyet incelendi ve gerekli işlem yapıldı. Teşekkürler.', '/me/reports', { reportId: r.id });
    return { decisionId: dec.id, status };
  }

  pendingListings() {
    return this.listings.find({ where: { status: ListingStatus.PENDING_REVIEW }, order: { createdAt: 'ASC' }, take: 100, relations: { user: true } })
      .then((ls) => ({ items: ls.map((l) => ({ ...listingCard(l), description: l.description, moderationFlags: l.moderationFlags, owner: userCard(l.user) })) }));
  }

  async decideListing(mod: User, id: string, dto: DecideListingDto) {
    const l = await this.listings.findOne({ where: { id } });
    if (!l || l.status !== ListingStatus.PENDING_REVIEW) throw new AppError('LISTING_NOT_PENDING', 'İlan incelemede değil', 409);
    if (dto.action === 'approve') {
      await this.listings.update(id, { status: ListingStatus.ACTIVE, publishedAt: l.publishedAt ?? new Date(), moderationFlags: [] });
    } else {
      await this.listings.update(id, { status: ListingStatus.REMOVED });
    }
    const dec = await this.record(mod, {
      targetType: ReportTarget.LISTING, targetId: id, affectedUserId: l.userId,
      action: dto.action === 'approve' ? DecisionAction.APPROVE_LISTING : DecisionAction.REJECT_LISTING, rule: dto.rule ?? '', reason: dto.reason ?? '',
    });
    await this.reports.update({ targetType: ReportTarget.LISTING, targetId: id, status: In([ReportStatus.OPEN, ReportStatus.IN_REVIEW]) }, { status: dto.action === 'approve' ? ReportStatus.DISMISSED : ReportStatus.RESOLVED });
    if (dto.action === 'approve') await this.notify.notify(l.userId, 'moderation', 'İlanın yayında', `"${l.title}" incelendi ve yayına alındı.`, `/listings/${id}`, { decisionId: dec.id });
    return { decisionId: dec.id };
  }

  // ---------- Kullanıcılar ----------

  async searchUsers(q = '') {
    const phone = normalizePhone(q);
    const where = phone ? [{ phone }] : q ? [{ firstName: ILike(`%${q}%`) }, { lastName: ILike(`%${q}%`) }] : {};
    const list = await this.users.find({ where, order: { createdAt: 'DESC' }, take: 50 });
    return { items: list.map((u) => ({ ...userCard(u), status: u.status, role: u.role, suspendedUntil: u.suspendedUntil })) };
  }

  async userDetail(id: string, mod: User) {
    const u = await this.users.findOne({ where: { id } });
    if (!u) throw Errors.notFound('Kullanıcı');
    const [listings, reports, decisions] = await Promise.all([
      this.listings.find({ where: { userId: id }, order: { createdAt: 'DESC' }, take: 30 }),
      this.reports.find({ where: { targetOwnerId: id }, order: { createdAt: 'DESC' }, take: 30 }),
      this.decisions.find({ where: { affectedUserId: id }, order: { createdAt: 'DESC' } }),
    ]);
    await this.audit.log(mod.id, 'user.view', 'user', id);
    return {
      user: { ...userCard(u), status: u.status, role: u.role, suspendedUntil: u.suspendedUntil, createdAt: u.createdAt, phone: mod.role === UserRole.ADMIN ? u.phone : undefined },
      listings: listings.map((l) => listingCard(l)), reports, decisions,
    };
  }

  async userAction(mod: User, id: string, dto: UserActionDto) {
    const u = await this.users.findOne({ where: { id } });
    if (!u) throw Errors.notFound('Kullanıcı');
    if (u.id === mod.id) throw new AppError('FORBIDDEN', 'Kendi hesabına işlem yapamazsın', 403);
    if ((dto.action === 'ban' || dto.action === 'set_role') && mod.role !== UserRole.ADMIN) throw Errors.forbidden();
    if (u.role === UserRole.ADMIN && mod.role !== UserRole.ADMIN) throw Errors.forbidden();
    const base = { targetType: ReportTarget.USER, targetId: id, affectedUserId: id, reason: dto.reason ?? '' };
    switch (dto.action) {
      case 'warn': await this.record(mod, { ...base, action: DecisionAction.WARN }); break;
      case 'suspend':
        if (!dto.suspendDays) throw new AppError('VALIDATION_ERROR', 'Askı süresi gerekli', 400, { fields: { suspendDays: 'required' } });
        await this.suspend(id, dto.suspendDays);
        await this.record(mod, { ...base, action: DecisionAction.SUSPEND, suspendDays: dto.suspendDays });
        break;
      case 'ban': await this.suspend(id, null); await this.record(mod, { ...base, action: DecisionAction.BAN }); break;
      case 'unsuspend':
        await this.users.update(id, { status: UserStatus.ACTIVE, suspendedUntil: null });
        await this.audit.log(mod.id, 'user.unsuspend', 'user', id);
        break;
      case 'set_role':
        if (!dto.role) throw new AppError('VALIDATION_ERROR', 'Rol gerekli', 400);
        await this.users.update(id, { role: dto.role as UserRole });
        await this.audit.log(mod.id, 'user.set_role', 'user', id, { role: dto.role });
        break;
    }
    const after = await this.users.findOneOrFail({ where: { id } });
    return { id, status: after.status, role: after.role, suspendedUntil: after.suspendedUntil };
  }

  // ---------- İtirazlar ----------

  async myDecisions(me: User) {
    const list = await this.decisions.find({ where: { affectedUserId: me.id }, order: { createdAt: 'DESC' }, take: 50 });
    const appeals = list.length ? await this.appeals.find({ where: { decisionId: In(list.map((d) => d.id)) } }) : [];
    return {
      items: list
        .filter((d) => d.action !== DecisionAction.NO_VIOLATION)
        .map(({ internalNote: _n, moderatorId: _m, ...d }) => ({ ...d, appeal: appeals.find((a) => a.decisionId === d.id) ?? null, canAppeal: !appeals.some((a) => a.decisionId === d.id) && d.appealDeadline > new Date() && d.action !== DecisionAction.APPROVE_LISTING })),
    };
  }

  async appeal(me: User, decisionId: string, dto: AppealDto) {
    const d = await this.decisions.findOne({ where: { id: decisionId, affectedUserId: me.id } });
    if (!d) throw Errors.notFound('Karar');
    if (d.appealDeadline < new Date()) throw new AppError('APPEAL_WINDOW_CLOSED', 'İtiraz süresi doldu', 409);
    if (await this.appeals.exist({ where: { decisionId } })) throw new AppError('APPEAL_DUPLICATE', 'Bu karara zaten itiraz ettin', 409);
    const a = await this.appeals.save(this.appeals.create({ decisionId, userId: me.id, note: dto.note.trim() }));
    await this.audit.log(me.id, 'appeal.create', 'decision', decisionId);
    return { id: a.id, status: a.status };
  }

  async listAppeals() {
    const list = await this.appeals.find({ where: { status: AppealStatus.PENDING }, order: { createdAt: 'ASC' } });
    const decs = list.length ? await this.decisions.find({ where: { id: In(list.map((a) => a.decisionId)) } }) : [];
    return { items: list.map((a) => ({ ...a, decision: decs.find((d) => d.id === a.decisionId) })) };
  }

  async resolveAppeal(mod: User, id: string, dto: ResolveAppealDto) {
    const a = await this.appeals.findOne({ where: { id } });
    if (!a || a.status !== AppealStatus.PENDING) throw Errors.notFound('İtiraz');
    const d = await this.decisions.findOneOrFail({ where: { id: a.decisionId } });
    // İtiraz, kararı veren moderatör dışında biri tarafından değerlendirilir.
    if (d.moderatorId === mod.id) throw new AppError('APPEAL_SAME_MODERATOR', 'Kendi kararına yapılan itirazı değerlendiremezsin', 403);
    if (dto.accept) {
      if (d.targetType === ReportTarget.LISTING && [DecisionAction.REMOVE_CONTENT, DecisionAction.REJECT_LISTING].includes(d.action)) {
        await this.listings.update(d.targetId, { status: ListingStatus.ACTIVE, publishedAt: new Date() });
      }
      if (d.targetType === ReportTarget.MESSAGE && d.action === DecisionAction.REMOVE_CONTENT) await this.messages.update(d.targetId, { deletedAt: null });
      if (d.affectedUserId && [DecisionAction.SUSPEND, DecisionAction.BAN].includes(d.action)) await this.users.update(d.affectedUserId, { status: UserStatus.ACTIVE, suspendedUntil: null });
    }
    await this.appeals.update(id, { status: dto.accept ? AppealStatus.ACCEPTED : AppealStatus.REJECTED, resolvedBy: mod.id, resolution: dto.resolution, resolvedAt: new Date() });
    await this.audit.log(mod.id, dto.accept ? 'appeal.accept' : 'appeal.reject', 'appeal', id, { decisionId: d.id });
    await this.notify.notify(a.userId, 'moderation', 'İtirazın sonuçlandı', dto.accept ? `İtirazın kabul edildi. ${dto.resolution}` : `İtirazın reddedildi. ${dto.resolution}`, `/decisions/${d.id}`, { decisionId: d.id });
    return { id, status: dto.accept ? AppealStatus.ACCEPTED : AppealStatus.REJECTED };
  }

  // ---------- Kurallar, kayıtlar, metrikler ----------

  listRules() { return this.rulesRepo.find({ order: { id: 'ASC' } }); }
  async createRule(mod: User, dto: RuleDto) {
    if (dto.matchType === 'regex') { try { new RegExp(dto.pattern); } catch { throw new AppError('VALIDATION_ERROR', 'Düzenli ifade geçersiz', 400); } }
    dto.pattern = dto.matchType === 'regex' ? dto.pattern.trim() : dto.pattern.trim().toLocaleLowerCase('tr-TR');
    if (await this.rulesRepo.findOne({ where: { pattern: dto.pattern, matchType: dto.matchType } })) throw new AppError('RULE_EXISTS', 'Bu kural zaten var', 409);
    const r = await this.rulesRepo.save(this.rulesRepo.create(dto));
    this.rules.invalidate();
    await this.audit.log(mod.id, 'rule.create', 'rule', String(r.id), { ...dto });
    return r;
  }
  async updateRule(mod: User, id: number, dto: Partial<RuleDto>) {
    await this.rulesRepo.update(id, dto);
    this.rules.invalidate();
    await this.audit.log(mod.id, 'rule.update', 'rule', String(id), { ...dto });
    return this.rulesRepo.findOneByOrFail({ id });
  }
  async deleteRule(mod: User, id: number) {
    await this.rulesRepo.delete(id);
    this.rules.invalidate();
    await this.audit.log(mod.id, 'rule.delete', 'rule', String(id));
    return { ok: true };
  }

  auditLog(mod: User, actorId?: string) {
    const where = mod.role === UserRole.ADMIN ? (actorId ? { actorId } : {}) : { actorId: mod.id };
    return this.auditRepo.find({ where, order: { createdAt: 'DESC' }, take: 200 });
  }

  /** Ana metrik ve sağlık göstergeleri. */
  async stats() {
    const q = (sql: string, p: unknown[] = []) => this.ds.query(sql, p).then((r) => r[0]);
    const window = (from: string, to: string) => q(
      `SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY EXTRACT(EPOCH FROM ("firstReplyAt"-"publishedAt"))) / 3600 AS "medianHours",
              COUNT(*)::int AS published,
              COUNT(*) FILTER (WHERE "firstReplyAt" IS NOT NULL)::int AS replied,
              COUNT(*) FILTER (WHERE "firstReplyAt" - "publishedAt" <= interval '24 hours')::int AS "replied24h"
         FROM listings WHERE "publishedAt" > now() - interval '${from}' AND "publishedAt" <= now() - interval '${to}'`,
    );
    const [cur, prev, users, reports, pending, appeals] = await Promise.all([
      window('7 days', '0 days'), window('14 days', '7 days'),
      q(`SELECT COUNT(*)::int AS total,
                (SELECT COUNT(DISTINCT x)::int FROM (SELECT "userId" AS x FROM listings WHERE "createdAt" > now()-interval '7 days'
                   UNION SELECT "senderId" FROM messages WHERE "createdAt" > now()-interval '7 days' AND "senderId" IS NOT NULL) t) AS "active7d",
                COUNT(*) FILTER (WHERE "createdAt" > now()-interval '7 days')::int AS "new7d"
           FROM users WHERE status <> 'deleted'`),
      q(`SELECT COUNT(*) FILTER (WHERE status IN ('open','in_review'))::int AS open,
                COUNT(*) FILTER (WHERE status IN ('open','in_review') AND priority='critical')::int AS critical,
                COUNT(*) FILTER (WHERE status IN ('open','in_review') AND "slaDueAt" < now())::int AS "slaBreached"
           FROM reports`),
      q(`SELECT COUNT(*)::int AS n FROM listings WHERE status='pending_review'`),
      q(`SELECT COUNT(*)::int AS n FROM appeals WHERE status='pending'`),
    ]);
    const fmt = (w: { medianHours: number | null; published: number; replied: number; replied24h: number }) => ({
      medianFirstReplyHours: w.medianHours == null ? null : Math.round(Number(w.medianHours) * 10) / 10,
      published: w.published, replied: w.replied, replyRate24h: w.published ? Math.round((w.replied24h / w.published) * 100) : null,
    });
    const supportOpen = await this.tickets.count({ where: { status: 'open' } });
    return { last7d: fmt(cur), prev7d: fmt(prev), users, reports, pendingListings: pending.n, pendingAppeals: appeals.n, supportOpen };
  }

  // ---------- Destek talepleri ----------

  private ticketNo = (id: number) => `YK-${String(id).padStart(6, '0')}`;

  /** Açık talepler önce, en eski üstte. status verilirse yalnızca o durum. */
  async listSupport(status?: string) {
    const where = status && ['open', 'answered', 'closed'].includes(status) ? { status } : {};
    const rows = await this.tickets.find({ where, order: { createdAt: status ? 'DESC' : 'ASC' }, take: 100 });
    const ids = [...new Set(rows.map((t) => t.userId))];
    const users = ids.length ? await this.users.find({ where: { id: In(ids) } }) : [];
    const items = rows
      .filter((t) => status || t.status !== 'closed')
      .map((t) => ({
        id: t.id, ticketNo: this.ticketNo(t.id), subject: t.subject, body: t.body, status: t.status, createdAt: t.createdAt,
        reply: t.reply, repliedAt: t.repliedAt, user: userCard(users.find((u) => u.id === t.userId)),
      }));
    return { items };
  }

  async replySupport(mod: User, id: number, dto: SupportReplyDto) {
    const t = await this.tickets.findOne({ where: { id } });
    if (!t) throw Errors.notFound('Destek talebi');
    const status = dto.status ?? 'answered';
    await this.tickets.update(id, { reply: dto.reply.trim(), repliedBy: mod.id, repliedAt: new Date(), status });
    await this.audit.log(mod.id, 'support.reply', 'support_ticket', String(id), { status });
    await this.notify.notify(t.userId, 'system', `Destek talebine yanıt (${this.ticketNo(id)})`, dto.reply.trim().slice(0, 300), '/settings', { ticketId: id });
    return { id, ticketNo: this.ticketNo(id), status };
  }
}
