import { Type } from 'class-transformer';
import { IsBoolean, IsEnum, IsIn, IsInt, IsOptional, IsString, Length, Max, MaxLength, Min } from 'class-validator';
import { DecisionAction, ReportPriority, ReportStatus } from '../../database/entities';

export class DecideReportDto {
  @IsIn([DecisionAction.NO_VIOLATION, DecisionAction.REMOVE_CONTENT, DecisionAction.WARN, DecisionAction.SUSPEND, DecisionAction.BAN]) action: DecisionAction;
  @IsOptional() @IsString() @MaxLength(80) rule?: string;
  /** Kullanıcıya gösterilecek açıklama. */
  @IsOptional() @IsString() @MaxLength(500) reason?: string;
  @IsOptional() @IsString() @MaxLength(1000) internalNote?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(30) suspendDays?: number;
}
export class DecideListingDto {
  @IsIn(['approve', 'reject']) action: 'approve' | 'reject';
  @IsOptional() @IsString() @MaxLength(80) rule?: string;
  @IsOptional() @IsString() @MaxLength(500) reason?: string;
}
export class UserActionDto {
  @IsIn(['warn', 'suspend', 'unsuspend', 'ban', 'set_role']) action: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(30) suspendDays?: number;
  @IsOptional() @IsIn(['user', 'moderator', 'admin']) role?: string;
  @IsOptional() @IsString() @MaxLength(500) reason?: string;
}
export class AppealDto {
  @IsString() @Length(10, 1000) note: string;
}
export class ResolveAppealDto {
  @IsBoolean() accept: boolean;
  @IsString() @Length(3, 1000) resolution: string;
}
export class RuleDto {
  @IsString() @Length(2, 200) pattern: string;
  @IsOptional() @IsIn(['exact', 'contains', 'regex']) matchType?: 'exact' | 'contains' | 'regex';
  @IsOptional() @IsIn(['block', 'review', 'warn']) action?: 'block' | 'review' | 'warn';
  @IsOptional() @IsString() @MaxLength(80) label?: string;
  @IsOptional() @IsBoolean() active?: boolean;
}
export class ReportsQueryDto {
  @IsOptional() @IsEnum(ReportStatus) status?: ReportStatus;
  @IsOptional() @IsEnum(ReportPriority) priority?: ReportPriority;
  @IsOptional() @IsIn(['true']) mine?: string;
}
export class UsersQueryDto {
  @IsOptional() @IsString() @MaxLength(60) q?: string;
}

export class SupportReplyDto {
  /** Kullanıcıya bildirim olarak gider. */
  @IsString() @Length(1, 2000) reply: string;
  @IsOptional() @IsIn(['open', 'answered', 'closed']) status?: 'open' | 'answered' | 'closed';
}
