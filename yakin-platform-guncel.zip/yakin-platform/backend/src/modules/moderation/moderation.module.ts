import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { ListingsModule } from '../listings/listings.module';
import { AdminController, MyDecisionsController } from './moderation.controller';
import { ModerationService } from './moderation.service';

@Module({ imports: [AuthModule, ListingsModule], controllers: [MyDecisionsController, AdminController], providers: [ModerationService] })
export class ModerationModule {}
