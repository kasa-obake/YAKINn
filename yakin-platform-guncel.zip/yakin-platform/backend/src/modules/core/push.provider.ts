import { Injectable, Logger } from '@nestjs/common';

export type PushMessage = { title: string; body: string; data?: Record<string, string> };

/**
 * Anlık bildirim sağlayıcısı. Geliştirmede bildirimleri loga yazar.
 * Üretimde FCM HTTP v1 bağdaştırıcısı bu arayüzü uygular (bkz. README "Anlık bildirimler").
 */
@Injectable()
export class PushProvider {
  private log = new Logger('Push');
  async send(tokens: string[], msg: PushMessage) {
    if (!tokens.length) return;
    this.log.log(`[${tokens.length} cihaz] ${msg.title} - ${msg.body}`);
  }
}
