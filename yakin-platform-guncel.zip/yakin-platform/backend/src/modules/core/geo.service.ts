import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { Neighborhood } from '../../database/entities';

/** Hizmet bölgesi kenarından en fazla bu kadar uzaktaki konumlar kabul edilir. */
const REGION_MARGIN_M = 2500;

@Injectable()
export class GeoService {
  constructor(@InjectRepository(Neighborhood) private repo: Repository<Neighborhood>, private cfg: ConfigService) {}

  city() {
    return this.cfg.get<string>('SERVICE_CITY') || 'Burdur';
  }
  list() {
    return this.repo.find({ where: { city: this.city(), active: true }, order: { name: 'ASC' } });
  }
  async get(id: number) {
    const n = await this.repo.findOne({ where: { id, active: true } });
    if (!n) throw Errors.notFound('Mahalle');
    return n;
  }

  /** Konumdan en yakın mahalleyi bulur. Koordinat saklanmaz, yalnızca mahalle döner. */
  async resolve(lat: number, lng: number) {
    const rows = await this.repo.query(
      `SELECT id, ST_Distance(centroid, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography) AS d, "radiusM"
         FROM neighborhoods WHERE city=$3 AND active ORDER BY d ASC LIMIT 1`,
      [lng, lat, this.city()],
    );
    if (!rows.length || rows[0].d > rows[0].radiusM + REGION_MARGIN_M) {
      throw new AppError('GEO_OUT_OF_REGION', 'Bu konum hizmet bölgesinin dışında', 422, { city: this.city() });
    }
    return this.get(rows[0].id);
  }

  /** İki mahalle merkezi arası mesafe (metre). */
  async distanceBetween(a: number, b: number): Promise<number> {
    if (a === b) return 0;
    const r = await this.repo.query('SELECT ST_Distance(x.centroid, y.centroid) AS d FROM neighborhoods x, neighborhoods y WHERE x.id=$1 AND y.id=$2', [a, b]);
    return Number(r[0]?.d ?? Infinity);
  }
}
