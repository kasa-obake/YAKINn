import { Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConnectedSocket, MessageBody, OnGatewayConnection, OnGatewayInit, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { InjectRepository } from '@nestjs/typeorm';
import { Server, Socket } from 'socket.io';
import { Repository } from 'typeorm';
import { Conversation, User, UserStatus } from '../../database/entities';
import { JwtPayload } from '../../common/auth.guard';

const TYPING_MIN_INTERVAL_MS = 1000;

/**
 * Socket.IO ağ geçidi. Her kullanıcı `user:<id>` odasına katılır.
 * Olaylar: message:new, message:read, message:deleted, typing, conversation:updated, listing:status, notification:new
 * Bağlanırken hesap durumu da kontrol edilir; askıya alınan veya silinen kullanıcının bağlantıları `disconnectUser` ile kapatılır.
 */
@WebSocketGateway({ path: '/socket.io' })
export class RealtimeGateway implements OnGatewayInit, OnGatewayConnection {
  @WebSocketServer() server: Server;
  private log = new Logger('Realtime');
  constructor(private jwt: JwtService, @InjectRepository(Conversation) private convs: Repository<Conversation>, @InjectRepository(User) private users: Repository<User>) {}

  /**
   * Kimlik doğrulama ara katmanda yapılır: istemci `connect` olayını ancak doğrulama (jeton + hesap durumu) bittikten sonra alır.
   * Reddedilen bağlantı `connect_error` (AUTH_REQUIRED) ile sonlanır.
   */
  afterInit(server: Server) {
    server.use(async (socket, next) => {
      try {
        const token = (socket.handshake.auth?.token as string) || String(socket.handshake.headers.authorization || '').replace(/^Bearer /, '');
        const p = await this.jwt.verifyAsync<JwtPayload>(token);
        const u = await this.users.findOne({ where: { id: p.sub }, select: { id: true, status: true } });
        if (!u || u.status !== UserStatus.ACTIVE) throw new Error('hesap etkin değil');
        socket.data.userId = p.sub;
        next();
      } catch {
        next(new Error('AUTH_REQUIRED'));
      }
    });
  }

  /** Oda katılımı senkron olmalı: istemci `connect` aldığında olaylar kaçmamalı. */
  handleConnection(socket: Socket) {
    if (socket.data.userId) void socket.join(`user:${socket.data.userId}`);
  }

  @SubscribeMessage('typing')
  async typing(@ConnectedSocket() socket: Socket, @MessageBody() body: { conversationId: string }) {
    const uid = socket.data.userId as string;
    if (!uid || !body?.conversationId) return;
    const now = Date.now();
    if (now - (socket.data.lastTyping ?? 0) < TYPING_MIN_INTERVAL_MS) return;
    socket.data.lastTyping = now;
    const c = await this.convs.findOne({ where: { id: body.conversationId } });
    if (!c || (c.buyerId !== uid && c.sellerId !== uid)) return;
    const other = c.buyerId === uid ? c.sellerId : c.buyerId;
    this.toUser(other, 'typing', { conversationId: c.id, userId: uid });
  }

  toUser(userId: string, event: string, payload: unknown) {
    this.server?.to(`user:${userId}`).emit(event, payload);
  }

  /** Kullanıcının tüm açık bağlantılarını kapatır (askıya alma, kalıcı kapatma, hesap silme). */
  disconnectUser(userId: string) {
    this.server?.in(`user:${userId}`).disconnectSockets(true);
  }
}
