import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ENTITIES } from '../../database/entities';
import { AuditService } from './audit.service';
import { BlocksService } from './blocks.service';
import { GeoService } from './geo.service';
import { NotificationsService } from './notifications.service';
import { PushProvider } from './push.provider';
import { RealtimeGateway } from './realtime.gateway';
import { HealthController } from './health.controller';

const SHARED = [RealtimeGateway, PushProvider, NotificationsService, AuditService, BlocksService, GeoService];

@Global()
@Module({
  imports: [TypeOrmModule.forFeature(ENTITIES)],
  controllers: [HealthController],
  providers: SHARED,
  exports: [TypeOrmModule, ...SHARED],
})
export class CoreModule {}
