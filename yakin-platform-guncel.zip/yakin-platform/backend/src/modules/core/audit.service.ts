import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog } from '../../database/entities';

/** Değiştirilemez işlem kaydı. Yalnızca ekleme yapılır. */
@Injectable()
export class AuditService {
  constructor(@InjectRepository(AuditLog) private repo: Repository<AuditLog>) {}
  log(actorId: string | null, action: string, targetType = '', targetId = '', meta: Record<string, unknown> = {}, ip = '') {
    return this.repo.insert({ actorId, action, targetType, targetId, meta: meta as never, ip });
  }
}
