import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DeviceToken, Notification, User } from '../../database/entities';
import { PushProvider } from './push.provider';
import { RealtimeGateway } from './realtime.gateway';

export type NotificationType =
  | 'new_message' | 'first_reply' | 'favorite_closed' | 'nearby_help' | 'review_request'
  | 'moderation' | 'security' | 'listing_expiring' | 'system';

/** Kapatılamayan bildirim türleri (tasarım dokümanı F9). */
const MANDATORY: NotificationType[] = ['moderation', 'security'];
/** Sessiz saatlerde de anlık bildirim gönderilen türler. */
const QUIET_ALLOWED: NotificationType[] = ['new_message', 'first_reply', 'security'];

@Injectable()
export class NotificationsService {
  constructor(
    @InjectRepository(Notification) private repo: Repository<Notification>,
    @InjectRepository(DeviceToken) private devices: Repository<DeviceToken>,
    @InjectRepository(User) private users: Repository<User>,
    private push: PushProvider,
    private rt: RealtimeGateway,
  ) {}

  async notify(userId: string, type: NotificationType, title: string, body: string, link: string, data: Record<string, unknown> = {}) {
    const user = await this.users.findOne({ where: { id: userId } });
    if (!user) return null;
    const prefs = user.notificationPrefs || {};
    if (!MANDATORY.includes(type) && prefs[type] === false) return null;
    const n = await this.repo.save(this.repo.create({ userId, type, title, body, link, data }));
    this.rt.toUser(userId, 'notification:new', n);
    if (this.inQuietHours(prefs) && !QUIET_ALLOWED.includes(type)) return n;
    const tokens = (await this.devices.find({ where: { userId } })).map((d) => d.token);
    await this.push.send(tokens, { title, body, data: { link, type } });
    return n;
  }

  private inQuietHours(prefs: Record<string, unknown>, now = new Date()) {
    if (prefs.quietHours === false) return false;
    const hour = Number(new Intl.DateTimeFormat('tr-TR', { hour: 'numeric', hourCycle: 'h23', timeZone: 'Europe/Istanbul' }).format(now));
    return hour >= 22 || hour < 8;
  }
}
