import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Block } from '../../database/entities';

@Injectable()
export class BlocksService {
  constructor(@InjectRepository(Block) private repo: Repository<Block>) {}
  /** İki yönlü engel: benim engellediklerim ve beni engelleyenler. */
  async hiddenIds(userId: string): Promise<string[]> {
    const rows = await this.repo.query('SELECT "blockedId" AS id FROM blocks WHERE "userId"=$1 UNION SELECT "userId" FROM blocks WHERE "blockedId"=$1', [userId]);
    return rows.map((r: { id: string }) => r.id);
  }
  async isBlockedBetween(a: string, b: string) {
    const n = await this.repo.count({ where: [{ userId: a, blockedId: b }, { userId: b, blockedId: a }] });
    return n > 0;
  }
}
