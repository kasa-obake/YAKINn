import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { Public } from '../../common/auth.guard';

@ApiTags('health')
@Controller('health')
export class HealthController {
  constructor(@InjectDataSource() private ds: DataSource) {}
  @Public() @Get()
  async health() {
    const t = Date.now();
    await this.ds.query('SELECT 1');
    return { status: 'ok', db: 'ok', dbLatencyMs: Date.now() - t, time: new Date().toISOString(), version: process.env.npm_package_version ?? '0.1.0' };
  }
}
