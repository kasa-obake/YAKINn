import { Body, Controller, Get, HttpCode, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { IsEnum, IsIn, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';
import { AllowSuspended, CurrentUser } from '../../common/auth.guard';
import { ReportTarget, User } from '../../database/entities';
import { REPORT_REASONS, SafetyService } from './safety.service';

class ReportDto {
  @IsEnum(ReportTarget) targetType: ReportTarget;
  @IsUUID() targetId: string;
  @IsIn(REPORT_REASONS as unknown as string[]) reason: string;
  @IsOptional() @IsString() @MaxLength(500) note?: string;
  @IsOptional() @IsString() @MaxLength(400) screenshotUrl?: string;
}

@ApiTags('safety')
@Controller()
export class SafetyController {
  constructor(private svc: SafetyService) {}
  @AllowSuspended() @Post('reports') @HttpCode(201) create(@CurrentUser() u: User, @Body() dto: ReportDto) { return this.svc.create(u, dto); }
  @Get('me/reports') mine(@CurrentUser() u: User) { return this.svc.mine(u); }
}
