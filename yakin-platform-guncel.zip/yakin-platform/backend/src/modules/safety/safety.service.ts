import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { Conversation, Listing, ListingStatus, Message, Report, ReportPriority, ReportStatus, ReportTarget, User } from '../../database/entities';
import { AuditService } from '../core/audit.service';

export const REPORT_REASONS = ['dolandiricilik', 'uygunsuz_icerik', 'taciz', 'yasakli_urun', 'sahte_ilan', 'spam', 'cocuk_guvenligi', 'diger'] as const;
export type ReportReason = (typeof REPORT_REASONS)[number];

/** Gerekçeye göre öncelik ve SLA (tasarım dokümanı F12). */
const PRIORITY: Record<string, [ReportPriority, number]> = {
  cocuk_guvenligi: [ReportPriority.CRITICAL, 1],
  taciz: [ReportPriority.CRITICAL, 1],
  dolandiricilik: [ReportPriority.HIGH, 4],
  yasakli_urun: [ReportPriority.HIGH, 4],
};
/** Bu kadar farklı kişi şikâyet ederse ilan inceleme bitene kadar akıştan kaldırılır. */
export const AUTO_HIDE_THRESHOLD = 3;

@Injectable()
export class SafetyService {
  constructor(
    @InjectRepository(Report) private reports: Repository<Report>,
    @InjectRepository(Listing) private listings: Repository<Listing>,
    @InjectRepository(Message) private messages: Repository<Message>,
    @InjectRepository(Conversation) private convs: Repository<Conversation>,
    @InjectRepository(User) private users: Repository<User>,
    private audit: AuditService,
  ) {}

  async create(me: User, dto: { targetType: ReportTarget; targetId: string; reason: string; note?: string; screenshotUrl?: string }) {
    let ownerId: string | null = null;
    if (dto.targetType === ReportTarget.LISTING) {
      const l = await this.listings.findOne({ where: { id: dto.targetId } });
      if (!l) throw Errors.notFound('İlan');
      ownerId = l.userId;
    } else if (dto.targetType === ReportTarget.USER) {
      if (!(await this.users.exist({ where: { id: dto.targetId } }))) throw Errors.notFound('Kullanıcı');
      ownerId = dto.targetId;
    } else {
      const m = await this.messages.findOne({ where: { id: dto.targetId } });
      if (!m) throw Errors.notFound('Mesaj');
      const c = await this.convs.findOneOrFail({ where: { id: m.conversationId } });
      if (c.buyerId !== me.id && c.sellerId !== me.id) throw Errors.notFound('Mesaj');
      ownerId = m.senderId;
    }
    if (ownerId === me.id) throw new AppError('REPORT_SELF', 'Kendi içeriğini şikâyet edemezsin', 400);
    const dup = await this.reports.findOne({ where: { reporterId: me.id, targetType: dto.targetType, targetId: dto.targetId, status: In([ReportStatus.OPEN, ReportStatus.IN_REVIEW]) } });
    if (dup) throw new AppError('REPORT_DUPLICATE', 'Bu içeriği zaten bildirdin, inceleniyor', 409);
    const [priority, hours] = PRIORITY[dto.reason] ?? [ReportPriority.NORMAL, 24];
    const r = await this.reports.save(this.reports.create({
      reporterId: me.id, targetType: dto.targetType, targetId: dto.targetId, targetOwnerId: ownerId, reason: dto.reason,
      note: (dto.note ?? '').trim(), screenshotUrl: dto.screenshotUrl ?? null, priority, slaDueAt: new Date(Date.now() + hours * 3600_000),
    }));
    let autoHidden = false;
    if (dto.targetType === ReportTarget.LISTING) {
      const [{ n }] = await this.reports.query(
        `SELECT COUNT(DISTINCT "reporterId")::int AS n FROM reports WHERE "targetType"='listing' AND "targetId"=$1 AND status IN ('open','in_review') AND "reporterId" IS NOT NULL`,
        [dto.targetId],
      );
      if (n >= AUTO_HIDE_THRESHOLD || priority === ReportPriority.CRITICAL) {
        const res = await this.listings.update({ id: dto.targetId, status: ListingStatus.ACTIVE }, { status: ListingStatus.PENDING_REVIEW });
        autoHidden = !!res.affected;
        if (autoHidden) await this.audit.log(null, 'listing.auto_hidden', 'listing', dto.targetId, { reports: n });
      }
    }
    return { id: r.id, priority: r.priority, autoHidden };
  }

  mine(me: User) {
    return this.reports.find({ where: { reporterId: me.id }, order: { createdAt: 'DESC' }, take: 50, select: ['id', 'targetType', 'targetId', 'reason', 'status', 'createdAt'] });
  }
}
