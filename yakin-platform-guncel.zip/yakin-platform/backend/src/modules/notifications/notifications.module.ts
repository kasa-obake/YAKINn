import { Module } from '@nestjs/common';
import { ChatModule } from '../chat/chat.module';
import { NotificationsController } from './notifications.controller';

@Module({ imports: [ChatModule], controllers: [NotificationsController] })
export class NotificationsModule {}
