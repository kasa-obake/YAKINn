import { Body, Controller, Get, HttpCode, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { IsOptional, IsString, Length } from 'class-validator';
import { DataSource, IsNull, Repository } from 'typeorm';
import { AllowIncompleteProfile, AllowSuspended, CurrentUser, Public } from '../../common/auth.guard';
import { clampLimit, decodeCursor, encodeCursor } from '../../common/format';
import { Notification, SUBTYPES, SupportTicket, User } from '../../database/entities';
import { ChatService } from '../chat/chat.service';
import { GeoService } from '../core/geo.service';
import { REPORT_REASONS } from '../safety/safety.service';

class SupportDto {
  @IsString() @Length(3, 120) subject: string;
  @IsString() @Length(10, 3000) body: string;
}
class PageDto {
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() limit?: number;
}

@ApiTags('notifications')
@Controller()
export class NotificationsController {
  constructor(
    @InjectRepository(Notification) private repo: Repository<Notification>,
    @InjectRepository(SupportTicket) private tickets: Repository<SupportTicket>,
    @InjectDataSource() private ds: DataSource,
    private chat: ChatService,
    private geo: GeoService,
  ) {}

  @Get('notifications')
  async list(@CurrentUser() u: User, @Query() q: PageDto) {
    const limit = clampLimit(q.limit, 30, 100);
    const cur = decodeCursor(q.cursor);
    const qb = this.repo.createQueryBuilder('n').where('n."userId"=:u', { u: u.id }).orderBy(`date_trunc('milliseconds', n."createdAt")`, 'DESC').addOrderBy('n.id', 'DESC').take(limit + 1);
    if (cur) qb.andWhere('(date_trunc(\'milliseconds\', n."createdAt"), n.id) < (:d, :id)', { d: cur.createdAt, id: cur.id });
    const rows = await qb.getMany();
    const page = rows.slice(0, limit), last = page[page.length - 1];
    return { items: page, nextCursor: rows.length > limit && last ? encodeCursor(last.createdAt, last.id) : null };
  }

  @Post('notifications/read-all') @HttpCode(200)
  async readAll(@CurrentUser() u: User) {
    await this.repo.update({ userId: u.id, readAt: IsNull() }, { readAt: new Date() });
    return { ok: true };
  }

  @Post('notifications/:id/read') @HttpCode(200)
  async readOne(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) {
    await this.repo.update({ id, userId: u.id }, { readAt: new Date() });
    return { ok: true };
  }

  /** Alt menü rozetleri: okunmamış mesaj, okunmamış bildirim, bekleyen değerlendirme. */
  @Get('badges')
  async badges(@CurrentUser() u: User) {
    const [messages, notifications, [pr]] = await Promise.all([
      this.chat.unreadCount(u),
      this.repo.count({ where: { userId: u.id, readAt: IsNull() } }),
      this.ds.query(
        `SELECT COUNT(*)::int AS n FROM listings l WHERE l."closeReason"='delivered' AND l."closedAt" > now() - interval '14 days'
           AND ($1 = l."userId" OR $1 = l."deliveredToUserId") AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r."listingId"=l.id AND r."fromId"=$1)`,
        [u.id],
      ),
    ]);
    return { messages, notifications, pendingReviews: pr.n };
  }

  @AllowIncompleteProfile() @AllowSuspended() @Post('support') @HttpCode(201)
  async support(@CurrentUser() u: User, @Body() dto: SupportDto) {
    const t = await this.tickets.save(this.tickets.create({ userId: u.id, subject: dto.subject.trim(), body: dto.body.trim() }));
    return { ticketNo: `YK-${String(t.id).padStart(6, '0')}`, status: t.status };
  }

  /** İstemcinin açılışta okuduğu uzaktan yapılandırma. */
  @Public() @Get('app/config')
  config() {
    return {
      city: this.geo.city(),
      minAppVersion: process.env.MIN_APP_VERSION || '1.0.0',
      maintenance: process.env.MAINTENANCE === 'true',
      categories: SUBTYPES,
      reportReasons: REPORT_REASONS,
      reviewTags: ['dakik', 'nazik', 'aciklamaya_uygun', 'iletisim_kolay', 'guvenilir'],
      radiusOptionsKm: [1, 3, 5, 10, 20],
      limits: { activeListings: 10, photosPerListing: 8, favorites: 100, messageLength: 2000 },
    };
  }
}
