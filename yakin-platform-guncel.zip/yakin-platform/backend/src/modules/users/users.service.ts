import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, IsNull, Not, Repository } from 'typeorm';
import { AppError, Errors } from '../../common/errors';
import { listingCard, meView, monthlyChanges, userCard } from '../../common/presenters';
import { Block, Listing, ListingStatus, Message, Notification, Review, User, CloseReason } from '../../database/entities';
import { AuditService } from '../core/audit.service';
import { BlocksService } from '../core/blocks.service';
import { GeoService } from '../core/geo.service';
import { RealtimeGateway } from '../core/realtime.gateway';
import { AuthService } from '../auth/auth.service';
import { UpdateMeDto } from './users.dto';

const NOTIF_KEYS = ['new_message', 'first_reply', 'favorite_closed', 'nearby_help', 'review_request', 'listing_expiring', 'quietHours'];
const PUBLISHED_REVIEW = `(r."publishedAt" IS NOT NULL OR r."createdAt" < now() - interval '14 days')`;

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User) private users: Repository<User>,
    @InjectRepository(Listing) private listings: Repository<Listing>,
    @InjectRepository(Block) private blocks: Repository<Block>,
    @InjectRepository(Review) private reviews: Repository<Review>,
    @InjectRepository(Message) private messages: Repository<Message>,
    @InjectRepository(Notification) private notifications: Repository<Notification>,
    private geo: GeoService,
    private blocksSvc: BlocksService,
    private audit: AuditService,
    private auth: AuthService,
    private rt: RealtimeGateway,
  ) {}

  async update(user: User, dto: UpdateMeDto) {
    const patch: Partial<User> = {};
    for (const k of ['firstName', 'lastName', 'bio', 'avatarUrl', 'interests', 'hideNeighborhood', 'showReadReceipts', 'showResponseTime', 'analyticsConsent', 'marketingConsent'] as const) {
      if (dto[k] !== undefined) (patch as Record<string, unknown>)[k] = typeof dto[k] === 'string' ? (dto[k] as string).trim() : dto[k];
    }
    if (dto.birthYear !== undefined) {
      const age = new Date().getFullYear() - dto.birthYear;
      // MVP yalnızca 18 yaş ve üzeri içindir. Yaş bilgisi reddedilse de kaydedilmez.
      if (age < 18) throw new AppError('USER_UNDERAGE', 'YAKIN şimdilik 18 yaş ve üzeri içindir', 422);
      if (age > 110) throw new AppError('VALIDATION_ERROR', 'Doğum yılı geçersiz', 400, { fields: { birthYear: 'invalid' } });
      if (user.birthYear && user.birthYear !== dto.birthYear) throw new AppError('USER_BIRTHYEAR_LOCKED', 'Doğum yılı değiştirilemez, destekle iletişime geç', 409);
      patch.birthYear = dto.birthYear;
    }
    if (dto.neighborhoodId !== undefined && dto.neighborhoodId !== user.neighborhoodId) {
      await this.geo.get(dto.neighborhoodId);
      if (user.neighborhoodId) {
        const used = monthlyChanges(user);
        if (used >= 2) throw new AppError('USER_NEIGHBORHOOD_LIMIT', 'Mahalleni bu ay en fazla 2 kez değiştirebilirsin', 429);
        patch.neighborhoodChanges = used + 1;
        patch.neighborhoodChangedAt = new Date();
      }
      patch.neighborhoodId = dto.neighborhoodId;
    }
    if (dto.notificationPrefs) {
      const prefs = { ...user.notificationPrefs };
      for (const [k, v] of Object.entries(dto.notificationPrefs)) if (NOTIF_KEYS.includes(k) && typeof v === 'boolean') prefs[k] = v;
      patch.notificationPrefs = prefs;
    }
    if (Object.keys(patch).length) await this.users.update(user.id, patch);
    return meView(await this.users.findOneOrFail({ where: { id: user.id } }));
  }

  /** Hesap silme talebi: ilanlar kapanır, oturumlar sonlanır, 30 gün sonra kalıcı silme işi çalışır. */
  async requestDeletion(user: User, reason = '') {
    await this.users.update(user.id, { deletionRequestedAt: new Date() });
    await this.listings.update({ userId: user.id, status: In([ListingStatus.ACTIVE, ListingStatus.PENDING_REVIEW, ListingStatus.DRAFT]) }, { status: ListingStatus.CLOSED, closeReason: CloseReason.CANCELLED, closedAt: new Date() });
    await this.auth.revokeAll(user.id);
    this.rt.disconnectUser(user.id);
    await this.audit.log(user.id, 'user.deletion_requested', 'user', user.id, { reason });
    return { ok: true, purgeAfterDays: 30 };
  }

  /** KVKK veri dışa aktarımı (JSON). Üretimde e-posta/indirme bağlantısıyla asenkron yapılır. */
  async exportData(user: User) {
    const [listings, sent, reviewsGiven, reviewsReceived, blocks, notifications] = await Promise.all([
      this.listings.find({ where: { userId: user.id } }),
      this.messages.find({ where: { senderId: user.id }, order: { createdAt: 'ASC' } }),
      this.reviews.find({ where: { fromId: user.id } }),
      this.reviews.find({ where: { toId: user.id, publishedAt: Not(IsNull()) } }),
      this.blocks.find({ where: { userId: user.id } }),
      this.notifications.find({ where: { userId: user.id }, take: 500, order: { createdAt: 'DESC' } }),
    ]);
    await this.audit.log(user.id, 'user.data_export', 'user', user.id);
    return {
      generatedAt: new Date(),
      profile: { ...meView(user), phone: user.phone },
      listings: listings.map((l) => ({ id: l.id, category: l.category, subtype: l.subtype, title: l.title, description: l.description, status: l.status, createdAt: l.createdAt })),
      messagesSent: sent.map((m) => ({ conversationId: m.conversationId, body: m.deletedAt ? '' : m.body, imageUrl: m.imageUrl, createdAt: m.createdAt })),
      reviewsGiven,
      reviewsReceived,
      blockedUserIds: blocks.map((b) => b.blockedId),
      notifications,
    };
  }

  async stats(userId: string) {
    const [rating] = await this.reviews.query(
      `SELECT COALESCE(AVG(rating),0)::float AS avg, COUNT(*)::int AS count FROM reviews r WHERE r."toId"=$1 AND ${PUBLISHED_REVIEW}`,
      [userId],
    );
    // Ortalama yanıt süresi: ilan sahibinin, karşı tarafın ilk mesajına ilk yanıtı (son 90 gün, medyan).
    const [resp] = await this.messages.query(
      `WITH firsts AS (
         SELECT c.id,
           MIN(m."createdAt") FILTER (WHERE m."senderId"=c."buyerId") AS q,
           MIN(m."createdAt") FILTER (WHERE m."senderId"=c."sellerId") AS a
         FROM conversations c JOIN messages m ON m."conversationId"=c.id
         WHERE c."sellerId"=$1 AND c."createdAt" > now() - interval '90 days' GROUP BY c.id)
       SELECT percentile_cont(0.5) WITHIN GROUP (ORDER BY EXTRACT(EPOCH FROM (a-q))) AS median, COUNT(*)::int AS n
       FROM firsts WHERE a IS NOT NULL AND a > q`,
      [userId],
    );
    return { ratingAvg: Math.round(rating.avg * 10) / 10, ratingCount: rating.count, medianResponseSec: resp.n >= 3 ? Math.round(resp.median) : null };
  }

  async publicProfile(viewer: User, id: string) {
    const u = await this.users.findOne({ where: { id } });
    if (!u || u.status === 'deleted' || u.deletionRequestedAt) throw Errors.notFound('Kullanıcı');
    const iBlocked = !!(await this.blocks.findOne({ where: { userId: viewer.id, blockedId: id } }));
    const blockedMe = !!(await this.blocks.findOne({ where: { userId: id, blockedId: viewer.id } }));
    if (blockedMe) throw Errors.notFound('Kullanıcı');
    const stats = await this.stats(id);
    const listings = iBlocked ? [] : await this.listings.find({ where: { userId: id, status: ListingStatus.ACTIVE }, order: { createdAt: 'DESC' }, take: 20 });
    const reviews = await this.reviews.query(
      `SELECT r.id, r.rating, r.tags, r.comment, r."createdAt", u."firstName", u."lastName"
         FROM reviews r JOIN users u ON u.id=r."fromId" WHERE r."toId"=$1 AND ${PUBLISHED_REVIEW} ORDER BY r."createdAt" DESC LIMIT 10`,
      [id],
    );
    return {
      user: { ...userCard(u), bio: u.bio, interests: u.interests },
      stats: { ...stats, medianResponseSec: u.showResponseTime ? stats.medianResponseSec : null, helpedCount: u.helpedCount },
      blockedByMe: iBlocked,
      isMe: viewer.id === id,
      listings: listings.map((l) => listingCard(l)),
      reviews: reviews.map((r: Record<string, string>) => ({
        id: r.id, rating: r.rating, tags: r.tags, comment: r.comment, createdAt: r.createdAt,
        from: `${r.firstName} ${r.lastName ? r.lastName.charAt(0) + '.' : ''}`.trim(),
      })),
    };
  }

  async block(me: User, id: string) {
    if (me.id === id) throw new AppError('VALIDATION_ERROR', 'Kendini engelleyemezsin', 400);
    if (!(await this.users.exist({ where: { id } }))) throw Errors.notFound('Kullanıcı');
    await this.blocks.upsert({ userId: me.id, blockedId: id }, ['userId', 'blockedId']);
    await this.audit.log(me.id, 'user.block', 'user', id);
    return { blocked: true };
  }
  async unblock(me: User, id: string) {
    await this.blocks.delete({ userId: me.id, blockedId: id });
    return { blocked: false };
  }
  async blockList(me: User) {
    const rows = await this.blocks.find({ where: { userId: me.id }, order: { createdAt: 'DESC' } });
    const users = rows.length ? await this.users.find({ where: { id: In(rows.map((r) => r.blockedId)) } }) : [];
    return { items: rows.map((r) => ({ user: userCard(users.find((u) => u.id === r.blockedId)), blockedAt: r.createdAt })) };
  }
}

