import { Body, Controller, Delete, Get, HttpCode, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AllowIncompleteProfile, AllowSuspended, CurrentUser } from '../../common/auth.guard';
import { meView } from '../../common/presenters';
import { User } from '../../database/entities';
import { DeleteMeDto, UpdateMeDto } from './users.dto';
import { UsersService } from './users.service';

@ApiTags('users')
@Controller()
export class UsersController {
  constructor(private svc: UsersService) {}

  @AllowIncompleteProfile() @AllowSuspended() @Get('me')
  me(@CurrentUser() u: User) {
    return meView(u);
  }
  @AllowIncompleteProfile() @Patch('me')
  update(@CurrentUser() u: User, @Body() dto: UpdateMeDto) {
    return this.svc.update(u, dto);
  }
  @AllowIncompleteProfile() @AllowSuspended() @Post('me/delete') @HttpCode(200)
  remove(@CurrentUser() u: User, @Body() dto: DeleteMeDto) {
    return this.svc.requestDeletion(u, dto.reason);
  }
  @AllowIncompleteProfile() @AllowSuspended() @Get('me/export')
  export(@CurrentUser() u: User) {
    return this.svc.exportData(u);
  }
  @Get('me/stats')
  stats(@CurrentUser() u: User) {
    return this.svc.stats(u.id);
  }
  @Get('me/blocks')
  blocks(@CurrentUser() u: User) {
    return this.svc.blockList(u);
  }
  @Get('users/:id')
  profile(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) {
    return this.svc.publicProfile(u, id);
  }
  @AllowSuspended() @Post('users/:id/block') @HttpCode(200)
  block(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) {
    return this.svc.block(u, id);
  }
  @AllowSuspended() @Delete('users/:id/block')
  unblock(@CurrentUser() u: User, @Param('id', ParseUUIDPipe) id: string) {
    return this.svc.unblock(u, id);
  }
}
