import { Type } from 'class-transformer';
import { ArrayMaxSize, IsArray, IsBoolean, IsInt, IsObject, IsOptional, IsString, Matches, Max, MaxLength, Min, MinLength } from 'class-validator';

export class UpdateMeDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(40) @Matches(/^[\p{L} '.-]+$/u, { message: 'firstName harf içermeli' }) firstName?: string;
  @IsOptional() @IsString() @MaxLength(40) @Matches(/^[\p{L} '.-]*$/u, { message: 'lastName harf içermeli' }) lastName?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1900) @Max(2100) birthYear?: number;
  @IsOptional() @IsString() @MaxLength(160) bio?: string;
  @IsOptional() @IsString() @MaxLength(400) avatarUrl?: string | null;
  @IsOptional() @Type(() => Number) @IsInt() neighborhoodId?: number;
  @IsOptional() @IsArray() @ArrayMaxSize(10) @IsString({ each: true }) interests?: string[];
  @IsOptional() @IsBoolean() hideNeighborhood?: boolean;
  @IsOptional() @IsBoolean() showReadReceipts?: boolean;
  @IsOptional() @IsBoolean() showResponseTime?: boolean;
  @IsOptional() @IsBoolean() analyticsConsent?: boolean;
  @IsOptional() @IsBoolean() marketingConsent?: boolean;
  @IsOptional() @IsObject() notificationPrefs?: Record<string, boolean>;
}

export class DeleteMeDto {
  @IsOptional() @IsString() @MaxLength(300) reason?: string;
}
