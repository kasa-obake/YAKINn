import { Module, ValidationPipe } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_FILTER, APP_GUARD, APP_PIPE } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthGuard } from './common/auth.guard';
import { AllExceptionsFilter } from './common/http-exception.filter';
import { dataSourceOptions } from './database/data-source';
import { AuthModule } from './modules/auth/auth.module';
import { ChatModule } from './modules/chat/chat.module';
import { CoreModule } from './modules/core/core.module';
import { GeoController } from './modules/geo/geo.controller';
import { ListingsModule } from './modules/listings/listings.module';
import { MaintenanceModule } from './modules/maintenance/maintenance.module';
import { MediaModule } from './modules/media/media.module';
import { ModerationModule } from './modules/moderation/moderation.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { SafetyModule } from './modules/safety/safety.module';
import { UsersModule } from './modules/users/users.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: process.env.ENV_FILE || '.env' }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (cfg: ConfigService) => ({ ...dataSourceOptions(cfg.getOrThrow('DATABASE_URL')), migrationsRun: cfg.get('DB_MIGRATE_ON_START') === 'true' }),
    }),
    JwtModule.registerAsync({
      global: true,
      inject: [ConfigService],
      useFactory: (cfg: ConfigService) => ({ secret: cfg.getOrThrow('JWT_ACCESS_SECRET'), signOptions: { expiresIn: cfg.get('JWT_ACCESS_TTL') || '15m' } }),
    }),
    ThrottlerModule.forRoot({ throttlers: [{ name: 'default', ttl: 60_000, limit: Number(process.env.RATE_LIMIT_PER_MIN || 120) }], skipIf: () => process.env.NODE_ENV === 'test' && process.env.THROTTLE_IN_TEST !== 'true' }),
    CoreModule,
    AuthModule,
    UsersModule,
    MediaModule,
    MaintenanceModule,
    ListingsModule,
    ChatModule,
    NotificationsModule,
    SafetyModule,
    ModerationModule,
  ],
  controllers: [GeoController],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
    { provide: APP_PIPE, useValue: new ValidationPipe({ whitelist: true, forbidNonWhitelisted: false, transform: true }) },
  ],
})
export class AppModule {}
