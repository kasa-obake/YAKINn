import { NetgsmSmsProvider, SmsSendError, smsProviderFactory, toGsmAscii, toNetgsmNumber } from '../src/modules/auth/sms.provider';

const cfg = { usercode: '8503330000', password: 'gizli', header: 'YAKIN', otp: true, baseUrl: 'https://api.netgsm.com.tr', timeoutMs: 2000 };
const resp = (status: number, body: unknown) => new Response(typeof body === 'string' ? body : JSON.stringify(body), { status });
const conf = (env: Record<string, string>) => ({ get: (k: string) => env[k] }) as never;

describe('Netgsm SMS sağlayıcısı', () => {
  it('numarayı 5XXXXXXXXX biçimine çevirir', () => {
    expect(toNetgsmNumber('+905321234567')).toBe('5321234567');
    expect(toNetgsmNumber('05321234567')).toBe('5321234567');
    expect(() => toNetgsmNumber('+4915112345678')).toThrow(SmsSendError);
  });

  it('OTP metnini ASCII yapar ve 160 karakterde tutar', () => {
    expect(toGsmAscii('YAKIN doğrulama kodun: 123456. Kodu kimseyle paylaşma.')).toBe('YAKIN dogrulama kodun: 123456. Kodu kimseyle paylasma.');
    const p = new NetgsmSmsProvider(cfg);
    const r = p.buildRequest('+905321234567', 'YAKIN doğrulama kodun: 123456.');
    expect(r.url).toBe('https://api.netgsm.com.tr/sms/rest/v2/otp');
    expect(r.body).toEqual({ msgheader: 'YAKIN', msg: 'YAKIN dogrulama kodun: 123456.', no: '5321234567' });
    expect(() => p.buildRequest('+905321234567', 'x'.repeat(161))).toThrow(/160/);
  });

  it('normal SMS kanalında Türkçe kodlamayla /send kullanır', () => {
    const r = new NetgsmSmsProvider({ ...cfg, otp: false, appname: 'yakin' }).buildRequest('+905321234567', 'Kodun: 1');
    expect(r.url).toBe('https://api.netgsm.com.tr/sms/rest/v2/send');
    expect(r.body).toEqual({ msgheader: 'YAKIN', encoding: 'TR', messages: [{ msg: 'Kodun: 1', no: '5321234567' }], appname: 'yakin' });
  });

  it('Basic kimlik bilgisiyle gönderir, 00 kodunda başarılı sayar', async () => {
    const f = jest.fn().mockResolvedValue(resp(200, { code: '00', jobid: '123' }));
    await new NetgsmSmsProvider(cfg, f).send('+905321234567', 'Kod 1');
    const [url, init] = f.mock.calls[0];
    expect(url).toBe('https://api.netgsm.com.tr/sms/rest/v2/otp');
    expect(init.headers.Authorization).toBe('Basic ' + Buffer.from('8503330000:gizli').toString('base64'));
    expect(f).toHaveBeenCalledTimes(1);
  });

  it('kalıcı hatada (30) tekrar denemez ve açıklamayla hata verir', async () => {
    const f = jest.fn().mockResolvedValue(resp(406, { code: '30', description: 'x' }));
    await expect(new NetgsmSmsProvider(cfg, f).send('+905321234567', 'Kod')).rejects.toMatchObject({ providerCode: '30', retryable: false });
    expect(f).toHaveBeenCalledTimes(1);
  });

  it('geçici hatada (100) ve ağ hatasında bir kez daha dener', async () => {
    const f = jest.fn().mockResolvedValueOnce(resp(200, { code: '100' })).mockResolvedValueOnce(resp(200, { code: '00' }));
    await new NetgsmSmsProvider(cfg, f).send('+905321234567', 'Kod');
    expect(f).toHaveBeenCalledTimes(2);
    const g = jest.fn().mockRejectedValue(new TypeError('fetch failed'));
    await expect(new NetgsmSmsProvider(cfg, g).send('+905321234567', 'Kod')).rejects.toMatchObject({ providerCode: 'NETWORK', retryable: true });
    expect(g).toHaveBeenCalledTimes(2);
  });

  it('hız sınırında (85) hemen tekrar denemez', async () => {
    const f = jest.fn().mockResolvedValue(resp(200, { code: '85' }));
    await expect(new NetgsmSmsProvider(cfg, f).send('+905321234567', 'Kod')).rejects.toMatchObject({ providerCode: '85', retryable: true });
    expect(f).toHaveBeenCalledTimes(1);
  });

  it('başlık kontrolü', async () => {
    const f = jest.fn().mockResolvedValue(resp(200, { code: '00', msgheaders: ['YAKIN', 'DIGER'] }));
    expect(await new NetgsmSmsProvider(cfg, f).checkHeaders()).toMatchObject({ ok: true });
    const g = jest.fn().mockResolvedValue(resp(200, { code: '00', msgheaders: ['DIGER'] }));
    expect(await new NetgsmSmsProvider(cfg, g).checkHeaders()).toMatchObject({ ok: false });
  });

  it('fabrika: eksik ayarda ve üretimde console seçiminde açılışta hata verir', () => {
    expect(() => smsProviderFactory(conf({ SMS_PROVIDER: 'netgsm', NETGSM_USERCODE: '1' }))).toThrow(/NETGSM_PASSWORD, NETGSM_HEADER/);
    expect(() => smsProviderFactory(conf({ SMS_PROVIDER: 'console', NODE_ENV: 'production' }))).toThrow(/Üretimde/);
    expect(smsProviderFactory(conf({ SMS_PROVIDER: 'netgsm', NETGSM_USERCODE: '1', NETGSM_PASSWORD: '2', NETGSM_HEADER: 'YAKIN' }))).toBeInstanceOf(NetgsmSmsProvider);
  });
});
