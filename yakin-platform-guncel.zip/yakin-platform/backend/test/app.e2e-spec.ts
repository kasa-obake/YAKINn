/**
 * Uçtan uca ana akış: kayıt → profil → ilan → akış → mesaj (gerçek zamanlı) → teslim → değerlendirme
 * → engelleme → şikâyet → moderasyon → itiraz. Gerçek PostgreSQL + PostGIS üzerinde çalışır.
 */
import { INestApplication } from '@nestjs/common';
import sharp from 'sharp';
import { io, Socket } from 'socket.io-client';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { createApp } from '../src/main';

let app: INestApplication;
let http: ReturnType<typeof request>;
let baseUrl: string;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function login(phone: string, termsAccepted = true) {
  const r = await http.post('/v1/auth/otp/request').send({ phone }).expect(200);
  expect(r.body.devCode).toHaveLength(6);
  const v = await http.post('/v1/auth/otp/verify').send({ phone, code: r.body.devCode, termsAccepted }).expect(200);
  return v.body as { accessToken: string; refreshToken: string; user: { id: string; profileComplete: boolean }; isNew: boolean };
}

function waitFor<T>(s: Socket, event: string, pred: (p: T) => boolean = () => true, ms = 5000): Promise<T> {
  return new Promise((res, rej) => {
    const t = setTimeout(() => rej(new Error(`zaman aşımı: ${event}`)), ms);
    const h = (p: T) => { if (pred(p)) { clearTimeout(t); s.off(event, h); res(p); } };
    s.on(event, h);
  });
}

beforeAll(async () => {
  app = await createApp();
  await app.listen(0);
  const addr = app.getHttpServer().address();
  baseUrl = `http://127.0.0.1:${addr.port}`;
  http = request(app.getHttpServer());
});
afterAll(async () => { await app?.close(); });

describe('YAKIN API', () => {
  const S: Record<string, any> = {};

  it('sağlık ve uzaktan yapılandırma', async () => {
    await http.get('/v1/health').expect(200);
    const c = await http.get('/v1/app/config').expect(200);
    expect(c.body.city).toBe('Burdur');
    expect(c.body.categories.esya).toContain('ucretsiz');
    const n = await http.get('/v1/neighborhoods').expect(200);
    expect(n.body.items.length).toBe(10);
    S.hoods = n.body.items;
  });

  it('kimlik doğrulama: geçersiz telefon, koşul onayı, hatalı kod, yeniden gönderme sınırı', async () => {
    await http.post('/v1/auth/otp/request').send({ phone: '12345' }).expect(400).expect((r) => expect(r.body.code).toBe('AUTH_PHONE_INVALID'));
    const r = await http.post('/v1/auth/otp/request').send({ phone: '0 555 111 22 33' }).expect(200);
    expect(r.body.phoneMasked).toBe('+90 555 *** ** 33');
    await http.post('/v1/auth/otp/request').send({ phone: '05551112233' }).expect(429).expect((x) => expect(x.body.code).toBe('AUTH_RESEND_TOO_SOON'));
    await http.post('/v1/auth/otp/verify').send({ phone: '05551112233', code: '000000', termsAccepted: true }).expect(400)
      .expect((x) => { expect(x.body.code).toBe('AUTH_OTP_INVALID'); expect(x.body.details.attemptsLeft).toBe(4); });
    await http.post('/v1/auth/otp/verify').send({ phone: '05551112233', code: r.body.devCode }).expect(400).expect((x) => expect(x.body.code).toBe('AUTH_TERMS_REQUIRED'));
    const v = await http.post('/v1/auth/otp/verify').send({ phone: '05551112233', code: r.body.devCode, termsAccepted: true }).expect(200);
    expect(v.body.isNew).toBe(true);
    expect(v.body.user.profileComplete).toBe(false);
    S.ali = v.body;
  });

  it('profil tamamlanmadan akış kapalı; 18 yaş ve bölge kontrolü', async () => {
    const t = S.ali.accessToken;
    await http.get('/v1/listings').set(auth(t)).expect(403).expect((r) => expect(r.body.code).toBe('PROFILE_INCOMPLETE'));
    await http.patch('/v1/me').set(auth(t)).send({ birthYear: new Date().getFullYear() - 15 }).expect(422).expect((r) => expect(r.body.code).toBe('USER_UNDERAGE'));
    await http.post('/v1/neighborhoods/resolve').set(auth(t)).send({ lat: 39.92, lng: 32.85 }).expect(422).expect((r) => expect(r.body.code).toBe('GEO_OUT_OF_REGION'));
    const n = await http.post('/v1/neighborhoods/resolve').set(auth(t)).send({ lat: 37.7213, lng: 30.2903 }).expect(200);
    expect(n.body.name).toBe('Konak');
    const me = await http.patch('/v1/me').set(auth(t)).send({ firstName: 'Ali', lastName: 'Yılmaz', birthYear: 1992, neighborhoodId: n.body.id }).expect(200);
    expect(me.body.profileComplete).toBe(true);
    expect(me.body.displayName).toBe('Ali Y.');
    expect(me.body.phoneMasked).not.toContain('1112233');
  });

  it('fotoğraf yükleme üst veriyi siler ve boyutu sınırlar', async () => {
    const img = await sharp({ create: { width: 3000, height: 2000, channels: 3, background: '#4FD69C' } })
      .withMetadata({ exif: { IFD0: { Copyright: 'gizli' } } }).jpeg().toBuffer();
    const r = await http.post('/v1/media').set(auth(S.ali.accessToken)).attach('file', img, 'a.jpg').expect(201);
    expect(r.body.width).toBe(1600);
    const file = await request(baseUrl).get(new URL(r.body.url).pathname).expect(200);
    const meta = await sharp(file.body).metadata();
    expect(meta.exif).toBeUndefined();
    S.mediaId = r.body.id;
    await http.post('/v1/media').set(auth(S.ali.accessToken)).attach('file', Buffer.from('metin'), 'a.txt').expect(415);
  });

  it('ilan oluşturma kuralları', async () => {
    const t = S.ali.accessToken;
    const base = { category: 'esya', subtype: 'ucretsiz', title: 'Ahşap kitaplık', description: 'Beş raflı ahşap kitaplık, taşınma nedeniyle veriyorum.' };
    await http.post('/v1/listings').set(auth(t)).send(base).expect(400).expect((r) => expect(r.body.code).toBe('LISTING_PHOTO_REQUIRED'));
    await http.post('/v1/listings').set(auth(t)).send({ ...base, subtype: 'istiyorum', mediaIds: [S.mediaId] }).expect(400).expect((r) => expect(r.body.code).toBe('LISTING_SUBTYPE_INVALID'));
    await http.post('/v1/listings').set(auth(t)).send({ ...base, subtype: 'satilik', mediaIds: [S.mediaId] }).expect(400).expect((r) => expect(r.body.code).toBe('LISTING_PRICE_REQUIRED'));
    await http.post('/v1/listings').set(auth(t)).send({ ...base, description: 'Az kullanılmış tabanca satıyorum, temiz.', mediaIds: [S.mediaId] }).expect(422)
      .expect((r) => expect(r.body.code).toBe('LISTING_CONTENT_BLOCKED'));
    const pending = await http.post('/v1/listings').set(auth(t)).send({ category: 'yardim', subtype: 'teklif', title: 'Taşınma yardımı', description: 'Kapora ile taşınma yardımı veriyorum, detay için yazın.' }).expect(201);
    expect(pending.body.status).toBe('pending_review');
    S.pendingId = pending.body.id;
    const ok = await http.post('/v1/listings').set(auth(t)).send({ ...base, description: base.description + ' Arayın: 0555 111 22 33', mediaIds: [S.mediaId], details: { condition: 'iyi', hack: 'x' } }).expect(201);
    expect(ok.body.status).toBe('active');
    expect(ok.body.warnings).toContain('phone');
    S.listingId = ok.body.id;
    const d = await http.get(`/v1/listings/${S.listingId}`).set(auth(t)).expect(200);
    expect(d.body.details).toEqual({ condition: 'iyi' });
    expect(d.body.isOwner).toBe(true);
    expect(JSON.stringify(d.body)).not.toContain('exactPoint');
  });

  it('kayıp ilanında gerçek nokta saklanır ama asla dönmez; görünen nokta 150-300 m uzakta', async () => {
    const t = S.ali.accessToken;
    const point = { lat: 37.7215, lng: 30.2901 };
    const r = await http.post('/v1/listings').set(auth(t)).send({ category: 'kayip', subtype: 'kayip_esya', title: 'Cüzdan kayboldu', description: 'Kahverengi deri cüzdan, içinde kimlik var.', point }).expect(201);
    const d = await http.get(`/v1/listings/${r.body.id}`).set(auth(t)).expect(200);
    const R = 6371000, rad = (x: number) => (x * Math.PI) / 180;
    const dLat = rad(d.body.approxLocation.lat - point.lat), dLng = rad(d.body.approxLocation.lng - point.lng);
    const m = 2 * R * Math.asin(Math.sqrt(Math.sin(dLat / 2) ** 2 + Math.cos(rad(point.lat)) ** 2 * Math.sin(dLng / 2) ** 2));
    expect(m).toBeGreaterThanOrEqual(140);
    expect(m).toBeLessThanOrEqual(310);
    expect(JSON.stringify(d.body)).not.toContain(String(point.lat));
    S.lostId = r.body.id;
  });

  it('akış, arama, sayım, harita ve sayfalama', async () => {
    S.ayse = await login('+905550000011');
    const t = S.ayse.accessToken;
    const f = await http.get('/v1/listings?radiusKm=5&limit=3').set(auth(t)).expect(200);
    expect(f.body.items).toHaveLength(3);
    expect(f.body.items[0].id).toBe(S.lostId);
    expect(f.body.nextCursor).toBeTruthy();
    const f2 = await http.get(`/v1/listings?radiusKm=5&limit=3&cursor=${f.body.nextCursor}`).set(auth(t)).expect(200);
    const ids = [...f.body.items, ...f2.body.items].map((x: any) => x.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids).not.toContain(S.pendingId);
    const s = await http.get('/v1/listings?q=COCUK').set(auth(t)).expect(200);
    expect(s.body.items.map((x: any) => x.title)).toContain('Çocuk bisikleti, 16 jant');
    const near = await http.get('/v1/listings?sort=near&category=esya').set(auth(t)).expect(200);
    const dist = near.body.items.map((x: any) => x.distance.meters);
    expect([...dist].sort((a, b) => a - b)).toEqual(dist);
    const c = await http.get('/v1/listings/count?category=esya&freeOnly=true').set(auth(t)).expect(200);
    expect(c.body.count).toBeGreaterThanOrEqual(2);
    const map = await http.get('/v1/listings/map?bbox=30.25,37.70,30.32,37.74').set(auth(t)).expect(200);
    expect(map.body.items.length).toBeGreaterThanOrEqual(8);
    await http.post(`/v1/listings/${S.listingId}/favorite`).set(auth(t)).expect(200);
    const favs = await http.get('/v1/me/favorites').set(auth(t)).expect(200);
    expect(favs.body.items[0].id).toBe(S.listingId);
  });

  it('gerçek zamanlı mesajlaşma, ilk yanıt metriği, IBAN onayı ve okundu bilgisi', async () => {
    const ali: Socket = io(baseUrl, { auth: { token: S.ali.accessToken }, transports: ['websocket'] });
    const ayse: Socket = io(baseUrl, { auth: { token: S.ayse.accessToken }, transports: ['websocket'] });
    await Promise.all([new Promise<void>((r) => ali.on('connect', () => r())), new Promise<void>((r) => ayse.on('connect', () => r()))]);
    try {
      await http.post('/v1/conversations').set(auth(S.ali.accessToken)).send({ listingId: S.listingId }).expect(400);
      const c = await http.post('/v1/conversations').set(auth(S.ayse.accessToken)).send({ listingId: S.listingId }).expect(200);
      S.convId = c.body.id;
      const again = await http.post('/v1/conversations').set(auth(S.ayse.accessToken)).send({ listingId: S.listingId }).expect(200);
      expect(again.body).toEqual({ id: S.convId, created: false });

      const gotMsg = waitFor<any>(ali, 'message:new');
      const gotNotif = waitFor<any>(ali, 'notification:new', (n) => n.type === 'first_reply');
      await http.post(`/v1/conversations/${S.convId}/messages`).set(auth(S.ayse.accessToken)).send({ body: 'Merhaba, kitaplık duruyor mu?', clientId: 'c1' }).expect(201);
      expect((await gotMsg).message.body).toBe('Merhaba, kitaplık duruyor mu?');
      expect((await gotNotif).title).toBe('İlanına ilk yanıt geldi');

      const typing = waitFor<any>(ayse, 'typing');
      ali.emit('typing', { conversationId: S.convId });
      expect((await typing).conversationId).toBe(S.convId);

      await http.post(`/v1/conversations/${S.convId}/messages`).set(auth(S.ali.accessToken)).send({ body: 'Ödemeyi TR12 0006 4000 0011 2345 6789 01 hesabına yap' }).expect(409)
        .expect((r) => expect(r.body.code).toBe('CHAT_PAYMENT_CONFIRM'));
      const warned = await http.post(`/v1/conversations/${S.convId}/messages`).set(auth(S.ali.accessToken)).send({ body: 'Duruyor, whatsapp üzerinden de yazabilirsin' }).expect(201);
      expect(warned.body.message.warnings).toContain('contact');

      const list = await http.get('/v1/conversations').set(auth(S.ali.accessToken)).expect(200);
      expect(list.body.items[0].unread).toBe(1);
      expect(list.body.items[0].role).toBe('owner');
      const badges = await http.get('/v1/badges').set(auth(S.ali.accessToken)).expect(200);
      expect(badges.body.messages).toBe(1);

      const read = waitFor<any>(ayse, 'message:read');
      await http.post(`/v1/conversations/${S.convId}/read`).set(auth(S.ali.accessToken)).expect(200);
      expect((await read).conversationId).toBe(S.convId);

      const msgs = await http.get(`/v1/conversations/${S.convId}/messages`).set(auth(S.ayse.accessToken)).expect(200);
      expect(msgs.body.items.map((m: any) => m.body)).toEqual(['Merhaba, kitaplık duruyor mu?', 'Duruyor, whatsapp üzerinden de yazabilirsin']);
      await http.delete(`/v1/messages/${msgs.body.items[0].id}`).set(auth(S.ayse.accessToken)).expect(200);
      const after = await http.get(`/v1/conversations/${S.convId}/messages`).set(auth(S.ali.accessToken)).expect(200);
      expect(after.body.items[0].deleted).toBe(true);
      expect(after.body.items[0].body).toBe('');
    } finally {
      ali.close();
      ayse.close();
    }
  });

  it('teslim, yardım sayacı ve kör değerlendirme', async () => {
    await http.post(`/v1/listings/${S.listingId}/close`).set(auth(S.ali.accessToken)).send({ reason: 'delivered', deliveredToUserId: S.ayse.user.id }).expect(200);
    const pr = await http.get('/v1/me/pending-reviews').set(auth(S.ayse.accessToken)).expect(200);
    expect(pr.body.items[0].listingId).toBe(S.listingId);
    const first = await http.post(`/v1/listings/${S.listingId}/reviews`).set(auth(S.ayse.accessToken)).send({ rating: 5, tags: ['nazik'], comment: 'Çok yardımcı oldu' }).expect(201);
    expect(first.body.published).toBe(false);
    let p = await http.get(`/v1/users/${S.ali.user.id}`).set(auth(S.ayse.accessToken)).expect(200);
    expect(p.body.stats.ratingCount).toBe(0);
    expect(p.body.stats.helpedCount).toBe(1);
    await http.post(`/v1/listings/${S.listingId}/reviews`).set(auth(S.ayse.accessToken)).send({ rating: 4 }).expect(409);
    const second = await http.post(`/v1/listings/${S.listingId}/reviews`).set(auth(S.ali.accessToken)).send({ rating: 5 }).expect(201);
    expect(second.body.published).toBe(true);
    p = await http.get(`/v1/users/${S.ali.user.id}`).set(auth(S.ayse.accessToken)).expect(200);
    expect(p.body.stats).toMatchObject({ ratingAvg: 5, ratingCount: 1 });
    expect(p.body.reviews[0].from).toBe('Ayşe K.');
  });

  it('engelleme akıştan ve mesajlaşmadan iki yönlü gizler', async () => {
    S.mehmet = await login('+905550000012');
    await http.post(`/v1/users/${S.ali.user.id}/block`).set(auth(S.mehmet.accessToken)).expect(200);
    const f = await http.get('/v1/listings?limit=50').set(auth(S.mehmet.accessToken)).expect(200);
    expect(f.body.items.map((x: any) => x.id)).not.toContain(S.lostId);
    await http.post('/v1/conversations').set(auth(S.mehmet.accessToken)).send({ listingId: S.lostId }).expect(403).expect((r) => expect(r.body.code).toBe('CHAT_BLOCKED'));
    await http.get(`/v1/users/${S.mehmet.user.id}`).set(auth(S.ali.accessToken)).expect(404);
    await http.delete(`/v1/users/${S.ali.user.id}/block`).set(auth(S.mehmet.accessToken)).expect(200);
  });

  it('şikâyet → otomatik gizleme → moderasyon → itiraz', async () => {
    S.zeynep = await login('+905550000013');
    const users = [S.ayse, S.mehmet, S.zeynep];
    let last: any;
    for (const u of users) last = (await http.post('/v1/reports').set(auth(u.accessToken)).send({ targetType: 'listing', targetId: S.lostId, reason: 'sahte_ilan' }).expect(201)).body;
    expect(last.autoHidden).toBe(true);
    await http.post('/v1/reports').set(auth(S.zeynep.accessToken)).send({ targetType: 'listing', targetId: S.lostId, reason: 'spam' }).expect(409);
    await http.get(`/v1/listings/${S.lostId}`).set(auth(S.ayse.accessToken)).expect(410);
    await http.get('/v1/admin/reports').set(auth(S.ayse.accessToken)).expect(403);

    S.mod = await login('+905550000002');
    S.admin = await login('+905550000001');
    const q = await http.get('/v1/admin/reports').set(auth(S.mod.accessToken)).expect(200);
    expect(q.body.items.length).toBeGreaterThanOrEqual(4);
    const pend = await http.get('/v1/admin/listings/pending').set(auth(S.mod.accessToken)).expect(200);
    expect(pend.body.items.map((x: any) => x.id)).toEqual(expect.arrayContaining([S.pendingId, S.lostId]));
    await http.post(`/v1/admin/listings/${S.pendingId}/decide`).set(auth(S.mod.accessToken)).send({ action: 'approve' }).expect(200);

    const rep = q.body.items.find((r: any) => r.targetId === S.lostId);
    const detail = await http.get(`/v1/admin/reports/${rep.id}`).set(auth(S.mod.accessToken)).expect(200);
    expect(detail.body.relatedReports).toHaveLength(3);
    expect(detail.body.owner.phone).toBeUndefined();
    await http.post(`/v1/admin/reports/${rep.id}/decide`).set(auth(S.mod.accessToken)).send({ action: 'ban' }).expect(403);
    const dec = await http.post(`/v1/admin/reports/${rep.id}/decide`).set(auth(S.mod.accessToken)).send({ action: 'remove_content', rule: 'sahte_ilan', reason: 'İlan gerçek bir kaybı yansıtmıyor.' }).expect(200);
    expect(dec.body.status).toBe('resolved');

    const mine = await http.get('/v1/me/decisions').set(auth(S.ali.accessToken)).expect(200);
    const d = mine.body.items.find((x: any) => x.id === dec.body.decisionId);
    expect(d.canAppeal).toBe(true);
    expect(d.internalNote).toBeUndefined();
    const ap = await http.post(`/v1/me/decisions/${d.id}/appeal`).set(auth(S.ali.accessToken)).send({ note: 'Cüzdanım gerçekten kayboldu, kimlik fotokopisini gösterebilirim.' }).expect(201);
    await http.post(`/v1/admin/appeals/${ap.body.id}/resolve`).set(auth(S.mod.accessToken)).send({ accept: true, resolution: 'Kendi kararım' }).expect(403);
    await http.post(`/v1/admin/appeals/${ap.body.id}/resolve`).set(auth(S.admin.accessToken)).send({ accept: true, resolution: 'İlan yeniden yayına alındı.' }).expect(200);
    await http.get(`/v1/listings/${S.lostId}`).set(auth(S.ayse.accessToken)).expect(200);
  });

  it('askıya alma, yönetici metrikleri ve denetim kaydı', async () => {
    await http.post(`/v1/admin/users/${S.zeynep.user.id}/action`).set(auth(S.mod.accessToken)).send({ action: 'suspend', suspendDays: 3, reason: 'Test' }).expect(200);
    await http.get('/v1/listings').set(auth(S.zeynep.accessToken)).expect(403).expect((r) => expect(r.body.code).toBe('ACCOUNT_SUSPENDED'));
    await http.get('/v1/me/decisions').set(auth(S.zeynep.accessToken)).expect(200);
    await http.post(`/v1/admin/users/${S.zeynep.user.id}/action`).set(auth(S.mod.accessToken)).send({ action: 'unsuspend' }).expect(200);
    const st = await http.get('/v1/admin/stats').set(auth(S.admin.accessToken)).expect(200);
    expect(st.body.last7d.replied).toBeGreaterThanOrEqual(1);
    expect(st.body.last7d.medianFirstReplyHours).not.toBeNull();
    const audit = await http.get('/v1/admin/audit').set(auth(S.admin.accessToken)).expect(200);
    expect(audit.body.map((a: any) => a.action)).toEqual(expect.arrayContaining(['decision.remove_content', 'appeal.accept', 'decision.suspend']));
    const rule = await http.post('/v1/admin/rules').set(auth(S.admin.accessToken)).send({ pattern: 'yasakkelime', action: 'block', label: 'Test' }).expect(201);
    await http.post('/v1/listings').set(auth(S.ayse.accessToken)).send({ category: 'yardim', subtype: 'istiyorum', title: 'Yardım lazım', description: 'yasakkelime içeren bir açıklama metni' }).expect(422);
    await http.delete(`/v1/admin/rules/${rule.body.id}`).set(auth(S.admin.accessToken)).expect(200);
    await http.get('/v1/admin/rules').set(auth(S.mod.accessToken)).expect(403);
  });

  it('yenileme belirteci döndürülür; tekrar kullanım tüm oturumları kapatır', async () => {
    const r1 = await http.post('/v1/auth/refresh').send({ refreshToken: S.ayse.refreshToken }).expect(200);
    expect(r1.body.refreshToken).not.toBe(S.ayse.refreshToken);
    await http.post('/v1/auth/refresh').send({ refreshToken: S.ayse.refreshToken }).expect(401);
    await http.post('/v1/auth/refresh').send({ refreshToken: r1.body.refreshToken }).expect(401);
  });

  it('veri dışa aktarma ve hesap silme talebi', async () => {
    const ex = await http.get('/v1/me/export').set(auth(S.ali.accessToken)).expect(200);
    expect(ex.body.listings.length).toBeGreaterThanOrEqual(3);
    expect(ex.body.profile.phone).toBe('+905551112233');
    await http.post('/v1/me/delete').set(auth(S.ali.accessToken)).send({ reason: 'test' }).expect(200);
    const ds = app.get(DataSource);
    const [{ n }] = await ds.query(`SELECT COUNT(*)::int AS n FROM listings WHERE "userId"=$1 AND status='active'`, [S.ali.user.id]);
    expect(n).toBe(0);
    await http.post('/v1/auth/refresh').send({ refreshToken: S.ali.refreshToken }).expect(401);
  });
});
