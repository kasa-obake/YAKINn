/**
 * Güvenlik ve işletme düzeltmeleri: destek talepleri, hesap silme (KVKK), bakım işleri,
 * socket kontrolleri, yönetici TOTP'si ve SMS kötüye kullanım sınırları. Gerçek PostgreSQL + PostGIS üzerinde çalışır.
 */
import { INestApplication } from '@nestjs/common';
import { existsSync } from 'fs';
import { basename, join } from 'path';
import sharp from 'sharp';
import { io, Socket } from 'socket.io-client';
import request from 'supertest';
import { DataSource } from 'typeorm';
import { totpCode } from '../src/common/totp';
import { User, UserRole } from '../src/database/entities';
import { createApp } from '../src/main';
import { MaintenanceService } from '../src/modules/maintenance/maintenance.service';
import { MediaStorage } from '../src/modules/media/storage';

let app: INestApplication;
let http: ReturnType<typeof request>;
let ds: DataSource;
let baseUrl: string;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function requestCode(phone: string) {
  await ds.query(`DELETE FROM otp_codes WHERE phone=$1`, [phone]); // 60 sn'lik yeniden gönderme sınırını aş
  const r = await http.post('/v1/auth/otp/request').send({ phone }).expect(200);
  return r.body.devCode as string;
}
async function login(phone: string) {
  const code = await requestCode(phone);
  const v = await http.post('/v1/auth/otp/verify').send({ phone, code, termsAccepted: true }).expect(200);
  return v.body as { accessToken: string; refreshToken: string; isNew: boolean; user: { id: string; totpEnabled: boolean } };
}
async function makeUser(phone: string, firstName: string) {
  const s = await login(phone);
  const t = s.accessToken;
  const n = await http.post('/v1/neighborhoods/resolve').set(auth(t)).send({ lat: 37.7213, lng: 30.2903 }).expect(200);
  await http.patch('/v1/me').set(auth(t)).send({ firstName, lastName: 'Deneme', birthYear: 1990, neighborhoodId: n.body.id }).expect(200);
  return { token: t, id: s.user.id, refresh: s.refreshToken };
}
async function makeStaff(phone: string, role: UserRole) {
  await ds.getRepository(User).save(ds.getRepository(User).create({ phone, firstName: 'Yetkili', lastName: 'Deneme', birthYear: 1985, role }));
  const s = await login(phone);
  return { token: s.accessToken, id: s.user.id };
}
async function photo(token: string) {
  const bg = { r: Math.floor(Math.random() * 255), g: Math.floor(Math.random() * 255), b: Math.floor(Math.random() * 255) };
  const img = await sharp({ create: { width: 400, height: 300, channels: 3, background: bg } }).jpeg().toBuffer();
  const r = await http.post('/v1/media').set(auth(token)).attach('file', img, 'f.jpg').expect(201);
  return r.body as { id: string; url: string };
}
async function listing(token: string, mediaId: string, title: string) {
  const r = await http.post('/v1/listings').set(auth(token)).send({ category: 'esya', subtype: 'ucretsiz', title, description: 'Beş raflı ahşap kitaplık, taşınma nedeniyle veriyorum.', mediaIds: [mediaId] }).expect(201);
  return r.body as { id: string };
}
const mediaPath = (url: string) => join((app.get(MediaStorage) as any).dir(), basename(new URL(url).pathname));
const connect = (token: string): Promise<Socket> =>
  new Promise((res) => { const s = io(baseUrl, { auth: { token }, transports: ['websocket'], reconnection: false }); s.on('connect', () => res(s)); });

beforeAll(async () => {
  app = await createApp();
  await app.listen(0);
  baseUrl = `http://127.0.0.1:${(app.getHttpServer().address() as any).port}`;
  http = request(app.getHttpServer());
  ds = app.get(DataSource);
});
afterAll(async () => { await app?.close(); });

describe('güvenlik ve işletme düzeltmeleri', () => {
  it('destek talebi: kullanıcı açar, moderatör görür ve yanıtlar, kullanıcıya bildirim gider', async () => {
    const u = await makeUser('+905559000106', 'Destek');
    const mod = await makeStaff('+905559000204', UserRole.MODERATOR);
    const t = await http.post('/v1/support').set(auth(u.token)).send({ subject: 'Giriş sorunu', body: 'Uygulamaya giriş yaparken sorun yaşıyorum.' }).expect(201);
    expect(t.body.ticketNo).toMatch(/^YK-\d{6}$/);
    await http.get('/v1/admin/support').set(auth(u.token)).expect(403);
    const list = await http.get('/v1/admin/support').set(auth(mod.token)).expect(200);
    const item = list.body.items.find((i: any) => i.ticketNo === t.body.ticketNo);
    expect(item).toMatchObject({ subject: 'Giriş sorunu', status: 'open' });
    expect((await http.get('/v1/admin/stats').set(auth(mod.token)).expect(200)).body.supportOpen).toBeGreaterThanOrEqual(1);
    await http.post(`/v1/admin/support/${item.id}/reply`).set(auth(mod.token)).send({ reply: 'Sorunu inceledik, şimdi tekrar dener misin?' }).expect(200).expect((r) => expect(r.body.status).toBe('answered'));
    const answered = await http.get('/v1/admin/support?status=answered').set(auth(mod.token)).expect(200);
    expect(answered.body.items.find((i: any) => i.id === item.id).reply).toContain('tekrar dener misin');
    const notes = await http.get('/v1/notifications').set(auth(u.token)).expect(200);
    expect(JSON.stringify(notes.body)).toContain(t.body.ticketNo);
    await http.post(`/v1/admin/support/${item.id}/reply`).set(auth(mod.token)).send({ reply: 'Kapatıyoruz.', status: 'closed' }).expect(200);
    const open = await http.get('/v1/admin/support').set(auth(mod.token)).expect(200);
    expect(open.body.items.map((i: any) => i.id)).not.toContain(item.id);
    await http.post('/v1/admin/support/999999/reply').set(auth(mod.token)).send({ reply: 'x' }).expect(404);
  });

  it('hesap silme: 30 gün dolmadan dokunulmaz, dolunca kişisel veri, mesaj ve fotoğraf silinir', async () => {
    const u = await makeUser('+905559000101', 'Silinecek');
    const v = await makeUser('+905559000102', 'Kalan');
    const m1 = await photo(u.token);
    const m2 = await photo(u.token);
    const l = await listing(u.token, m1.id, 'Silinecek kitaplık');
    const c = await http.post('/v1/conversations').set(auth(v.token)).send({ listingId: l.id }).expect(200);
    await http.post(`/v1/conversations/${c.body.id}/messages`).set(auth(v.token)).send({ body: 'Merhaba, hâlâ duruyor mu?' }).expect(201);
    await http.post(`/v1/conversations/${c.body.id}/messages`).set(auth(u.token)).send({ body: 'Evet, duruyor, gelebilirsin.' }).expect(201);
    expect(existsSync(mediaPath(m1.url)) && existsSync(mediaPath(m2.url))).toBe(true);

    await http.post('/v1/me/delete').set(auth(u.token)).send({ reason: 'test' }).expect(200);
    const svc = app.get(MaintenanceService);
    expect(await svc.purgeDeletedAccounts()).toBe(0); // 30 gün dolmadı
    expect((await ds.query(`SELECT status FROM users WHERE id=$1`, [u.id]))[0].status).toBe('active');

    await ds.query(`UPDATE users SET "deletionRequestedAt"=now()-interval '31 days' WHERE id=$1`, [u.id]);
    expect(await svc.purgeDeletedAccounts()).toBe(1);

    const [usr] = await ds.query(`SELECT status, phone, "firstName", "birthYear", "avatarUrl", "neighborhoodId" FROM users WHERE id=$1`, [u.id]);
    expect(usr).toMatchObject({ status: 'deleted', firstName: '', birthYear: null, avatarUrl: null, neighborhoodId: null });
    expect(usr.phone).toMatch(/^deleted:/);
    const [lst] = await ds.query(`SELECT title, description FROM listings WHERE id=$1`, [l.id]);
    expect(lst).toEqual({ title: 'Silinmiş ilan', description: '' });
    expect((await ds.query(`SELECT COUNT(*)::int n FROM listing_media WHERE "listingId"=$1`, [l.id]))[0].n).toBe(0);
    const msgs = await ds.query(`SELECT "senderId", body FROM messages WHERE "conversationId"=$1`, [c.body.id]);
    expect(msgs.find((m: any) => m.senderId === u.id).body).toBe('');
    expect(msgs.find((m: any) => m.senderId === v.id).body).toBe('Merhaba, hâlâ duruyor mu?'); // karşı tarafın verisi dokunulmaz
    expect(existsSync(mediaPath(m1.url)) || existsSync(mediaPath(m2.url))).toBe(false);
    expect((await ds.query(`SELECT COUNT(*)::int n FROM refresh_tokens WHERE "userId"=$1`, [u.id]))[0].n).toBe(0);
    expect((await ds.query(`SELECT COUNT(*)::int n FROM audit_logs WHERE action='user.purged' AND "targetId"=$1`, [u.id]))[0].n).toBe(1);
    expect(await svc.purgeDeletedAccounts()).toBe(0); // ikinci kez işlenmez

    const again = await login('+905559000101'); // aynı numara sonradan yeni hesap açabilir
    expect(again.isNew).toBe(true);
    expect(again.user.id).not.toBe(u.id);
  });

  it('bakım: eski OTP/oturum/bildirim ve sahipsiz fotoğraflar temizlenir, kullanımdaki dosyalar kalır', async () => {
    const w = await makeUser('+905559000103', 'Foto');
    const keep = await photo(w.token);
    const orphan = await photo(w.token);
    await listing(w.token, keep.id, 'Fotoğraflı ilan');
    await ds.query(`UPDATE media_uploads SET "createdAt"=now()-interval '25 hours' WHERE "userId"=$1`, [w.id]);
    await ds.query(`INSERT INTO otp_codes (phone,"codeHash","expiresAt","createdAt") VALUES ('+905559000999','x',now(),now()-interval '3 days')`);
    await ds.query(`INSERT INTO refresh_tokens ("userId","tokenHash","expiresAt") VALUES ($1,'eski-hash',now()-interval '2 days')`, [w.id]);
    await ds.query(`INSERT INTO notifications ("userId",type,title,"createdAt") VALUES ($1,'system','eski',now()-interval '200 days')`, [w.id]);
    const svc = app.get(MaintenanceService);
    const r = await svc.cleanupOldRecords();
    expect(r.otp).toBeGreaterThanOrEqual(1);
    expect(r.refreshTokens).toBeGreaterThanOrEqual(1);
    expect(r.notifications).toBeGreaterThanOrEqual(1);
    expect(await svc.cleanupOrphanMedia()).toBeGreaterThanOrEqual(1);
    expect(existsSync(mediaPath(orphan.url))).toBe(false);
    expect((await ds.query(`SELECT COUNT(*)::int n FROM media_uploads WHERE id=$1`, [orphan.id]))[0].n).toBe(0);
    expect(existsSync(mediaPath(keep.url))).toBe(true);
    expect((await ds.query(`SELECT COUNT(*)::int n FROM media_uploads WHERE id=$1`, [keep.id]))[0].n).toBe(1);
  });

  it('socket: askıya alınan kullanıcının bağlantısı kapanır, yeni bağlantı reddedilir; typing hız sınırlıdır', async () => {
    const owner = await makeUser('+905559000104', 'Sahip');
    const other = await makeUser('+905559000107', 'Diğer');
    const mod = await makeStaff('+905559000205', UserRole.MODERATOR);
    const l = await listing(owner.token, (await photo(owner.token)).id, 'Soket ilanı');
    const c = await http.post('/v1/conversations').set(auth(other.token)).send({ listingId: l.id }).expect(200);

    const sOwner = await connect(owner.token);
    const sOther = await connect(other.token);
    let typing = 0;
    sOther.on('typing', () => typing++);
    sOwner.emit('typing', { conversationId: c.body.id });
    sOwner.emit('typing', { conversationId: c.body.id });
    sOwner.emit('typing', { conversationId: c.body.id });
    await sleep(700);
    expect(typing).toBe(1);

    const closed = new Promise<string>((res) => sOwner.on('disconnect', (reason) => res(reason)));
    await http.post(`/v1/admin/users/${owner.id}/action`).set(auth(mod.token)).send({ action: 'suspend', suspendDays: 1, reason: 'Test' }).expect(200);
    expect(await Promise.race([closed, sleep(3000).then(() => 'zaman aşımı')])).toBe('io server disconnect');

    const s2 = io(baseUrl, { auth: { token: owner.token }, transports: ['websocket'], reconnection: false });
    const ended = await new Promise<string>((res) => { s2.on('disconnect', () => res('kapandı')); s2.on('connect_error', () => res('kapandı')); setTimeout(() => res('açık kaldı'), 3000); });
    expect(ended).toBe('kapandı');
    s2.close(); sOther.close();
  });

  it('yönetici iki adımlı doğrulama (TOTP): kurulum, girişte zorunluluk, zorunlu mod, kapatma', async () => {
    const phone = '+905559000202';
    const admin = await makeStaff(phone, UserRole.ADMIN);
    const normal = await makeUser('+905559000105', 'Normal');
    await http.post('/v1/me/totp/setup').set(auth(normal.token)).expect(403);
    await http.post('/v1/me/totp/enable').set(auth(admin.token)).send({ code: '123456' }).expect(409); // önce kurulum

    const setup = await http.post('/v1/me/totp/setup').set(auth(admin.token)).expect(200);
    expect(setup.body.otpauthUrl).toContain('otpauth://totp/');
    await http.post('/v1/me/totp/enable').set(auth(admin.token)).send({ code: '000000' }).expect(400);
    await http.post('/v1/me/totp/enable').set(auth(admin.token)).send({ code: totpCode(setup.body.secret) }).expect(200);
    const [{ totpSecret }] = await ds.query(`SELECT "totpSecret" FROM users WHERE id=$1`, [admin.id]);
    expect(totpSecret).not.toContain(setup.body.secret); // veritabanında şifreli

    const code = await requestCode(phone);
    await http.post('/v1/auth/otp/verify').send({ phone, code }).expect(401).expect((r) => expect(r.body.code).toBe('AUTH_TOTP_REQUIRED'));
    await http.post('/v1/auth/otp/verify').send({ phone, code, totpCode: '000000' }).expect(401).expect((r) => expect(r.body.code).toBe('AUTH_TOTP_INVALID'));
    const ok = await http.post('/v1/auth/otp/verify').send({ phone, code, totpCode: totpCode(setup.body.secret) }).expect(200);
    expect(ok.body.user.totpEnabled).toBe(true);

    process.env.ADMIN_TOTP_REQUIRED = 'true';
    try {
      const b = await makeStaff('+905559000203', UserRole.ADMIN);
      await http.get('/v1/admin/stats').set(auth(b.token)).expect(403).expect((r) => expect(r.body.code).toBe('TOTP_SETUP_REQUIRED'));
      const sb = await http.post('/v1/me/totp/setup').set(auth(b.token)).expect(200);
      await http.post('/v1/me/totp/enable').set(auth(b.token)).send({ code: totpCode(sb.body.secret) }).expect(200);
      await http.get('/v1/admin/stats').set(auth(b.token)).expect(200);
      await http.get('/v1/admin/stats').set(auth(ok.body.accessToken)).expect(200);
    } finally {
      delete process.env.ADMIN_TOTP_REQUIRED;
    }

    await http.post('/v1/me/totp/disable').set(auth(ok.body.accessToken)).send({ code: '000000' }).expect(400);
    await http.post('/v1/me/totp/disable').set(auth(ok.body.accessToken)).send({ code: totpCode(setup.body.secret) }).expect(200);
    const plain = await login(phone); // artık yalnızca SMS kodu yeterli
    expect(plain.user.totpEnabled).toBe(false);
  });

  it('SMS kötüye kullanım sınırları: günlük toplam ve IP başına', async () => {
    await requestCode('+905559000300');
    const [{ n }] = await ds.query(`SELECT COUNT(*)::int n FROM otp_codes WHERE "createdAt" > now() - interval '24 hours'`);
    process.env.SMS_DAILY_LIMIT = String(n);
    try {
      await http.post('/v1/auth/otp/request').send({ phone: '+905559000301' }).expect(503).expect((r) => expect(r.body.code).toBe('AUTH_SMS_BUDGET'));
    } finally {
      delete process.env.SMS_DAILY_LIMIT;
    }
    await http.post('/v1/auth/otp/request').send({ phone: '+905559000301' }).expect(200);

    process.env.THROTTLE_IN_TEST = 'true';
    try {
      const statuses: number[] = [];
      for (let i = 0; i < 16; i++) statuses.push((await http.post('/v1/auth/otp/request').send({ phone: `+9055591${String(i).padStart(5, '0')}` })).status);
      expect(statuses.slice(0, 15).every((s) => s === 200)).toBe(true);
      expect(statuses[15]).toBe(429);
    } finally {
      delete process.env.THROTTLE_IN_TEST;
    }
  });
});
