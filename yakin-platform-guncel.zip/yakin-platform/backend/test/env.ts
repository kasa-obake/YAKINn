import { config } from 'dotenv';
import { resolve } from 'path';
config({ path: resolve(__dirname, '../.env.test'), override: true });
process.env.ENV_FILE = resolve(__dirname, '../.env.test');
