import { ConfigService } from '@nestjs/config';
import { mkdtempSync, existsSync, writeFileSync, readdirSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { validateEnv } from '../src/common/env';
import { base32Encode, decryptSecret, encryptSecret, generateTotpSecret, totpCode, verifyTotp } from '../src/common/totp';
import { LocalMediaStorage } from '../src/modules/media/storage';
import { mediaStorageFactory } from '../src/modules/media/media.module';
import { S3MediaStorage } from '../src/modules/media/storage.s3';

const cfg = (m: Record<string, string>) => ({ get: (k: string) => m[k], getOrThrow: (k: string) => m[k] }) as unknown as ConfigService;

const GOOD = {
  NODE_ENV: 'production', DATABASE_URL: 'postgres://yakin:Zk3pQ9vL2mXw@db:5432/yakin', PUBLIC_BASE_URL: 'https://api.ornek.com.tr', SMS_PROVIDER: 'netgsm',
  JWT_ACCESS_SECRET: 'q8W3zL0pV7nB5xT2cR9mK4jH6gF1dS8aY3uE7iO0', JWT_REFRESH_SECRET: 'Zr4TgB8nM2vC6xL9kQ1wP5hJ3dF7sA0yU8eI2oN6', CORS_ORIGINS: '', OTP_DEV_ECHO: 'false',
} as NodeJS.ProcessEnv;

describe('üretim yapılandırma doğrulaması', () => {
  it('eski docker-compose varsayılanları üretimde reddedilir', () => {
    const { errors } = validateEnv({ NODE_ENV: 'production', DATABASE_URL: 'postgres://yakin:yakin@db:5432/yakin', PUBLIC_BASE_URL: 'http://localhost:3000', CORS_ORIGINS: '*', SMS_PROVIDER: 'console', OTP_DEV_ECHO: 'true', JWT_ACCESS_SECRET: 'degistir-erisim', JWT_REFRESH_SECRET: 'degistir-yenileme' } as NodeJS.ProcessEnv);
    const all = errors.join('\n');
    expect(all).toMatch(/JWT_ACCESS_SECRET en az 32/);
    expect(all).toMatch(/OTP_DEV_ECHO/);
    expect(all).toMatch(/CORS_ORIGINS/);
    expect(all).toMatch(/SMS_PROVIDER/);
    expect(all).toMatch(/PUBLIC_BASE_URL/);
    expect(all).toMatch(/parolası/);
  });
  it('güvenli üretim yapılandırması geçer', () => expect(validateEnv(GOOD).errors).toEqual([]));
  it('aynı veya sabit kodlu anahtarlar reddedilir', () => {
    expect(validateEnv({ ...GOOD, JWT_REFRESH_SECRET: GOOD.JWT_ACCESS_SECRET }).errors.join()).toMatch(/farklı olmalı/);
    expect(validateEnv({ ...GOOD, OTP_FIXED_CODE: '123456' }).errors.join()).toMatch(/OTP_FIXED_CODE/);
    expect(validateEnv({ ...GOOD, JWT_ACCESS_SECRET: undefined }).errors.join()).toMatch(/JWT_ACCESS_SECRET tanımlı değil/);
  });
  it('ALLOW_INSECURE_HTTP=true yalnızca https uyarısını yumuşatır', () => {
    const r = validateEnv({ ...GOOD, PUBLIC_BASE_URL: 'http://1.2.3.4', ALLOW_INSECURE_HTTP: 'true' });
    expect(r.errors).toEqual([]);
    expect(r.warnings.join()).toMatch(/https/);
    expect(validateEnv({ ...GOOD, PUBLIC_BASE_URL: 'http://1.2.3.4' }).errors.join()).toMatch(/https/);
  });
  it('geliştirmede yalnızca uyarı verir, testte sessizdir', () => {
    expect(validateEnv({ NODE_ENV: 'development', OTP_DEV_ECHO: 'true' } as NodeJS.ProcessEnv).errors).toEqual([]);
    expect(validateEnv({ NODE_ENV: 'test' } as NodeJS.ProcessEnv)).toEqual({ errors: [], warnings: [] });
  });
});

describe('TOTP (RFC 6238)', () => {
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  it('RFC 6238 test vektörleriyle uyumlu (SHA-1, son 6 hane)', () => {
    expect(secret).toBe('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
    expect(totpCode(secret, 59_000)).toBe('287082');
    expect(totpCode(secret, 1_111_111_109_000)).toBe('081804');
    expect(totpCode(secret, 1_234_567_890_000)).toBe('005924');
    expect(totpCode(secret, 2_000_000_000_000)).toBe('279037');
  });
  it('±1 adım (30 sn) kabul edilir, daha uzağı reddedilir; sayı dışı girdi reddedilir', () => {
    const t = 1_700_000_000_000;
    const code = totpCode(secret, t);
    expect(verifyTotp(secret, code, t)).toBe(true);
    expect(verifyTotp(secret, code, t + 30_000)).toBe(true);
    expect(verifyTotp(secret, code, t - 30_000)).toBe(true);
    expect(verifyTotp(secret, code, t + 90_000)).toBe(false);
    expect(verifyTotp(secret, 'abcdef', t)).toBe(false);
    expect(verifyTotp(secret, '12345', t)).toBe(false);
  });
  it('sır şifreli saklanır; yanlış anahtarla açılmaz', () => {
    const s = generateTotpSecret();
    const a = encryptSecret(s, 'anahtar-1'), b = encryptSecret(s, 'anahtar-1');
    expect(a).not.toBe(b);
    expect(a).not.toContain(s);
    expect(decryptSecret(a, 'anahtar-1')).toBe(s);
    expect(() => decryptSecret(a, 'anahtar-2')).toThrow();
  });
});

describe('dosya depoları', () => {
  it('S3: yükler, kendi adresindeki dosyayı siler, başka adresi ve güvensiz anahtarı yok sayar', async () => {
    const sent: any[] = [];
    const s3 = new S3MediaStorage(cfg({ S3_BUCKET: 'kova', S3_PUBLIC_BASE_URL: 'https://cdn.ornek.com/', S3_ACCESS_KEY_ID: 'a', S3_SECRET_ACCESS_KEY: 'b' }), { send: async (c: any) => { sent.push(c); return {}; } } as any);
    const url = await s3.put('abc.jpg', Buffer.from('x'), 'image/jpeg');
    expect(url).toBe('https://cdn.ornek.com/abc.jpg');
    expect(sent[0].input).toMatchObject({ Bucket: 'kova', Key: 'abc.jpg', ContentType: 'image/jpeg' });
    await s3.delete('https://cdn.ornek.com/abc.jpg');
    expect(sent[1].constructor.name).toBe('DeleteObjectCommand');
    expect(sent[1].input).toEqual({ Bucket: 'kova', Key: 'abc.jpg' });
    await s3.delete('https://baska.com/abc.jpg');
    await s3.delete('https://cdn.ornek.com/..%2Fx.jpg');
    expect(sent).toHaveLength(2);
  });
  it('yerel disk: siler, yoksa hata vermez, ../ ile dışarı çıkamaz', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'yk-'));
    const outside = join(dir, '..', `dis-${Date.now()}.txt`);
    writeFileSync(outside, 'dokunma');
    const st = new LocalMediaStorage(cfg({ MEDIA_DIR: dir, PUBLIC_BASE_URL: 'http://x' }));
    const url = await st.put('a.jpg', Buffer.from('1'));
    expect(url).toBe('http://x/uploads/a.jpg');
    expect(existsSync(join(dir, 'a.jpg'))).toBe(true);
    await st.delete(url);
    expect(readdirSync(dir)).toEqual([]);
    await st.delete(url);
    await st.delete(`http://x/uploads/..%2F${outside.split('/').pop()}`);
    await st.delete('http://x/uploads/../' + outside.split('/').pop());
    expect(existsSync(outside)).toBe(true);
  });
  it('MEDIA_DRIVER seçimi: bilinmeyen değer ve eksik S3 ayarı açılışta hata verir', () => {
    expect(mediaStorageFactory(cfg({}))).toBeInstanceOf(LocalMediaStorage);
    expect(() => mediaStorageFactory(cfg({ MEDIA_DRIVER: 'ftp' }))).toThrow(/MEDIA_DRIVER/);
    expect(() => mediaStorageFactory(cfg({ MEDIA_DRIVER: 's3' }))).toThrow(/S3_BUCKET/);
  });
});
