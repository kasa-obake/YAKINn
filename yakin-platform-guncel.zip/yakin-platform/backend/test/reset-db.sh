#!/usr/bin/env bash
# Test veritabanını sıfırlar, göçleri ve tohum verisini uygular.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env.test; set +a
psql "$DATABASE_URL" -q -c "DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;" >/dev/null
npx typeorm-ts-node-commonjs migration:run -d src/database/data-source.ts >/dev/null
ENV_FILE=.env.test npx ts-node --transpile-only src/database/seed.ts
